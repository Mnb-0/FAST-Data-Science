//Muhammad Muneeb Lone | 23i-2623 | Assignment 1
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
void displayMatrix(int*** , int , int , int );
void scalar(int***, int, int, int, int);
void arithmetic(int***, int, int, int);
void transpose(int***, int, int, int);


int main() 
{
    srand(time(nullptr));

    int depth, rows, cols;
    cout << "Enter depth, rows, and columns of the 3D matrix: ";
    cin >> depth >> rows >> cols;

    int*** matrix = new int**[depth];
    for (int k = 0; k < depth; ++k) 
    {
        matrix[k] = new int*[rows];
        for (int i = 0; i < rows; ++i) 
        {
            matrix[k][i] = new int[cols];
        }
    }

    for (int k = 0; k < depth; ++k) 
    {
        for (int i = 0; i < rows; ++i) 
        {
            for (int j = 0; j < cols; ++j) 
            {
                matrix[k][i][j] = rand() % 90 + 10;
            }
        }
    }

    displayMatrix(matrix, depth, rows, cols);
    scalar(matrix, depth, rows, cols, 10);
    displayMatrix(matrix, depth, rows, cols);
    arithmetic(matrix,depth,rows,cols);
    displayMatrix(matrix, depth, rows, cols);
    transpose(matrix, depth, rows, cols);
    displayMatrix(matrix, depth, rows, cols);


    for (int k = 0; k < depth; ++k) 
    {
        for (int i = 0; i < rows; ++i) 
        {
            delete[] matrix[k][i];
        }
        delete[] matrix[k];
    }
    delete[] matrix;

    return 0;
}
void displayMatrix(int*** matrix, int depth, int rows, int cols) 
{
    for (int k = 0; k < depth; ++k) 
    {
        cout << "Depth " << k + 1 << ":\n";
        for (int i = 0; i < rows; ++i) 
        {
            for (int j = 0; j < cols; ++j) 
            {
                cout << matrix[k][i][j] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
}
void scalar(int*** matrix, int depth, int rows, int cols, int val)
{
    for(int i = 0; i < depth; i++)
    {
        for(int j = 0; j < rows; j++)
        {
            for(int k = 0; k < cols; k++)
            {
                matrix[i][j][k] = matrix[i][j][k] + val;
            }
        }
    }
}
void arithmetic(int*** matrix, int depth, int rows, int cols) 
{
    int dTar, rTar, cTar, val;
    cout << "Enter a target depth, row, and column to perform arithmetic operations on: \n";
    cin >> dTar >> rTar >> cTar;

    if (dTar < 1 || dTar > depth || rTar < 1 || rTar > rows || cTar < 1 || cTar > cols) 
    {
        cout << "Invalid target.\n";
        return;
    }

    char operation = ' ';
    cout << "Enter the operation you want to perform (+, -, *, /): \n";
    cin >> operation;

    cout << "Enter the value: \n";
    cin >> val;

    switch (operation) 
    {
        case '+':
            matrix[dTar - 1][rTar - 1][cTar - 1] += val;
            break;
        case '-':
            matrix[dTar - 1][rTar - 1][cTar - 1] -= val;
            break;
        case '*':
            matrix[dTar - 1][rTar - 1][cTar - 1] *= val;
            break;
        case '/':
            if (val != 0)
                matrix[dTar - 1][rTar - 1][cTar - 1] /= val;
            else
                cout << "Cannot divide by zero.\n";
            break;
        default:
            cout << "Invalid operation.\n";
    }
}

void transpose(int*** matrix, int depth, int rows, int cols) 
{
    
    int*** tempMatrix = new int**[depth];
    for (int k = 0; k < depth; ++k) 
    {
        tempMatrix[k] = new int*[cols];
        for (int i = 0; i < cols; ++i) 
        {
            tempMatrix[k][i] = new int[rows];
        }
    }

    
    for (int k = 0; k < depth; ++k) 
    {
        for (int i = 0; i < cols; ++i) 
        {
            for (int j = 0; j < rows; ++j) 
            {
                tempMatrix[k][i][j] = matrix[k][j][i];
            }
        }
    }

    // Copy the transposed matrix back to the original matrix
    for (int k = 0; k < depth; ++k) 
    {
        for (int i = 0; i < rows; ++i) 
        {
            delete[] matrix[k][i];
        }
        delete[] matrix[k];
    }

    for (int k = 0; k < depth; ++k) 
    {
        matrix[k] = tempMatrix[k];
    }


    for (int k = 0; k < depth; ++k) 
    {
        for (int i = 0; i < cols; ++i) 
        {
            delete[] tempMatrix[k][i];
        }
        delete[] tempMatrix[k];
    }
    delete[] tempMatrix;
}


