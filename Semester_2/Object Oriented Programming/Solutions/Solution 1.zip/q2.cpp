//Muhammad Muneeb Lone | 23i-2623 | Assignment 1
#include <iostream>
using namespace std;
void sizeofArray(int, int);
void accessArray(int**, int, int, int, int);
void resizeArray(int**, int&, int&, int, int);
void printArray(int**, int, int);
int main()
{
    int x, y;
    cout<<"Array Creation Initiated: \n";
    cout<<"Enter the number of rows for the 2D Array: \n";
    cin>>x;
    cout<<"Enter the numer of columns for the 2D Array: \n";
    cin>>y;
    cout<<"Array created. Initialize it with values now: \n";
    int** arr = new int*[x];
    for(int i = 0; i < x; i++)
    {
        arr[i] = new int[y];
        for(int j = 0; j < y; j++)
        {
            cin>>arr[i][j];
        }
    }
    int choice = 0;
    cout<<"MENU\n";
    cout<<"\nSelect an option:\n";
    cout<<"\n1.Get Size of the Array.\n2.Access Elements by index.\n3.Resize the Array.\n4.Display elements of the array.\n5.Deallocate array.\n";
    cin>>choice;
    while(choice != 5)
    {
        switch(choice)
        {
            case 1:
            {
                sizeofArray(x,y);
                break;
            }
            case 2:
            {
                int tar1, tar2;
                cout<<"Enter a target row and column: \n";
                cin>>tar1>>tar2;
                accessArray(arr,x,y,tar1,tar2);
                break;
            }
            case 3:
            {
                int new_x, new_y;
                cout<<"Enter rows and columns for the new array: \n";
                cin>>new_x>>new_y;
                resizeArray(arr,x,y,new_x, new_y);
                break;
            }
            case 4:
            {
                printArray(arr,x,y);
                break;
            }
            case 5:
            {
                for (int i = 0; i < x; i++)
                    delete[] arr[i];
                delete[] arr;
                cout<<"Array deleted. Ending program.\n";
                return 0;
            }
        }
        cout<<"Enter your choice again: ";
        cin>>choice;
    }
}

void sizeofArray(int rows ,int cols)
{
    cout<<"Number of rows in the array: "<<rows<<endl;
    cout<<"Number of cols in the array: "<<cols<<endl;
    cout<<"Number of elements in the array: "<<rows*cols<<endl;
}
void accessArray(int** arr, int rows, int cols, int rTar, int cTar)
{
    cout<<"The element on the index ["<<rTar<<"]["<<cTar<<"] is: "<<arr[rTar][cTar];

}
void resizeArray(int** arr, int& rows, int& cols, int x, int y)
{
    int** arrTemp = new int*[x];
    for(int i = 0; i < x; i++)
    {
        arrTemp[i] = new int[y];
    }
    for(int i = 0; i < x; i++)
    {
        if(i < rows)
        {
            for(int j = 0; j < y; j++)
            {
                if(j < cols)
                {
                    arrTemp[i][j] = arr[i][j];
                }
            }
        }
    }
    for (int i = 0; i < rows; i++)
        delete[] arr[i];
    delete[] arr;
    arr = arrTemp;
    cout<<"Array resized.\n";
    rows = x;
    cols = y;
}

void printArray(int** arr, int rows, int cols)
{
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            cout<<arr[i][j]<<endl;
        }
    }
}