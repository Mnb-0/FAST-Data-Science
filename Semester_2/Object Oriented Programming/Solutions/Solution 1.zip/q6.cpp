//Muhammad Muneeb Lone | 23i-2623 | Assignment 1
#include <iostream>
using namespace std;
void arrEncrypt(char **, int);
void arrDecrypt(char **, int);
bool arrUpdate(char **, int, int , int , char );

int main() 
{
    char draw;
    cout << "Enter symbol to draw pattern with: ";
    cin >> draw;

    char **arr = new char*[5];
    for (int i = 0; i < 5; ++i) 
    {
        arr[i] = new char[5];
    }

    for (int i = 0; i < 5; ++i) //drawing F using loops
    {
        for (int j = 0; j < 5; ++j) 
        {
            if (i == 0 || i == 2)
                arr[i][j] = draw;
            else if (j == 0)
                arr[i][j] = draw;
            else
                arr[i][j] = ' ';
        }
    }

    cout << "Original Matrix: \n";
    for (int i = 0; i < 5; ++i) 
    {
        for (int j = 0; j < 5; ++j) 
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }

    arrEncrypt(arr, 5);
    cout << "***Encrypting***"<<endl;
    for (int i = 0; i < 5; ++i) 
    {
        for (int j = 0; j < 5; ++j) 
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }

    arrDecrypt(arr, 5);

    cout << "***Decrypting***" << endl;
    for (int i = 0; i < 5; ++i) 
    {
        for (int j = 0; j < 5; ++j) 
        {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }

    char symbol;
    int rowI, colI;
    cout << "\nEnter a symbol, row and column: ";
    cin >> symbol>>rowI>>colI;

    if(arrUpdate(arr, 5, rowI, colI, symbol))
    {
        cout << "Grid After Updating:" << endl;
        for (int i = 0; i < 5; ++i) 
        {
            for (int j = 0; j < 5; ++j) 
            {
                cout << arr[i][j] << " ";
            }
            cout << endl;
        }
    }

    for (int i = 0; i < 5; ++i) 
    {
        delete[] arr[i];
    }
    delete[] arr;

    return 0;
}
void arrEncrypt(char **arr, int size)
{
    //colswap then transpose
    for (int i = 0; i < size; ++i) 
    {
        char temp = arr[i][0];
        arr[i][0] = arr[i][size - 1];
        arr[i][size - 1] = temp;
    }
    for (int i = 0; i < size; ++i) 
    {
        for (int j = i + 1; j < size; ++j) 
        {
            char temp = arr[i][j];
            arr[i][j] = arr[j][i];
            arr[j][i] = temp;
        }
    }
    
}

void arrDecrypt(char **arr, int size) 
{
    //transpose then colswap
    for (int i = 0; i < size; ++i) 
    {
        for (int j = i + 1; j < size; ++j) 
        {
            char temp = arr[i][j];
            arr[i][j] = arr[j][i];
            arr[j][i] = temp;
        }
    }
    for (int i = 0; i < size; ++i) 
    {
        char temp = arr[i][0];
        arr[i][0] = arr[i][size - 1];
        arr[i][size - 1] = temp;
    }
    
}

bool arrUpdate(char **arr, int size, int rowI, int colI, char symbol) 
{
    //Checking boundaries and if the index is on the patterns
    if (rowI >= 0 && rowI < size && colI >= 0 && colI < size && (rowI == 0 || rowI == 2 || colI == 0)) 
    {
        arr[rowI][colI] = symbol;
        return true;
    }
    else
    {
        cout<<"Index is not on the pattern.\n";
        return false;
    }
}
