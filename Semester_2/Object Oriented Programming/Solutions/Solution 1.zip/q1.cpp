//Muhammad Muneeb Lone | 23i-2623 | Assignment 1
#include <iostream>
#include <string>
#include <fstream>
#define N 10 // Change for more rows in the file
using namespace std;
bool checkWord(string, string, int);
void upperCase(string&);
string makeRow(char **, int , bool );
string makeCol(char **, int , bool );
string makeDiagonals(char **, int , int , bool );
bool searchWord(char **, string);


int main() 
{

    char** arr = new char*[N];
    for (int i = 0; i < N; i++)
        arr[i] = new char[N];

    ifstream file("boggle.txt");
    if (!file.is_open()) 
    {
        cerr << "Error opening file." << endl;
        return 1;
    }

    for (int i = 0; i < N; i++) 
    {
        for (int j = 0; j < N; j++) 
        {
            file >> arr[i][j];
        }
    }
    file.close();

    for (int i = 0; i < N; i++) 
    {
        for (int j = 0; j < N; j++) 
        {
            cout << arr[i][j];
        }
        cout << endl;
    }
    string word;
    cout << "Enter a word you would like to search on the arr: ";
    cin >> word;

    upperCase(word);

    if (searchWord(arr, word)) 
    {
        cout << "The word \"" << word << "\" was found in the grid." << endl;
    } else 
    {
        cout << "The word \"" << word << "\" was not found in the grid." << endl;
    }

    // Deallocation
    for (int i = 0; i < N; i++)
        delete[] arr[i];
    delete[] arr;

    return 0;
}
bool checkWord(string checkStr, string inString, int size) 
{
    string temp = "";
    for (int i = 0; i < size; i++) 
    {
        if (checkStr[i] == inString[i]) 
        {
            temp += inString[i];
        } else 
        {
            break;
        }
    }
    return temp == checkStr;
}



void upperCase(string& inString) 
{
    for (int i = 0; i < inString.length(); i++) 
    {
        if (inString[i] >= 'a' && inString[i] <= 'z') 
        {
            inString[i] = inString[i] - 32;
        }
    }
}

string makeRow(char **array, int rowNum, bool asc) 
{
    string rowString = "";
    if(asc == true)//True means left to right and false means right to left in this function
    {
        
        for (int i = 0; i < N; i++) 
        {
            rowString += array[rowNum][i];
        }
    }
    else if(asc == false)
    {
    
        for (int i = N-1; i >= 0; i--) 
        {
            rowString += array[rowNum][i];
        }
        
    }
    return rowString;
}
string makeCol(char **array, int colNum, bool asc) 
{
    string colString = "";
    if(asc == true)//True means up to down in this function
    {
        
        for (int i = 0; i < N; i++) 
        {
            colString += array[i][colNum];
        }
    }
    else if(asc == false)
    {
        for (int i = N-1; i >= 0; i--) 
        {
            colString += array[i][colNum];
        }
        
    }
    return colString;
}
string makeDiagonals(char **array, int startRow, int startCol, bool asc) 
{
    string diagonalString = "";
    int row, col;
if(asc==true)
    {// Left to right diagonal
    row = startRow;
    col = startCol;
    while (row >= 0 && row < N && col >= 0 && col < N) 
    {
        diagonalString += array[row][col];
        row++;
        col++;
    }
    }
    else if(asc == false)
    {// Right to left diagonal
    row = startRow;
    col = startCol;
    while (row >= 0 && row < N && col >= 0 && col < N) 
    {
        diagonalString += array[row][col];
        row++;
        col--;
    }
    }

    return diagonalString;
}
bool searchWord(char **array, string word) 
{
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            string row1 = makeRow(array, i, true);
            string col1 = makeCol(array, j, true);
            string row2 = makeRow(array, i, false);
            string col2 = makeCol(array, j, false);
            string diagonal1 = makeDiagonals(array, i, j, true);
            string diagonal2 = makeDiagonals(array, i, j, false);

            if (checkWord(word, row1, N) || checkWord(word, col1, N) || checkWord(word, diagonal1, N) || checkWord(word, diagonal2, N) || checkWord(word, row2, N) || checkWord(word, col2, N)) 
            {
                return true;
            }
        }
    }
    return false;
}

