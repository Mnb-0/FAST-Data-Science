// Muhammad Muneeb Lone | 23i-2623 | Assignment #4
#include <iostream>
#include <string>

using namespace std;

// Length Function
int length(string inString)
{
    int len = 0;
    for (int i = 0; inString[i] != '\0'; i++)
    {
        len++;
    }
    return len;
}
string pad(string in, int max)
{
    if (length(in) >= max)
    {
        return in;
    }

    int need = max - length(in);
    // Append zeros to the start of the string
    for (int i = 0; i < need; i++)
    {
        in = '0' + in;
    }
    return in;
}
string substr(string const str, int startPos, int endPos)
{
    string temp;
    if (startPos > endPos || startPos < 0 || endPos >= length(str))
    {
        return temp;
    }
    for (int i = startPos; i <= endPos; i++)
    {
        temp += str[i];
    }
    return temp;
}

// Conversion to Denary Number
int to_Decimal(string inString, int base = 2)
{
    if (base <= 1)
    {
        cout << "Invalid base. Base must be greater than 1\n";
        return -1; // Error
    }

    int decVal = 0;
    int power = 1;
    for (int i = length(inString) - 1; i >= 0; i--)
    {
        int digit = inString[i] - '0';
        if (digit >= base)
        {
            cout << "Invalid Number/Base. Digits cannot be greater than or equal to the base\n";
            return -1; // Error
        }
        decVal += digit * power;
        power *= base;
    }
    return decVal;
}

// Conversion to Binary Number (Only from Denary)
string to_Binary(string in, int base = 10)
{
    if (base != 10)
    {
        return "Invalid base\n";
    }

    int decimal = 0;
    for (int i = 0; i < length(in); i++)
    {
        decimal = decimal * 10 + (in[i] - '0');
    }

    string binaryNum = "";
    if (decimal == 0)
    {
        binaryNum = "0";
    }
    else
    {
        while (decimal > 0)
        {
            int remainder = decimal % 2;
            binaryNum = char('0' + remainder) + binaryNum;
            decimal /= 2;
        }
    }

    return binaryNum;
}
// Only from denary
string to_Binary(int decimal, int base = 10)
{
    if (decimal == 0)
    {
        return "0";
    }

    string binaryNum = "";
    while (decimal > 0)
    {
        int remainder = decimal % 2;
        binaryNum = char('0' + remainder) + binaryNum;
        decimal /= 2;
    }

    return binaryNum;
}

class Binary
{
private:
    string binaryString;
    int base;

public:
    // Constructor (If base is greater than 2 first convert into base 10 using that base and then convert back into binary and change the base to 2)
    Binary() : binaryString(""), base(2) {}
    Binary(string binaryStr, int base = 2)
    {
        this->binaryString = binaryStr;
        this->base = base;

        if (base <= 1)
        {
            cout << "Please enter a base greater than 1\n";
        }
        else if (base > 2)
        {
            int denary = to_Decimal(this->binaryString, this->base);
        }
    }

    // Overloading + operator for addition
    Binary operator+(const Binary &other) const
    {
        Binary temp;
        temp.binaryString = to_Binary(to_Decimal(this->binaryString, this->base) + to_Decimal(other.binaryString, other.base));
        return temp;
    }

    // Overloading - operator for subtraction
    Binary operator-(const Binary &other) const
    {
        Binary temp;
        temp.binaryString = to_Binary(to_Decimal(this->binaryString, this->base) - to_Decimal(other.binaryString, other.base));
        return temp;
    }

    // Overloading += operator for addition
    Binary &operator+=(const Binary &other)
    {
        int sum = to_Decimal(binaryString, base) + to_Decimal(other.binaryString, other.base);
        binaryString = to_Binary(sum, base);
        return *this;
    }

    // Overloading -= operator for subtraction
    Binary &operator-=(const Binary &other)
    {
        int diff = to_Decimal(binaryString, base) - to_Decimal(other.binaryString, other.base);
        binaryString = to_Binary(diff, base);
        return *this;
    }

    // Overloading * operator for multiplication (Convert to base 10 multiply and convert back into base 2)
    Binary operator*(const Binary &other) const
    {
        Binary temp;
        temp.binaryString = to_Binary(to_Decimal(this->binaryString, this->base) * to_Decimal(other.binaryString, other.base));
        return temp;
    }

    // Overloading / operator for division  (Convert to base 10 divide and convert back into base 2)
    Binary operator/(const Binary &other) const
    {
        Binary temp;
        temp.binaryString = to_Binary(to_Decimal(this->binaryString, this->base) / to_Decimal(other.binaryString, other.base));
        return temp;
    }

    // Overloading % operator for modulus  (Convert to base 10 modulus and convert back into base 2)
    Binary operator%(const Binary &other) const
    {
        Binary temp;
        temp.binaryString = to_Binary(to_Decimal(this->binaryString, this->base) % to_Decimal(other.binaryString, other.base));
        return temp;
    }

    // Overloading | operator for or
    Binary operator|(const Binary &other) const
    {
        int maxLen;
        if (length(this->binaryString) > length(other.binaryString))
        {
            maxLen = length(this->binaryString);
        }
        else
        {
            maxLen = length(other.binaryString);
        }
        string pad1 = pad(binaryString, maxLen);
        string pad2 = pad(other.binaryString, maxLen);

        string resultBinaryString = "";
        for (int i = 0; i < maxLen; i++)
        {
            if (pad1[i] == '1' || pad2[i] == '1')
            {
                resultBinaryString += '1';
            }
            else
            {
                resultBinaryString += '0';
            }
        }

        Binary result;
        result.binaryString = resultBinaryString;
        return result;
    }

    // Overloading ^ operator for xor
    Binary operator^(const Binary &other) const
    {
        int maxLen;
        if (length(this->binaryString) > length(other.binaryString))
        {
            maxLen = length(this->binaryString);
        }
        else
        {
            maxLen = length(other.binaryString);
        }
        string pad1 = pad(binaryString, maxLen);
        string pad2 = pad(other.binaryString, maxLen);

        string resultBinaryString = "";
        for (int i = 0; i < maxLen; i++)
        {
            if (pad1[i] == pad2[i])
            {
                resultBinaryString += '1';
            }
            else
            {
                resultBinaryString += '0';
            }
        }

        Binary result;
        result.binaryString = resultBinaryString;
        return result;
    }

    // Overloading & operator for and
    Binary operator&(const Binary &other) const
    {
        int maxLen;
        if (length(this->binaryString) > length(other.binaryString))
        {
            maxLen = length(this->binaryString);
        }
        else
        {
            maxLen = length(other.binaryString);
        }
        string pad1 = pad(binaryString, maxLen);
        string pad2 = pad(other.binaryString, maxLen);

        string resultBinaryString = "";
        for (int i = 0; i < maxLen; i++)
        {
            if (pad1[i] == '1' && pad2[i] == '1')
            {
                resultBinaryString += '1';
            }
            else
            {
                resultBinaryString += '0';
            }
        }

        Binary result;
        result.binaryString = resultBinaryString;
        return result;
    }

    // Overloading ! operator for 2's Compliment
    Binary operator!() const
    {
        Binary oComp = ~(*this);
        return oComp + Binary("1");
    }

    // Overloading ~ operator for 1's Compliment
    Binary operator~() const
    {
        Binary temp;
        for (int i = 0; i < length(this->binaryString); i++)
        {
            if (this->binaryString[i] == '1')
            {
                temp.binaryString += '0';
            }
            else
            {
                temp.binaryString += '1';
            }
        }
        return temp;
    }

    // Overloading left shift operator
    Binary operator<<(int shiftAmount) const
    {
        if (shiftAmount >= length(this->binaryString))
        {
            return Binary("0");
        }
        Binary temp;
        for (int i = shiftAmount; i < length(this->binaryString); i++)
        {
            temp.binaryString += this->binaryString;
        }
        for (int i = 0; i < shiftAmount; i++)
        {
            temp.binaryString += '0';
        }
        return temp;
    }

    // Overloading right shift operator
    Binary operator>>(int shiftAmount) const
    {
        Binary temp = *this;

        if (shiftAmount >= length(temp.binaryString))
        {
            return Binary("0");
        }

        temp.binaryString = substr(temp.binaryString, 0, shiftAmount);

        while (length(temp.binaryString) < length(this->binaryString))
        {
            temp.binaryString = '0' + temp.binaryString;
        }

        return temp;
    }

    // Overloading input operator
    friend istream &operator>>(istream &input, Binary &other)
    {
        string inputString;
        input >> inputString;
        other = Binary(inputString);
        return input;
    }

    // Overloading output operator (Display Both Binary as well as Integer value)
    friend ostream &operator<<(ostream &output, const Binary &other)
    {
        output << "Binary: " << other.binaryString << ", Integer: " << to_Decimal(other.binaryString, other.base);
        return output;
    }
};
int main()
{
    Binary binary1("1010", 2);
    cout << "Binary 1: " << binary1 << endl;

    Binary binary2("1100", 2);
    Binary sum = binary1 + binary2;
    cout << "Binary 1 + Binary 2: " << sum << endl;

    Binary difference = binary1 - binary2;
    cout << "Binary 1 - Binary 2: " << difference << endl;

    Binary binary3("11", 2);
    Binary product = binary1 * binary3;
    cout << "Binary 1 * Binary 3: " << product << endl;

    Binary binary4("10", 2);
    Binary quotient = binary1 / binary4;
    cout << "Binary 1 / Binary 4: " << quotient << endl;

    Binary binary5("11", 2);
    Binary remainder = binary1 % binary5;
    cout << "Binary 1 % Binary 5: " << remainder << endl;

    Binary binary6("1100", 2);
    Binary bitwiseOr = binary1 | binary6;
    cout << "Binary 1 | Binary 6: " << bitwiseOr << endl;

    Binary binary7("1010", 2);
    Binary bitwiseXor = binary1 ^ binary7;
    cout << "Binary 1 ^ Binary 7: " << bitwiseXor << endl;

    Binary bitwiseNot = ~binary1;
    cout << "Bitwise NOT of Binary 1: " << bitwiseNot << endl;

    int shiftAmount = 2;
    Binary leftShifted = binary1 << shiftAmount;
    cout << "Left shift of Binary 1 by " << shiftAmount << " bits: " << leftShifted << endl;

    Binary rightShifted = binary1 >> shiftAmount;
    cout << "Right shift of Binary 1 by " << shiftAmount << " bits: " << rightShifted << endl;

    return 0;
}
