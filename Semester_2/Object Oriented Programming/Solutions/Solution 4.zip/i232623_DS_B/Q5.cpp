// Muhammad Muneeb Lone | 23i-2623 | Assignment #4
#include <iostream>
using namespace std;

class Time
{
private:
    // You will need three integer data members to store the hours, minutes, and seconds.
    int hours;
    int minutes;
    int seconds;

public:
    Time(int hours = 0, int minutes = 0, int seconds = 0)
    {
        this->hours = hours;
        this->minutes = minutes;
        this->seconds = seconds;
        while (this->seconds >= 60)
        {
            this->seconds -= 60;
            this->minutes++;
        }
        while (this->minutes >= 60)
        {
            this->minutes -= 60;
            this->hours++;
        }
    }
    Time(const Time &copy) // copy constructor
    {
        this->hours = copy.hours;
        this->minutes = copy.minutes;
        this->seconds = copy.seconds;
    }
    // Binary Operators
    // Arithmetic Operators
    Time operator+(const Time &val) const
    {
        Time temp;
        temp.hours = hours + val.hours;
        temp.minutes = minutes + val.minutes;
        temp.seconds = seconds + val.seconds;
        while (temp.seconds >= 60)
        {
            temp.seconds -= 60;
            temp.minutes++;
        }
        while (temp.minutes >= 60)
        {
            temp.minutes -= 60;
            temp.hours++;
        }
        return temp;
    }
    Time operator-(const Time &val) const
    {
        Time temp;
        temp.hours = hours - val.hours;
        temp.minutes = minutes - val.minutes;
        temp.seconds = seconds - val.seconds;
        while (temp.seconds < 0)
        {
            temp.seconds += 60;
            temp.minutes--;
        }
        while (temp.minutes < 0)
        {
            temp.minutes += 60;
            temp.hours--;
        }
        while (temp.hours < 0)
        {
            temp.hours += 12;
        }
        return temp;
    }
    // Compound Assignment Operators
    Time &operator+=(const Time &rhs)
    {
        hours += rhs.hours;
        minutes += rhs.minutes;
        seconds += rhs.seconds;
        while (seconds >= 60)
        {
            seconds -= 60;
            minutes++;
        }
        while (minutes >= 60)
        {
            minutes -= 60;
            hours++;
        }
        return *this;
    }
    Time &operator-=(const Time &rhs)
    {
        hours -= rhs.hours;
        minutes -= rhs.minutes;
        seconds -= rhs.seconds;
        while (seconds < 0)
        {
            seconds += 60;
            minutes--;
        }
        while (minutes < 0)
        {
            minutes += 60;
            hours--;
        }
        while (hours < 0)
        {
            hours += 12;
        }
        return *this;
    }
    // Logical Operators
    bool operator==(const Time &val) const
    {
        if (hours == val.hours && minutes == val.minutes && seconds == val.seconds)
        {
            return true;
        }
        return false;
    }
    bool operator!=(const Time &val) const
    {
        if (hours != val.hours || minutes != val.minutes || seconds != val.seconds)
        {
            return true;
        }
        return false;
    }
    bool operator<(const Time &val) const
    {
        if (hours < val.hours)
        {
            return true;
        }
        if (minutes < val.minutes)
        {
            return true;
        }
        if (seconds < val.seconds)
        {
            return true;
        }
        return false;
    }
    bool operator<=(const Time &val) const
    {
        if (hours == val.hours && minutes == val.minutes && seconds == val.seconds)
        {
            return true;
        }
        if (hours < val.hours)
        {
            return true;
        }
        if (minutes < val.minutes)
        {
            return true;
        }
        if (seconds < val.seconds)
        {
            return true;
        }
        return false;
    }
    bool operator>(const Time &val) const
    {
        if (hours > val.hours)
        {
            return true;
        }
        if (minutes > val.minutes)
        {
            return true;
        }
        if (seconds > val.seconds)
        {
            return true;
        }
        return false;
    }
    bool operator>=(const Time &val) const
    {
        if (hours == val.hours && minutes == val.minutes && seconds == val.seconds)
        {
            return true;
        }
        if (hours > val.hours)
        {
            return true;
        }
        if (minutes > val.minutes)
        {
            return true;
        }
        if (seconds > val.seconds)
        {
            return true;
        }
        return false;
    }
    // Additional Functions
    Time elapsedTime() const // Calculate elapsed time
    {
        time_t currentTime = time(nullptr);
        struct tm *now = localtime(&currentTime);

        int currentHours = now->tm_hour;
        int currentMinutes = now->tm_min;
        int currentSeconds = now->tm_sec;

        int totalSeconds = (currentHours * 3600 + currentMinutes * 60 + currentSeconds) - (hours * 3600 + minutes * 60 + seconds);

        if (totalSeconds < 0)
            totalSeconds *= -1;

        int elapsedHours = totalSeconds / 3600;
        int elapsedMinutes = (totalSeconds % 3600) / 60;
        int elapsedSeconds = (totalSeconds % 3600) % 60;

        return Time(elapsedHours, elapsedMinutes, elapsedSeconds);
    }
    ~Time() // destructor
    {
        // Unnecessary as no dynamic memory allocation
        cout << "Destructor called\n";
    }
    friend ostream &operator<<(ostream &output, const Time &val) // outputs the Time
    {
        output << "Hours: " << val.hours << endl;
        output << "Minutes: " << val.minutes << endl;
        output << "Seconds: " << val.seconds << endl;
        return output;
    }

    friend istream &operator>>(istream &input, Time &val) // inputs the Time
    {
        cout << "Enter Hours, Minutes and Seconds: \n";
        input >> val.hours >> val.minutes >> val.seconds;
        return input;
    }
};

int main()
{
    Time t1(5, 180, 45);
    Time t2(3, 20, 15);

    cout << "Time 1: \n"
         << t1 << endl;
    cout << "Time 2: \n"
         << t2 << endl;

    cout << "Adding Time 1 and Time 2: \n";
    Time t3 = t1 + t2;
    cout << t3 << endl;

    cout << "Subtracting Time 2 from Time 1: \n";
    Time t4 = t1 - t2;
    cout << t4 << endl;

    cout << "Adding 2 hours, 10 minutes, and 20 seconds to Time 1: \n";
    t1 += Time(2, 10, 20);
    cout << t1 << endl;

    cout << "Subtracting 1 hour, 15 minutes, and 10 seconds from Time 2: \n";
    t2 -= Time(1, 15, 10);
    cout << t2 << endl;

    cout << "Comparing Time 1 and Time 2: \n";
    if (t1 == t2)
    {
        cout << "Time 1 and Time 2 are equal.\n";
    }
    else if (t1 < t2)
    {
        cout << "Time 1 is less than Time 2.\n";
    }
    else
    {
        cout << "Time 1 is greater than Time 2.\n";
    }

    cout << "Elapsed time between Time 1 and Current Time: \n";
    Time elapsed = t1.elapsedTime();
    cout << elapsed << endl;

    cout << "Elapsed time between Time 2 and Current Time: \n";
    Time elapsed1 = t2.elapsedTime();
    cout << elapsed1 << endl;

    return 0;
}
