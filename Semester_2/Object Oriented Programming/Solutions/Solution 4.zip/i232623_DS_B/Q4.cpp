// Muhammad Muneeb Lone | 23i-2623 | Assignment #4
#include <iostream>
using namespace std;

int gcd(int a, int b);
int lcm(int a, int b);
void bubbleSort(int *array, int size);

class Set
{
private:
    // You will need an array to store the elements of the set.
    // You will also need a variable to keep track of the size of the array.
    int *elements;
    int size;

public:
    Set() : size(0), elements(nullptr) {}
    Set(const int *elems, int sz) : size(sz)
    {
        elements = new int[size];
        for (int i = 0; i < size; i++)
        {
            elements[i] = elems[i];
        }
        bubbleSort(elements, size);
    }
    Set(const Set &copy) : size(copy.size) // copy constructor
    {
        elements = new int[size];
        for (int i = 0; i < size; i++)
        {
            elements[i] = copy.elements[i];
        }
        bubbleSort(elements, size);
    }
    // Binary Operators
    // Set Operators
    Set operator+(const Set &val) const // Union
    {
        Set temp;
        temp.size = this->size + val.size;
        temp.elements = new int[temp.size];
        for (int i = 0; i < this->size; i++)
        {
            temp.elements[i] = this->elements[i];
        }
        for (int i = 0; i < val.size; i++)
        {
            temp.elements[i + this->size] = val.elements[i];
        }
        bubbleSort(temp.elements, temp.size);
        return temp;
    }
    Set operator*(const Set &val) const // Intersection
    {
        Set temp;
        int *newElements = new int[min(this->size, val.size)];
        int k = 0;
        for (int i = 0; i < this->size; i++)
        {
            for (int j = 0; j < val.size; j++)
            {
                if (this->elements[i] == val.elements[j])
                {
                    newElements[k++] = this->elements[i];
                    break;
                }
            }
        }
        temp.elements = newElements;
        temp.size = k;
        return temp;
    }
    Set operator-(const Set &val) const // Difference
    {
        Set temp;
        int *newElements = new int[this->size];
        int k = 0;
        for (int i = 0; i < this->size; i++)
        {
            bool found = false;
            for (int j = 0; j < val.size; j++)
            {
                if (this->elements[i] == val.elements[j])
                {
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                newElements[k++] = this->elements[i];
            }
        }
        temp.elements = newElements;
        temp.size = k;
        return temp;
    }
    Set &operator+=(const Set &rhs) // Union Assignment
    {
        int newSize = this->size + rhs.size;
        int *newElements = new int[newSize];
        for (int i = 0; i < this->size; i++)
        {
            newElements[i] = this->elements[i];
        }
        for (int i = 0; i < rhs.size; i++)
        {
            newElements[i + this->size] = rhs.elements[i];
        }
        delete[] this->elements;
        this->elements = newElements;
        this->size = newSize;
        bubbleSort(this->elements, this->size);
        return *this;
    }
    Set &operator*=(const Set &rhs) // Intersection Assignment
    {
        int newSize = this->size;
        int *newElements = new int[newSize];
        int k = 0;
        for (int i = 0; i < this->size; i++)
        {
            for (int j = 0; j < rhs.size; j++)
            {
                if (this->elements[i] == rhs.elements[j])
                {
                    newElements[k++] = this->elements[i];
                    break;
                }
            }
        }
        delete[] this->elements;
        this->elements = newElements;
        this->size = k;
        bubbleSort(this->elements, this->size);
        return *this;
    }
    Set &operator-=(const Set &rhs) // Difference Assignment
    {
        int *newElements = new int[this->size];
        int k = 0;
        for (int i = 0; i < this->size; i++)
        {
            bool found = false;
            for (int j = 0; j < rhs.size; j++)
            {
                if (this->elements[i] == rhs.elements[j])
                {
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                newElements[k++] = this->elements[i];
            }
        }
        delete[] this->elements;
        this->elements = newElements;
        this->size = k;
        bubbleSort(this->elements, this->size);
        return *this;
    }
    // Logical Operators
    bool operator==(const Set &val) const
    {
        if (this->size != val.size)
        {
            return false;
        }
        for (int i = 0; i < this->size; i++)
        {
            if (this->elements[i] != val.elements[i])
            {
                return false;
            }
        }
        return true;
    }
    bool operator!=(const Set &val) const
    {
        return !(*this == val);
    }
    //  Functional Operators
    Set &operator>(Set &rhs) // Sort the elements in the set
    {
        bubbleSort(this->elements, this->size);
        return *this;
    }
    int &operator[](int element) // Access element at index
    {
        return this->elements[element];
    }
    bool operator()(int element) const // Check if element is in the set
    {
        for (int i = 0; i < this->size; i++)
        {
            if (elements[i] == element)
            {
                return true;
            }
        }
        return false;
    }
    bool operator()(int element, int dummy) // Add element to the set if it is not already in set, The dumy element to differenciate from the other operator
    {
        if (!(*this)(element))
        {
            int *newElements = new int[this->size + 1];
            for (int i = 0; i < this->size; i++)
            {
                newElements[i] = this->elements[i];
            }
            newElements[this->size] = element;
            delete[] this->elements;
            this->elements = newElements;
            this->size++;
            bubbleSort(this->elements, this->size);
            return true;
        }
        return false;
    }
    bool operator()(int element, int dummy, int dummy2) // Add element to the set if it is not already in set and element is lcm between any to numbers of the set,
    // Two dumy elements to differenciate from the other operator
    {
        if (!(*this)(element) && dummy2 == 0)
        {
            for (int i = 0; i < this->size; i++)
            {
                for (int j = i + 1; j < this->size; j++)
                {
                    if (lcm(this->elements[i], this->elements[j]) == element)
                    {
                        int *newElements = new int[this->size + 1];
                        for (int k = 0; k < this->size; k++)
                        {
                            newElements[k] = this->elements[k];
                        }
                        newElements[this->size] = element;
                        delete[] this->elements;
                        this->elements = newElements;
                        this->size++;
                        bubbleSort(this->elements, this->size);
                        return true;
                    }
                }
            }
        }
        return false;
    }
    // Additional Functions for functional operators
    int find(int element) const
    {
        for (int i = 0; i < this->size; i++)
        {
            if (this->elements[i] == element)
            {
                return i;
            }
        }
        return -1;
    }
    void display()
    {
        cout << "\nThe Set is: \n";
        for (int i = 0; i < this->size; i++)
        {
            cout << this->elements[i] << " ";
        }
        cout << endl;
    }
    ~Set()
    {
        delete[] this->elements;
    }

    friend ostream &operator<<(ostream &output, const Set &val)
    {
        output << "{";
        for (int i = 0; i < val.size; i++)
        {
            output << val.elements[i];
            if (i != val.size - 1)
            {
                output << " , ";
            }
        }
        output << "}";
        return output;
    }

    friend istream &operator>>(istream &input, Set &val) // inputs the Set
    {
        input >> val.size;
        val.elements = new int[val.size];
        for (int i = 0; i < val.size; i++)
        {
            input >> val.elements[i];
        }
        return input;
    }
};

int gcd(int a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

int lcm(int a, int b)
{
    return (a * b) / gcd(a, b);
}

void bubbleSort(int *array, int size)
{
    for (int step = 0; step < (size - 1); ++step)
    {
        int swapped = 0;
        for (int i = 0; i < (size - step - 1); ++i)
        {
            if (array[i] > array[i + 1])
            {
                int temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
                swapped = 1;
            }
        }
        if (swapped == 0)
            break;
    }
}
int main()
{
    int arr1[] = {0, 1, 2, 3, 4};
    int arr2[] = {3, 4, 5, 6, 7};
    Set set1(arr1, 5);
    Set set2(arr2, 5);

    cout << "Set 1: " << set1 << endl;
    cout << "Set 2: " << set2 << endl;

    Set set3 = set1;
    cout << "Copied: " << set3 << endl;

    Set unionSet = set1 + set2;
    cout << "Union: " << unionSet << endl;

    Set intersectSet = set1 * set2;
    cout << "Intersection: " << intersectSet << endl;

    Set diffSet = set1 - set2;
    cout << "Difference: " << diffSet << endl;

    Set set4 = set1;
    set4 += set2;
    cout << "Set 1 += Set 2: " << set4 << endl;

    Set set5 = set1;
    set5 *= set2;
    cout << "Set 1 *= Set 2: " << set5 << endl;

    Set set6 = set1;
    set6 -= set2;
    cout << "Set 1 -= Set 2: " << set6 << endl;

    cout << "Set 1 == Set 2: " << (set1 == set2) << endl;
    cout << "Set 1 != Set 2: " << (set1 != set2) << endl;

    Set set7 = set1;
    cout << "Adding 10 to Set 1: " << (set7(10, 0)) << endl;
    cout << "Adding 21 to Set 1 if lcm: " << (set7(21, 0, 0)) << endl;
    cout << "Updated Set 1: " << set7 << endl;

    cout << "Element at index 2 of set 1: " << set1[2] << endl;

    cout << "Index of element 8 in set 1: " << set1.find(8) << endl;

    cout << "Displaying set 1: ";
    set1.display();

    return 0;
}
