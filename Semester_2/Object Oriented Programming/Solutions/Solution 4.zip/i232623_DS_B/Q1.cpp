// Muhammad Muneeb Lone | 23i-2623 | Assignment #4
#include <iostream>
#include <string>
#include <cstring>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;

class Car
{
private:
    string name;
    int year;
    double sellingPrice;
    int kmDriven;
    string fuel;
    string sellerType;
    string transmission;
    int owner;
    double mileage;
    double engine;
    double maxPower;
    double torque;
    int seats;

public:
    // Default Constructor
    Car()
        : name(""), year(0), sellingPrice(0.0), kmDriven(0), fuel(""), sellerType(""), transmission(""), owner(0), mileage(0.0), engine(0.0), maxPower(0.0), torque(0.0), seats(0) {}
    // Constructor
    Car(string n, int y, double sp, int km, string f, string st, string tr, int own, double ml, double eng, double mp, double tq, int s)
        : name(n), year(y), sellingPrice(sp), kmDriven(km), fuel(f), sellerType(st), transmission(tr), owner(own), mileage(ml), engine(eng), maxPower(mp), torque(tq), seats(s) {}

    // Getters and Setters
    string getName() const
    {
        return name;
    }
    int getYear() const
    {
        return year;
    }
    int getKmDriven() const
    {
        return kmDriven;
    }
    string getFuel() const
    {
        return fuel;
    }
    string getSellerType() const
    {
        return sellerType;
    }
    string getTransmission() const
    {
        return transmission;
    }
    int getOwner() const
    {
        return owner;
    }
    double getEngine() const
    {
        return engine;
    }
    int getSeats()
    {
        return seats;
    }

    double getSellingPrice() const
    {
        return sellingPrice;
    }

    double getMaxPower() const
    {
        return maxPower;
    }

    double getMileage() const
    {
        return mileage;
    }

    double getTorque() const
    {
        return torque;
    }
    // Overloading + operator to combine details of 2 cars i.e. Add their SellingPrice, Mileage, Engine, MaxPower, Torque, Assign name with your name Take the rest for 1st Car
    Car operator+(const Car &other) const
    {
        Car newCar("Muneeb Lone", this->year, this->sellingPrice + other.sellingPrice, this->kmDriven, this->fuel, this->sellerType, this->transmission, this->owner, this->mileage + other.mileage, this->engine + other.engine, this->maxPower + other.maxPower, this->torque + other.torque, this->seats);

        return newCar;
    }

    // Overloading += operator to combine details of 2 cars i.e. Add their SellingPrice, Mileage, Engine, MaxPower, Torque
    Car &operator+=(const Car &other)
    {
        this->sellingPrice += other.sellingPrice;
        this->mileage += other.mileage;
        this->engine += other.engine;
        this->maxPower += other.maxPower;
        this->torque += other.torque;

        return *this;
    }

    // Overloading - operator to subtract selling prices of two cars
    double operator-(const Car &other) const
    {
        double diff = this->sellingPrice - other.sellingPrice;
        return diff;
    }

    // Overloading -= operator to subtract details of 2 cars i.e. subtract their SellingPrice, Mileage, Engine, MaxPower, Torque
    Car &operator-=(const Car &other)
    {

        this->sellingPrice -= other.sellingPrice;
        this->mileage -= other.mileage;
        this->engine -= other.engine;
        this->maxPower -= other.maxPower;
        this->torque -= other.torque;

        return *this;
    }

    // Overloading == operator to compare details of two cars
    bool operator==(const Car &other) const
    {

        if (this->name == other.name && this->year == other.year && this->sellingPrice == other.sellingPrice && this->kmDriven == other.kmDriven && this->fuel == other.fuel && this->sellerType == other.sellerType && this->transmission == other.transmission && this->owner == other.owner && this->mileage == other.mileage && this->engine == other.engine && this->maxPower == other.maxPower && this->torque == other.torque && this->seats == other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading > operator to compare details of (int, float and Double Datatype)
    bool operator>(const Car &other) const
    {
        if (this->year > other.year && this->sellingPrice > other.sellingPrice && this->kmDriven > other.kmDriven && this->owner > other.owner && this->mileage > other.mileage && this->engine > other.engine && this->maxPower > other.maxPower && this->torque > other.torque && this->seats > other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading < operator to compare details of (int, float and Double Datatype)
    bool operator<(const Car &other) const
    {
        if (this->year < other.year && this->sellingPrice < other.sellingPrice && this->kmDriven < other.kmDriven && this->owner < other.owner && this->mileage < other.mileage && this->engine < other.engine && this->maxPower < other.maxPower && this->torque < other.torque && this->seats < other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading >= operator to compare details of (int, float and Double Datatype)
    bool operator>=(const Car &other) const
    {

        if (this->year >= other.year && this->sellingPrice >= other.sellingPrice && this->kmDriven >= other.kmDriven && this->owner >= other.owner && this->mileage >= other.mileage && this->engine >= other.engine && this->maxPower >= other.maxPower && this->torque >= other.torque && this->seats >= other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading <= operator to compare details of (int, float and Double Datatype)
    bool operator<=(const Car &other) const
    {

        if (this->year <= other.year && this->sellingPrice <= other.sellingPrice && this->kmDriven <= other.kmDriven && this->owner <= other.owner && this->mileage <= other.mileage && this->engine <= other.engine && this->maxPower <= other.maxPower && this->torque <= other.torque && this->seats <= other.seats)
        {
            return true;
        }
        return false;
    }

    // Overloading != operator to compare details of (int, float and Double Datatype)
    bool operator!=(const Car &other) const
    {

        if (this->year != other.year && this->sellingPrice != other.sellingPrice && this->kmDriven != other.kmDriven && this->owner != other.owner && this->mileage != other.mileage && this->engine != other.engine && this->maxPower != other.maxPower && this->torque != other.torque && this->seats != other.seats)
        {
            return true;
        }
        return false;
    }

    // Display car details
    friend ostream &operator<<(ostream &output, const Car &car)
    {
        output << "Name: " << car.name << endl;
        output << "Year: " << car.year << endl;
        output << "Selling Price: " << car.sellingPrice << endl;
        output << "Kilometers Driven: " << car.kmDriven << endl;
        output << "Fuel Type: " << car.fuel << endl;
        output << "Seller Type: " << car.sellerType << endl;
        output << "Transmission: " << car.transmission << endl;
        output << "Owner: " << car.owner << endl;
        output << "Mileage: " << car.mileage << endl;
        output << "Engine: " << car.engine << endl;
        output << "Max Power: " << car.maxPower << endl;
        output << "Torque: " << car.torque << endl;
        output << "Seats: " << car.seats << endl;

        return output;
    }

    // Input Car Details
    friend istream &operator>>(istream &input, Car &car)
    {
        cout << "Enter Name: ";
        input >> car.name;
        cout << "Enter Year: ";
        input >> car.year;
        cout << "Enter Selling Price: ";
        input >> car.sellingPrice;
        cout << "Enter Kilometers Driven: ";
        input >> car.kmDriven;
        cout << "Enter Fuel Type: ";
        input >> car.fuel;
        cout << "Enter Seller Type: ";
        input >> car.sellerType;
        cout << "Enter Transmission Type: ";
        input >> car.transmission;
        cout << "Enter Owner: ";
        input >> car.owner;
        cout << "Enter Mileage: ";
        input >> car.mileage;
        cout << "Enter Engine Size: ";
        input >> car.engine;
        cout << "Enter Max Power: ";
        input >> car.maxPower;
        cout << "Enter Torque: ";
        input >> car.torque;
        cout << "Enter Number of Seats: ";
        input >> car.seats;

        return input;
    }
};

class Garage
{
private:
    Car *cars;
    int numOfCars;

public:
    // Constructor to make cars null
    Garage()
    {
        cars = NULL;
        numOfCars = 0;
    }

    // Destructor to deallocate memory for cars array
    ~Garage()
    {
        delete[] cars;
    }

    // Overloading + operator to Add car using user input use the operator overloading as done in Car Class

    Garage operator+(const Car &other) const
    {
        // Create a new garage object with one more car than the current garage
        Garage newGarage;
        newGarage.numOfCars = numOfCars + 1;

        newGarage.cars = new Car[newGarage.numOfCars];

        for (int i = 0; i < numOfCars; ++i)
        {
            newGarage.cars[i] = cars[i];
        }

        // Add the new car to the end of the new garage
        newGarage.cars[numOfCars] = other;

        return newGarage;
    }

    // Overloading += operator to Add car of another garage
    Garage &operator+=(const Car &other)
    {
        Car *newCars = new Car[numOfCars + 1];

        for (int i = 0; i < numOfCars; ++i)
        {
            newCars[i] = cars[i];
        }

        newCars[numOfCars] = other;

        // Deallocate the old array
        delete[] cars;

        cars = newCars;

        numOfCars++;

        return *this;
    }

    // Overloading - operator to remove car using index
    Garage operator-(int index) const
    {
        Garage newGarage;
        newGarage.numOfCars = this->numOfCars - 1;
        newGarage.cars = new Car[newGarage.numOfCars];
        int k = 0;
        // Copying all elements except the one at index to a new array
        for (int i = 0; i < numOfCars; i++)
        {

            if (i != index)
            {
                newGarage.cars[k++] = cars[i];
            }
            else
            {
                continue;
            }
        }
        return newGarage;
    }

    // Overloading -= operator to remove car using name
    Garage &operator-=(const Car &other)
    {
        Car *newCars = new Car[numOfCars - 1];
        int k = 0;
        for (int i = 0; i < numOfCars; i++)
        {
            if (cars[i].getName() != other.getName())
            {
                newCars[k++] = cars[i];
            }
            else
            {
                continue;
            }
        }

        delete[] cars;

        cars = newCars;

        // Update numOfCars
        numOfCars--;

        return *this;
    }

    // Overloading == operator to compare details of two Garage for each car
    bool operator==(const Garage &other) const
    {
        if (numOfCars != other.numOfCars)
        {
            return false;
        }
        for (int i = 0; i < numOfCars; ++i)
        {
            if (cars[i] != other.cars[i])
            {
                return false;
            }
        }

        return true;
    }

    // Overloading > operator to compare Avg price of 2 garage
    bool operator>(const Garage &other) const
    {
        double avg, otherAvg;
        for (int i = 0; i < numOfCars; i++)
        {
            avg += cars[i].getSellingPrice();
        }
        avg = avg / numOfCars;
        for (int i = 0; i < other.numOfCars; i++)
        {
            otherAvg += other.cars[i].getSellingPrice();
        }
        otherAvg = otherAvg / numOfCars;

        if (avg == otherAvg)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Overloading < operator to average maxPower of cars of 2 garage
    bool operator<(const Garage &other) const
    {
        double power, otherPower;
        for (int i = 0; i < numOfCars; i++)
        {
            power += cars[i].getMaxPower();
        }
        power = power / numOfCars;
        for (int i = 0; i < other.numOfCars; i++)
        {
            otherPower += other.cars[i].getMaxPower();
        }
        otherPower = otherPower / numOfCars;

        if (power == otherPower)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Overloading >= operator to compare Average Mileage of 2 Garage
    bool operator>=(const Garage &other) const
    {
        double mileage, otherMileage;
        for (int i = 0; i < numOfCars; i++)
        {
            mileage += cars[i].getMileage();
        }
        mileage = mileage / numOfCars;
        for (int i = 0; i < other.numOfCars; i++)
        {
            otherMileage += other.cars[i].getMileage();
        }
        otherMileage = otherMileage / numOfCars;

        if (mileage == otherMileage)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Overloading <= operator to compare Average torque of 2 garage
    bool operator<=(const Garage &other) const
    {
        double torque, otherTorque;
        for (int i = 0; i < numOfCars; i++)
        {
            torque += cars[i].getTorque();
        }
        torque = torque / numOfCars;
        for (int i = 0; i < other.numOfCars; i++)
        {
            otherTorque += other.cars[i].getTorque();
        }
        otherTorque = otherTorque / numOfCars;

        if (torque == otherTorque)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    // Overloading != operator to compare No of Cars of 2 garage
    bool operator!=(const Garage &other) const
    {
        if (numOfCars != other.numOfCars)
        {
            return true;
        }
        return false;
    }

    // Display details of all cars in the garage
    friend ostream &operator<<(ostream &output, const Garage &garage)
    {
        for (int i = 0; i < garage.numOfCars; ++i)
        {
            output << "Car " << i + 1 << ":\n";
            output << garage.cars[i] << endl; // Using the << overloaded in Car class
        }
        return output;
    }
};

Car extractCarDetails(const string &line);
double stringToDouble(const string &s);
int countLines(const string &filename);
bool isInteger(const string &s);
double stringToDouble(const string &s);
int stringToInt(const string &s);

int main()
{
    Car car1("Toyota", 2019, 250070.06, 500700, "Petrol", "Dealer", "Automatic", 1, 15.5, 2.0, 150.0, 200.0, 5);
    Car car2("Honda", 2020, 2778000.06, 670000, "Diesel", "Private", "Manual", 2, 18.0, 2.5, 180.0, 220.0, 5);
    Car car3("BMW", 2018, 500700.07, 300600, "Petrol", "Dealer", "Automatic", 1, 12.5, 3.0, 200.0, 250.0, 4);

    Garage garage1;

    // Add cars to the garage
    garage1 += car1;
    garage1 += car2;

    // Display the cars in 1st Garage
    cout << "Cars in garage1:\n";
    cout << garage1 << endl;

    // Second Garage Object
    Garage garage2;
    garage2 += car3;

    // Display the cars in 2nd Garage
    cout << "Cars in garage2:\n";
    cout << garage2 << endl;

    // Checking if Garages are Equal
    if (garage1 == garage2)
    {
        cout << "garage1 is equal to garage2\n";
    }
    else
    {
        cout << "garage1 is not equal to garage2\n";
    }

    // Check if Garage 1 > Garage 2
    if (garage1 > garage2)
    {
        cout << "garage1 > garage2\n";
    }
    else
    {
        cout << "garage1 < garage2\n";
    }

    // Check if Garage 1 < Garage 2
    if (garage1 < garage2)
    {
        cout << "garage1 < garage2\n";
    }
    else
    {
        cout << "garage1 > garage2\n";
    }


    if (garage1 >= garage2)
    {
        cout << "garage1 average mileage greater than or equal to garage2\n";
    }
    else
    {
        cout << "garage1 average mileage not greater than or equal to garage2\n";
    }

    // Check if garage1 has average torque less than or equal to garage2
    if (garage1 <= garage2)
    {
        cout << "garage1 average torque less than or equal to garage2\n";
    }
    else
    {
        cout << "garage1 average torque not less than or equal to garage2\n";
    }

    // Check if garage1 is not equal to garage2
    if (garage1 != garage2)
    {
        cout << "garage1 is not equal to garage2\n";
    }
    else
    {
        cout << "garage1 is equal to garage2\n";
    }

    cout << "---------------------------------RANDOM FUNCTION USE-------------------------------------------\n";
    srand(time(nullptr));
    string filename = "Car details v3.csv";
    int numLines = countLines(filename);
    // Generate a random line number
    int randomLine = rand() % numLines + 1;

    ifstream file(filename);
    if (!file.is_open())
    {
        cerr << "Error: Unable to open file." << endl;
        return 0;
    }

    // Read lines until the random line
    string line;
    int currentLine = 0;
    while (getline(file, line) && currentLine < randomLine)
    {
        currentLine++;
    }
    Car car = extractCarDetails(line);

    file.close();

    cout << car;

    return 0;
}

int countLines(const string &filename)
{
    ifstream file(filename);
    if (!file.is_open())
    {
        cout << "Unable to open file." << endl;
        return 0;
    }

    int count = 0;
    string line;
    while (getline(file, line))
    {
        count++;
    }

    file.close();
    return count;
}
bool isInteger(const string &s)
{
    for (char c : s)
    {
        if (!isdigit(c))
        {
            return false;
        }
    }
    return true;
}
int stringToInt(const string &s)
{
    int result = 0;
    for (int i = 0; i < s.length(); ++i)
    {
        if (isdigit(s[i]))
        {
            result = result * 10 + (s[i] - '0');
        }
    }
    return result;
}

double stringToDouble(const string &s)
{
    double result = 0.0;
    double decimal = 0.1;
    bool decimalPart = false;
    for (int i = 0; i < s.length(); ++i)
    {
        if (isdigit(s[i]))
        {
            if (!decimalPart)
            {
                result = result * 10 + (s[i] - '0');
            }
            else
            {
                result = result + (decimal * (s[i] - '0'));
                decimal *= 0.1;
            }
        }
        else if (s[i] == '.')
        {
            decimalPart = true;
        }
    }
    return result;
}
Car extractCarDetails(const string &line)
{
    stringstream ss(line);
    string token;
    getline(ss, token, ','); // Name
    string name = token;
    getline(ss, token, ','); // Year
    int year = isInteger(token) ? stringToInt(token) : 0;
    getline(ss, token, ','); // Selling price
    double sellingPrice = stringToDouble(token);
    getline(ss, token, ','); // Kilometers driven
    int kmDriven = isInteger(token) ? stringToInt(token) : 0;
    getline(ss, token, ','); // Fuel
    string fuel = token;
    getline(ss, token, ','); // Seller type
    string sellerType = token;
    getline(ss, token, ','); // Transmission
    string transmission = token;
    getline(ss, token, ','); // Owner
    int owner = isInteger(token) ? stringToInt(token) : 0;
    getline(ss, token, ','); // Mileage
    double mileage = stringToDouble(token);
    getline(ss, token, ','); // Engine
    double engine = stringToDouble(token);
    getline(ss, token, ','); // Max power
    double maxPower = stringToDouble(token);
    getline(ss, token, ','); // Torque
    double torque = stringToDouble(token);
    getline(ss, token); // Seats
    int seats = isInteger(token) ? stringToInt(token) : 0;

    return Car(name, year, sellingPrice, kmDriven, fuel, sellerType, transmission, owner, mileage, engine, maxPower, torque, seats);
}
