// Muhammad Muneeb Lone | 23i-2623 | Assignment #4
#include <iostream>
#include <string>

using namespace std;

int length(string const str)
{
    int i = 0;
    while (str[i] != '\0')
    {
        i++;
    }
    return i;
}

string substr(string const str, int startPos)
{
    string temp;
    int i = 0;
    while (str[i] != '\0')
    {
        temp += str[i];
        i++;
    }
    return temp;
}

string substr(string const str, int startPos, int endPos)
{
    string temp;
    if (startPos > endPos || startPos < 0 || endPos >= length(str))
    {
        return temp;
    }
    for (int i = startPos; i <= endPos; i++)
    {
        temp += str[i];
    }
    return temp;
}

int find(string const str, char toFind = '.')
{
    for (int i = 0; i < length(str); i++)
    {
        if (str[i] == toFind)
        {
            return i;
        }
    }
    return -1;
}
int str_int(const string &str)
{
    int result = 0;
    bool isNegative = false;

    int i = 0;
    if (str[0] == '-')
    {
        isNegative = true;
        i = 1;
    }

    for (; i < length(str); ++i)
    {
        if (str[i] >= '0' && str[i] <= '9')
        {
            result = result * 10 + (str[i] - '0');
        }
    }

    // Apply negative sign if necessary
    if (isNegative)
    {
        result *= -1;
    }

    return result;
}
string int_str(int num)
{
    if (num == 0)
    {
        return "0";
    }

    string result = "";
    bool isNegative = false;

    // Check if the number is negative
    if (num < 0)
    {
        isNegative = true;
        num = -num; // Make it positive
    }

    while (num > 0)
    {
        char digit = '0' + num % 10; // Extract the least significant digit
        result = digit + result;     // Add the digit to the result
        num /= 10;                   // Move to the next digit
    }
    if (isNegative)
    {
        result = "-" + result;
    }

    return result;
}
double str_double(const string &str)
{
    double result = 0;
    bool isNegative = false;

    int i = 0;
    if (str[0] == '-')
    {
        isNegative = true;
        i = 1;
    }

    for (; i < length(str); ++i)
    {
        if (str[i] >= '0' && str[i] <= '9')
        {
            result = result * 10 + (str[i] - '0');
        }
    }

    // Apply negative sign if necessary
    if (isNegative)
    {
        result *= -1;
    }

    return result;
}
string integerpart(string const str)
{
    string cut = "";
    for (int i = 0; str[i] != '.'; i++)
    {
        cut += str[i];
    }
    return cut;
}
string decimalpart(string const str)
{
    string cut = "";
    for (int i = length(integerpart(str)); i < length(str); i++)
    {
        cut += str[i];
    }
    return cut;
}

class BigFloat
{

    string integer;
    string fraction;
    bool sign;
    int precision;

public:
    BigFloat(double val = 0.0, int precision = 2) : integer(""), fraction(""), sign(false) {}
    BigFloat(const string &text, int precision = 2)
    {
        if (text[0] == '-')
        {
            this->sign = true; // negative is true
        }
        else
        {
            this->sign = false;
        }
        this->integer = substr(text, 1, find(text));
        this->fraction = substr(text, find(text));
        this->precision = precision;
    }
    BigFloat(const BigFloat &copy) // copy constructor
    {
        integer = copy.integer;
        fraction = copy.fraction;
        sign = copy.sign;
        precision = copy.precision;
    }
    // Binary Operators
    // Arithmetic Operators
    BigFloat operator+(const BigFloat &val) const
    {
        BigFloat temp;
        if (val.precision > this->precision)
        {
            temp.precision = this->precision;
        }
        else
        {
            temp.precision = val.precision;
        }
        temp.integer = int_str(str_int(this->integer) + str_int(val.integer));
        temp.fraction = int_str(str_int(this->fraction) + str_int(val.fraction));
        if (temp.integer[0] == '-')
        {
            temp.sign = true;
        }

        string cut = "";
        if (precision <= length(temp.fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += temp.fraction[i];
            }
        }
        else
        {
            for (int i = length(temp.fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        temp.fraction = cut;
        return temp;
    }
    BigFloat operator-(const BigFloat &val) const
    {
        BigFloat temp;
        if (val.precision > this->precision)
        {
            temp.precision = this->precision;
        }
        else
        {
            temp.precision = val.precision;
        }
        temp.integer = int_str(str_int(this->integer) - str_int(val.integer));
        temp.fraction = int_str(str_int(this->fraction) - str_int(val.fraction));
        if (temp.integer[0] == '-')
        {
            temp.sign = true;
        }

        string cut = "";
        if (precision <= length(temp.fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += temp.fraction[i];
            }
        }
        else
        {
            for (int i = length(temp.fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        temp.fraction = cut;
        return temp;
    }

    BigFloat operator*(const BigFloat &val) const
    {
        BigFloat temp;
        if (val.precision > this->precision)
        {
            temp.precision = this->precision;
        }
        else
        {
            temp.precision = val.precision;
        }
        string whole1 = "", whole2 = "";
        whole1 = this->integer + '.' + this->fraction;
        whole2 = val.integer + '.' + val.fraction;
        string ans = int_str(str_double(whole1) * str_double(whole2));
        temp.integer = integerpart(ans);
        temp.fraction = decimalpart(ans);
        if (temp.integer[0] == '-')
        {
            temp.sign = true;
        }
        string cut;
        if (precision <= length(temp.fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += temp.fraction[i];
            }
        }
        else
        {
            for (int i = length(temp.fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        temp.fraction = cut;
        return temp;
    }
    BigFloat operator/(const BigFloat &val) const
    {
        BigFloat temp;
        if (str_int(val.integer) == 0 && str_int(val.fraction) == 0)
        {
            cout << "Error. Cannot Divide By Zero. Return Original Float\n";
            return *this;
        }
        if (val.precision > this->precision)
        {
            temp.precision = this->precision;
        }
        else
        {
            temp.precision = val.precision;
        }
        string whole1 = "", whole2 = "";
        whole1 = this->integer + '.' + this->fraction;
        whole2 = val.integer + '.' + val.fraction;
        string ans = int_str(str_double(whole1) / str_double(whole2));
        temp.integer = integerpart(ans);
        temp.fraction = decimalpart(ans);
        if (temp.integer[0] == '-')
        {
            temp.sign = true;
        }
        string cut;
        if (precision <= length(temp.fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += temp.fraction[i];
            }
        }
        else
        {
            for (int i = length(temp.fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        temp.fraction = cut;
        return temp;
    }
    BigFloat operator%(const BigFloat &val) const // Modulus Operator
    {
        BigFloat temp;
        if (str_int(val.integer) == 0 && str_int(val.fraction) == 0)
        {
            cout << "Error. Cannot Divide By Zero. Return Original Float\n";
            return *this;
        }
        if (val.precision > this->precision)
        {
            temp.precision = this->precision;
        }
        else
        {
            temp.precision = val.precision;
        }
        string whole1 = "", whole2 = "";
        whole1 = this->integer + '.' + this->fraction;
        whole2 = val.integer + '.' + val.fraction;
        string ans = int_str(str_double(whole1) - (str_double(whole2) * (str_double(whole1) / str_double(whole2))));
        temp.integer = integerpart(ans);
        temp.fraction = decimalpart(ans);
        if (temp.integer[0] == '-')
        {
            temp.sign = true;
        }
        string cut;
        if (precision <= length(temp.fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += temp.fraction[i];
            }
        }
        else
        {
            for (int i = length(temp.fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        temp.fraction = cut;
        return temp;
    }
    // Compound Assignment Operators
    BigFloat operator+=(const BigFloat &rhs)
    {
        if (rhs.precision > this->precision)
        {
            this->precision = rhs.precision;
        }
        this->integer = int_str(str_int(this->integer) + str_int(rhs.integer));
        this->fraction = int_str(str_int(this->fraction) + str_int(rhs.fraction));
        if (this->integer[0] == '-')
        {
            this->sign = true;
        }

        string cut = "";
        if (precision <= length(this->fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += this->fraction[i];
            }
        }
        else
        {
            for (int i = length(this->fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        this->fraction = cut;
        return *this;
    }
    BigFloat operator-=(const BigFloat &rhs)
    {
        if (rhs.precision > this->precision)
        {
            this->precision = rhs.precision;
        }
        this->integer = int_str(str_int(this->integer) - str_int(rhs.integer));
        this->fraction = int_str(str_int(this->fraction) - str_int(rhs.fraction));
        if (this->integer[0] == '-')
        {
            this->sign = true;
        }

        string cut = "";
        if (precision <= length(this->fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += this->fraction[i];
            }
        }
        else
        {
            for (int i = length(this->fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        this->fraction = cut;
        return *this;
    }
    BigFloat operator*=(const BigFloat &rhs)
    {
        if (rhs.precision > this->precision)
        {
            this->precision = rhs.precision;
        }
        string whole1 = this->integer + '.' + this->fraction;
        string whole2 = rhs.integer + '.' + rhs.fraction;

        string ans = int_str(str_double(whole1) * str_double(whole2));

        this->integer = integerpart(ans);
        this->fraction = decimalpart(ans);
        if (this->integer[0] == '-')
        {
            this->sign = true;
        }
        string cut;
        if (precision <= length(this->fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += this->fraction[i];
            }
        }
        else
        {
            for (int i = length(this->fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        this->fraction = cut;
        return *this;
    }
    BigFloat operator/=(const BigFloat &rhs)
    {
        if (str_int(rhs.integer) == 0 && str_int(rhs.fraction) == 0)
        {
            cout << "Error. Cannot Divide By Zero. Return Original Float\n";
            return *this;
        }
        if (rhs.precision > this->precision)
        {
            this->precision = rhs.precision;
        }
        string whole1 = this->integer + '.' + this->fraction;
        string whole2 = rhs.integer + '.' + rhs.fraction;

        string ans = int_str(str_double(whole1) / str_double(whole2));

        this->integer = integerpart(ans);
        this->fraction = decimalpart(ans);
        if (this->integer[0] == '-')
        {
            this->sign = true;
        }
        string cut;
        if (precision <= length(this->fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += this->fraction[i];
            }
        }
        else
        {
            for (int i = length(this->fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        this->fraction = cut;
        return *this;
    }
    BigFloat operator%=(const BigFloat &rhs) // Modulus Assignment Operator
    {
        if (str_int(rhs.integer) == 0 && str_int(rhs.fraction) == 0)
        {
            cout << "Error. Cannot Divide By Zero. Return Original Float\n";
            return *this;
        }
        if (rhs.precision > this->precision)
        {
            this->precision = rhs.precision;
        }
        string whole1 = this->integer + '.' + this->fraction;
        string whole2 = rhs.integer + '.' + rhs.fraction;

        string ans = int_str(str_double(whole1) - (str_double(whole2) * (str_double(whole1) / str_double(whole2))));

        this->integer = integerpart(ans);
        this->fraction = decimalpart(ans);
        if (this->integer[0] == '-')
        {
            this->sign = true;
        }
        string cut;
        if (precision <= length(this->fraction))
        {
            for (int i = 0; i <= precision; i++)
            {
                cut += this->fraction[i];
            }
        }
        else
        {
            for (int i = length(this->fraction); i < precision; i++)
            {
                cut += '0';
            }
        }
        this->fraction = cut;
        return *this;
    }
    // Logical Operators
    bool operator==(const BigFloat &val) const
    {
        string whole1 = this->integer + '.' + this->fraction;
        string whole2 = val.integer + '.' + val.fraction;
        if (whole1 == whole2 && this->precision == val.precision && this->sign == val.sign)
        {
            return true;
        }
        return false;
    }
    bool operator!=(const BigFloat &val) const
    {
        return !(*this == val);
    }
    bool operator<(const BigFloat &val) const
    {
        if ((str_int(this->integer) < str_int(val.integer)) || ((str_int(this->integer) >= str_int(val.integer)) && str_int(this->fraction) < str_int(val.fraction)))
        {
            return true;
        }
        return false;
    }
    bool operator<=(const BigFloat &val) const
    {
        return (*this < val) || (*this == val);
    }
    bool operator>(const BigFloat &val) const
    {
        return !(*this <= val);
    }
    bool operator>=(const BigFloat &val) const
    {
        return !(*this < val);
    }
    // Unary Operators
    BigFloat operator+() const // Unary Plus Operator
    {
        
        // unnecessary function as + * + = + and + * - = -
        return *this;
    }

    BigFloat operator-() const // Unary Minus Operator
    {
        BigFloat result = *this;

        // If the current object is negative, convert it to positive
        if (result.sign == true)
        {
            result.integer = int_str(str_int(result.integer) * -1);
            result.sign = false;
        }
        else
        {
            result.integer = int_str(str_int(result.integer) * -1);
            result.sign = true;
        }

        return result;
    }
    // Conversion Operator
    operator string() const // return value of the BigFloat as string
    {
        return (this->integer + '.' + this->fraction);
    }
    ~BigFloat() // destructor
    {
        // unnecessary
    }
    friend ostream &operator<<(ostream &output, const BigFloat &val) // outputs the BigFloat
    {
        if (val.sign == true)
        {
            output << '-';
        }
        string whole = val.integer + '.' + val.fraction;
        output << whole;
        return output;
    }
    friend istream &operator>>(istream &input, BigFloat &val) // inputs the BigFloat
    {
        // input >> val.hours >> val.minutes >> val.seconds;
        cout << "Enter Integer Part: \n";
        input >> val.integer;
        cout << "Enter Fraction Part: \n";
        input >> val.fraction;
        val.precision = length(val.fraction);
        if (val.integer[0] == '-')
        {
            val.sign = true;
        }
        else
        {
            val.sign = false;
        }
        return input;
    }
};

int main()
{
    // Test constructors
    BigFloat a("10.5");
    BigFloat b("15.25");

    // Test arithmetic operators
    BigFloat sum = a + b;
    BigFloat difference = a - b;
    BigFloat product = a * b;
    BigFloat quotient = a / b;
    BigFloat modulus = a % b;

    // Test logical operators
    if (a == b)
    {
        cout << "a is equal to b\n";
    }
    if (a != b)
    {
        cout << "a is not equal to b\n";
    }
    if (a < b)
    {
        cout << "a is greater than b\n";
    }
    if (a <= b)
    {
        cout << "a is greater than or equal to b\n";
    }
    if (a > b)
    {
        cout << "a is less than b\n";
    }
    if (a >= b)
    {
        cout << "a is less than or equal to b\n";
    }

    // Test unary operators
    BigFloat d = -a;
    BigFloat e = +b;

    // Test output operator
    cout << "Sum: " << sum << endl;
    cout << "Difference: " << difference << endl;
    cout << "Product: " << product << endl;
    cout << "Quotient: " << quotient << endl;
    cout << "Modulus: " << modulus << endl;
    cout << "a after compound assignment operations: " << a << endl;
    cout << "b after compound assignment operations: " << b << endl;
    cout << "Is a equal to b? " << (a == b ? "Yes" : "No") << endl;
    cout << "Negative of a: " << d << endl;
    cout << "Positive of b: " << e << endl;
    return 0;
}