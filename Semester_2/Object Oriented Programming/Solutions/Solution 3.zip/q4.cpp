// Muhammad Muneeb Lone || 23i-2623 || Assignment #3
#include <iostream>
#include <cstring>
using namespace std;

class Product
{
    int id;
    char *name;
    float price;
    int quantity;

public:
    // Constructor
    Product() : id(0), name(nullptr), price(0.0f), quantity(0) {}
    Product(int id, const char *name, float price, int quantity)
    {
        this->id = id;
        this->name = new char[strlen(name) + 1];
        strcpy(this->name, name);
        this->price = price;
        this->quantity = quantity;
    }

    // Destructor
    ~Product()
    {
        delete[] name;
    }

    // Getters and setters
    int getId() const
    {
        return id;
    }
    const char *getName() const
    {
        return name;
    }
    float getPrice() const
    {
        return price;
    }
    int getQuantity() const
    {
        return quantity;
    }

    void setId(int id)
    {
        this->id = id;
    }
    void setName(const char *name)
    {
        delete[] this->name;
        this->name = new char[strlen(name) + 1];
        strcpy(this->name, name);
    }
    void setPrice(float price)
    {
        this->price = price;
    }
    void setQuantity(int quantity)
    {
        this->quantity = quantity;
    }
};

class Inventory
{
    Product *products;
    int count;
    int size;

public:
    Inventory(int size)
    {
        if (size <= 0)
        {
            cout << "Inventory size must be greater than 0. Setting default size to 1." << endl;
            size = 1;
        }
        this->size = size;
        products = new Product[size];
        this->count = 0;
    }

    void add_product(int id, const char *name, float price, int quantity)
    {
        if (id <= 0 || price <= 0 || quantity < 0)
        {
            cout << "Invalid input for adding product. ID, price, and quantity must be positive integers." << endl;
            return;
        }
        if (count < size)
        {
            products[count] = Product(id, name, price, quantity);
            count++;
        }
        else
        {
            cout << "Inventory is full. Cannot add more products." << endl;
        }
    }

    void add_product(Product *product)
    {
        if (product->getId() <= 0 || product->getPrice() <= 0 || product->getQuantity() < 0)
        {
            cout << "Invalid input for adding product. ID, price, and quantity must be positive integers." << endl;
            return;
        }
        if (count < size)
        {
            products[count++] = *product;
        }
        else
        {
            cout << "Inventory is full. Cannot add more products." << endl;
        }
    }

    void remove_product(int id)
    {
        if (id <= 0)
        {
            cout << "Invalid ID for removing product. ID must be a positive integer." << endl;
            return;
        }
        for (int i = 0; i < count; i++)
        {
            if (products[i].getId() == id)
            {
                for (int j = i; j < count - 1; j++)
                {
                    products[j] = products[j + 1];
                }
                count--;
                cout << "Product with the ID " << id << " has been removed from the inventory at position " << i << endl;
                return;
            }
        }
        cout << "Product with provided ID was not found.\n";
    }

    void remove_product(char *name)
    {
        if (strlen(name) == 0)
        {
            cout << " Empty name provided for removing product." << endl;
            return;
        }
        int remCount = 0;
        for (int i = 0; i < count; i++)
        {
            if (strcmp(products[i].getName(), name) == 0)

            {
                for (int j = i; j < count - 1; j++)
                {
                    products[j] = products[j + 1];
                }
                count--;
                remCount++;
                i--;
            }
        }
        if (remCount <= 0)
        {
            cout << "No product removed\n";
            return;
        }
        else
        {
            cout << name << " removed.\n";
        }
    }
    void remove_product(int id, int count)
    {
        if (id <= 0 || count <= 0)
        {
            cout << " Invalid ID or quantity for removing product. ID must be a positive integer, and count must be a positive integer." << endl;
            return;
        }
        for (int k = 0; k < count; k++)
        {
            for (int i = 0; i < this->count; i++)
            {
                if (products[i].getId() == id)
                {
                    for (int j = i; j < this->count - 1; j++)
                    {
                        products[j] = products[j + 1];
                    }
                    this->count--;
                    cout << "Product with the ID " << id << " has been removed from the inventory at position " << i << endl;
                    return;
                }
            }
        }
        cout << "Product with provided ID was not found.\n";
    }

    void update_quantity(int id, int quantity_change)
    {
        if (id <= 0)
        {
            cout << " Invalid ID for updating quantity. ID must be a positive integer." << endl;
            return;
        }
        for (int i = 0; i < count; i++)
        {
            if (products[i].getId() == id)
            {
                if (quantity_change > 0)
                {
                    products[i].setQuantity(products[i].getQuantity() + quantity_change);
                    cout << "Quantity updated.\n";
                    return;
                }
                else if (quantity_change == 0)
                {
                    cout << "No change in quantity was made.\n";
                    return;
                }
                else
                {
                    if ((quantity_change * -1) > products[i].getQuantity())
                    {
                        cout << "The quantity to subtract is greater than the quantity stored. Error.\n";
                        return;
                    }
                    else
                    {
                        products[i].setQuantity(products[i].getQuantity() + quantity_change);
                        cout << "Quantity updated.\n";
                        return;
                    }
                }
            }
        }
        cout << "Product with provided ID was not found.\n";
    }

    Product &get_product(int id)
    {
        if (id <= 0)
        {
            cout << " Invalid ID for getting product information. ID must be a positive integer." << endl;
        }
        else

        {
            for (int i = 0; i < count; i++)
            {
                if (products[i].getId() == id)
                {
                    return products[i];
                }
            }
        }
        cout << "No product with this ID was found.\n";
    }
    float calculate_inventory_value()
    {
        float sum = 0;
        for (int i = 0; i < count; i++)
        {
            sum += products[i].getPrice();
        }
        return sum;
    }

    void display() const
    {
        cout << "Product Catalogue:" << endl;

        for (int i = 0; i < count; i++)
        {
            const Product &product = products[i];
            cout << "ID: " << product.getId() << endl;
            cout << "Name: " << product.getName() << endl;
            cout << "Price: " << product.getPrice() << endl;
            cout << "Quantity: " << product.getQuantity() << endl;
        }
    }

    ~Inventory()
    {
        delete[] products;
    }
};

int main()
{

    int invSize = 0;
    cout << "Enter a size for the inventory: \n";
    cin >> invSize;
    if (invSize <= 0)
    {
        cout << "Invalid input for inventory size. Size must be a positive integer." << endl;
        return 1;
    }
    Inventory inventory(invSize);

    int choice;
    while (true)
    {
        cout << "\n------ Inventory Management System ------\n";
        cout << "1. Add Product\n";
        cout << "2. Remove Product by ID\n";
        cout << "3. Remove Product by Name\n";
        cout << "4. Display Catalogue\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            int id, quantity;
            float price;
            char name[50];
            cout << "\nEnter product ID: ";
            cin >> id;
            if (id <= 0)
            {
                cout << "Invalid input for product ID. ID must be a positive integer." << endl;
                break;
            }
            cout << "Enter product name: ";
            cin.ignore();
            cin.getline(name, 50);
            if (strlen(name) == 0)
            {
                cout << "Empty name provided for adding product." << endl;
                break;
            }
            cout << "Enter product price: ";
            cin >> price;
            if (price <= 0)
            {
                cout << "Invalid input for product price. Price must be a positive number." << endl;
                break;
            }
            cout << "Enter product quantity: ";
            cin >> quantity;
            if (quantity < 0)
            {
                cout << "Invalid input for product quantity. Quantity must be a non-negative integer." << endl;
                break;
            }
            inventory.add_product(id, name, price, quantity);
            break;
        }
        case 2:
        {
            int id;
            cout << "\nEnter product ID to remove: ";
            cin >> id;
            inventory.remove_product(id);
            break;
        }
        case 3:
        {
            char name[50];
            cout << "\nEnter product name to remove: ";
            cin.ignore();
            cin.getline(name, 50);
            inventory.remove_product(name);
            break;
        }
        case 4:
        {
            cout << "\n------ Product Catalogue ------\n";
            inventory.display();
            break;
        }
        case 5:
        {
            cout << "\nExiting program.\n";
            return 0;
        }
        default:
            cout << "\nInvalid choice. Please enter a valid option.\n";
        }
    }

    return 0;
}