// Muhammad Muneeb Lone || 23i-2623 || Assignment #3
#include <iostream>
#include <cstring>
using std::endl, std::cout, std::cin;

class IceCream
{
private:
    char *flavor, *topping, *servingType;
    bool isReady;
    double price;

public:
    IceCream() : flavor(nullptr), topping(nullptr), servingType(nullptr), isReady(false), price(0.0) {} // Default Constructor

    IceCream(char *flavor, char *topping, char *servingType, double price) // Paramterized Constructor 1
    {
        this->flavor = new char[strlen(flavor) + 1];
        strcpy(this->flavor, flavor);
        this->topping = new char[strlen(topping) + 1];
        strcpy(this->topping, topping);
        this->servingType = new char[strlen(servingType) + 1];
        strcpy(this->servingType, servingType);
        this->price = price;
    }

    IceCream(char *topping, double price) : isReady(false) // Parameterized Constructor 2
    {
        this->topping = new char[strlen(topping) + 1];
        strcpy(this->topping, topping);
        this->price = price;
    }

    IceCream(const IceCream &iceCream) // Copy Constructor
    {
        this->flavor = new char[strlen(iceCream.flavor) + 1];
        strcpy(this->flavor, iceCream.flavor);
        this->topping = new char[strlen(iceCream.topping) + 1];
        strcpy(this->topping, iceCream.topping);
        this->servingType = new char[strlen(iceCream.servingType) + 1];
        strcpy(this->servingType, iceCream.servingType);
        this->price = iceCream.price;
    }

    ~IceCream() // Destructor
    {
        delete[] flavor;
        delete[] topping;
        delete[] servingType;
    }

    void setFlavor(char *flavor)
    {
        delete[] this->flavor;
        this->flavor = new char[strlen(flavor) + 1];
        strcpy(this->flavor, flavor);
    }
    void setTopping(char *topping)
    {
        delete[] this->topping;
        this->topping = new char[strlen(topping) + 1];
        strcpy(this->topping, topping);
    }
    void setServing(char *servingType)
    {
        delete[] this->servingType;
        this->servingType = new char[strlen(servingType) + 1];
        strcpy(this->servingType, servingType);
    }
    void setPrice(float price)
    {
        this->price = price;
    }
    char *getFlavor() const
    {
        return flavor;
    }
    char *getTopping() const
    {
        return topping;
    }
    char *getServingType() const
    {
        return servingType;
    }
    double getPrice() const
    {
        return price;
    }
    void makeIceCream()
    {
        if (topping != nullptr)
        {
            isReady = true;
        }
    }
    bool checkStatus()
    {
        if (isReady)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
};

int main()
{
    int choice = 0;
    cout << "Enter a number:\n 1 : Default Constructor\n 2 : First Parameterized Constructor\n 3 : Second Parameterized Constructor\n ";
    cin >> choice;
    switch (choice)
    {
    case 1:
    {
        cout << "\nCalling Default Constructor\n";
        IceCream icecream_1;
        cout << icecream_1.getFlavor() << endl;
        cout << icecream_1.getPrice() << endl;
        cout << icecream_1.getServingType() << endl;
        cout << icecream_1.getTopping() << endl;
        break;
    }
    case 2:
    {
        cout << "\nCalling First Constructor\n";
        IceCream icecream_2("chocolate", "choc chip", "large", 100.0);
        cout << icecream_2.getFlavor() << endl;
        cout << icecream_2.getPrice() << endl;
        cout << icecream_2.getServingType() << endl;
        cout << icecream_2.getTopping() << endl;
        break;
    }
    case 3:
    {
        cout << "\nCalling Second Constructor\n";
        IceCream icecream_3("chocolate chip", 99.0);
        cout << icecream_3.getPrice() << endl;
        cout << icecream_3.getTopping() << endl;
        break;
    }
    default:
    {
        cout << "\nInvalid choice\n";
        break;
    }
    }
    return 0;
}
