// Muhammad Muneeb Lone || 23i-2623 || Assignment #3
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

class Minesweeper
{
private:
    int **grid;
    int size;
    int mines;

public:
    Minesweeper(int size, int mines) : size(size), mines(mines)
    {

        grid = new int *[size];
        for (int i = 0; i < size; i++)
        {
            grid[i] = new int[size];
            for (int j = 0; j < size; j++)
            {
                grid[i][j] = 0; // Initializing the field with 0s
            }
        }

        srand(time(NULL));
        int placedMines = 0;
        while (placedMines < mines)
        {
            int row = rand() % size;
            int col = rand() % size;
            if (grid[row][col] != -1)
            {
                grid[row][col] = -1; // -1 represents a mine
                placedMines++;
            }
        }
    }

    ~Minesweeper()
    {

        for (int i = 0; i < size; i++)
        {
            delete[] grid[i];
        }
        delete[] grid;
    }

    void displayGrid(bool revealMines = false)
    {
        cout << "  ";
        for (int j = 0; j < size; j++)
        {
            cout << j << " ";
        }
        cout << endl;

        for (int i = 0; i < size; i++)
        {
            cout << i << " ";
            for (int j = 0; j < size; j++)
            {
                if (grid[i][j] == -1 && !revealMines)
                {
                    cout << "* ";
                }
                else
                {
                    cout << grid[i][j] << " ";
                }
            }
            cout << endl;
        }
    }

    bool isValidCell(int row, int col)
    {
        return row >= 0 && row < size && col >= 0 && col < size;
    }

    bool revealCell(int row, int col)
    {
        if (!isValidCell(row, col))
        {
            cout << "Invalid cell coordinates" << endl;
            return false;
        }

        if (grid[row][col] == -1)
        {
            cout << "Game over!." << endl;
            return true;
        }
        else
        {   
            cout << "Cell (" << row << ", " << col << ") was not a mine." << endl;
            return false;
        }
    }

    void flagCell(int row, int col)
    {
        if (!isValidCell(row, col))
        {
            cout << "Invalid coordinates" << endl;
            return;
        }

        grid[row][col] = -2; // -2 represents a flagged cell
        cout << "Cell (" << row << ", " << col << ") flagged." << endl;
    }

    bool checkWin()
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            // Check if a non-mine cell is unrevealed
            if (grid[i][j] != -1 && grid[i][j] >= 0)
            {
                return false;
            }
        }
    }
    return true; // All non-mine cells have been revealed
}

};

int main()
{
    int size, mines;
    cout << "Enter the size of the Minesweeper grid: ";
    cin >> size;
    cout << "Enter the number of mines: ";
    cin >> mines;

    Minesweeper game(size, mines);

    bool gameOver = false;
    while (!gameOver)
    {
        cout << "\nCurrent grid:" << endl;
        game.displayGrid();

        int row, col;
        char action;
        cout << "Enter coordinates: ";
        cin >> row >> col;
        cout<<"Enter action (R for reveal and F for flag): \n";
        cin>>action;

        if (action == 'R' || action == 'r')
        {
            gameOver = game.revealCell(row, col);
        }
        else if (action == 'F' || action == 'f')
        {
            game.flagCell(row, col);
        }
        else
        {
            cout << "Invalid action." << endl;
        }

        if (!gameOver)
        {
            gameOver = game.checkWin();
        }
    }

    cout << "\nFinal grid:" << endl;
    game.displayGrid(true);

    return 0;
}
