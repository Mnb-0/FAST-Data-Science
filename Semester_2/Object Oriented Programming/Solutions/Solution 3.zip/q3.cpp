// Muhammad Muneeb Lone || 23i-2623 || Assignment #3
#include <iostream>
#include <string>
using namespace std;

class HotelBooking
{

private:
    string bookingID;
    string customerName;
    string hotelName;
    string roomType;
    string checkIn;
    string checkOut;
    int stayDuration;
    double roomRate;

public:
    HotelBooking(string bookingID, string customerName, string hotelName, string roomType, string checkIn, string checkOut)
    {
        this->bookingID = bookingID;
        this->customerName = customerName;
        this->hotelName = hotelName;
        this->roomType = roomType;
        this->checkIn = checkIn;
        this->checkOut = checkOut;
        this->roomRate = calculateRoomRate();
        this->stayDuration = calculateStayDuration();
    }

    bool validateBookingID() const
    {
        string temp = bookingID;
        if (temp.length() != 14)
        {
            cout << "Invalid ID length\n";
            return false;
        }
        for (int i = 0; i < 8; i++)
        {
            if (!isalpha(temp[i]))
            {
                cout << "First 8 characters are not characters.\n";
                return false;
            }
        }
        if (!((temp[8] == '@' || temp[8] == '#' || temp[8] == '$') && (temp[9] == '@' || temp[9] == '#' || temp[9] == '$')))
        {
            cout << "9th and 10th Characters are not special characters.\n";
            return false;
        }

        for (int i = 10; i < 14; i++)
        {
            if (!isdigit(temp[i]))
            {
                cout << "Last 4 characters are not digits.\n";
                return false;
            }
        }

        int sum = 0;
        sum = (temp[10] - '0') + (temp[11] - '0') + (temp[12] - '0') + (temp[13] - '0');
        if (sum >= 18)
        {
            cout << "Sum is greater than or equal to 18.\n";
            return false;
        }
        cout << "All checks passed.\n";
        return true;
    }

    bool isValidDate(const string &date) const
    {
        // Simple validation for date format (DD/MM/YY)
        if (date.length() != 8)
        {
            return false;
        }
        for (int i = 0; i < 8; ++i)
        {
            if (i == 2 || i == 5)
            {
                if (date[i] != '/')
                {
                    return false;
                }
            }
            else
            {
                if (!isdigit(date[i]))
                {
                    return false;
                }
            }
        }
        return true;
    }

    double calculateRoomRate() const
    {
        if (roomType == "Economy")
        {
            return 50.0;
        }
        else if (roomType == "Average")
        {
            return 100.0;
        }
        else if (roomType == "Luxury")
        {
            return 200.0;
        }
        else
        {
            return -1.0;
        }
    }

    double calculateTotalCost() const
    {
        return stayDuration * calculateRoomRate();
    }

    void getBookingDetails() const
    {
        cout << "Booking ID: " << bookingID << endl;
        cout << "Customer Name: " << customerName << endl;
        cout << "Hotel Name: " << hotelName << endl;
        cout << "Room Type: " << roomType << endl;
        cout << "Check-in Date: " << checkIn << endl;
        cout << "Check-out Date: " << checkOut << endl;
        cout << "Stay Duration: " << stayDuration << " days" << endl;
        cout << "Room Rate: Rs." << roomRate << " per night" << endl;
        cout << "Total Cost: Rs." << calculateTotalCost() << endl;
    }

    int calculateStayDuration()
    {
        // Assuming format is DD/MM/YY
        int duration = 0;
        string daysIn;
        daysIn += checkIn[0];
        daysIn += checkIn[1];
        string daysOut;
        daysOut += checkOut[0];
        daysOut += checkOut[1];

        duration = stoi(daysOut) - stoi(daysIn);
        if (duration < 0)
        {
            duration = duration * -1;
        }

        stayDuration = duration;
        return stayDuration;
    }

    void updateBookingInfo(const string &newCheckIn, const string &newCheckOut)
    {
        if (!isValidDate(newCheckIn) || !isValidDate(newCheckOut))
        {
            cout << "Error: Invalid date format." << endl;
            return;
        }

        checkIn = newCheckIn;
        checkOut = newCheckOut;

        stayDuration = calculateStayDuration();

        roomRate = calculateRoomRate();
    }
};

int main()
{
    
    string name, id, hotel, room, in, out;

    cout << "Enter booking ID: ";
    getline(cin, id);

    cout << "Enter customer name: ";
    getline(cin, name);

    cout << "Enter hotel name: ";
    getline(cin, hotel);

    cout << "Enter room type (Economy/Average/Luxury): ";
    getline(cin, room);

    cout << "Enter check-in date (DD/MM/YY): ";
    getline(cin, in);

    cout << "Enter check-out date (DD/MM/YY): ";
    getline(cin, out);

    HotelBooking booking(id, name, hotel, room, in, out);

    int choice;
    string newCheckIn, newCheckOut;
    cout << "Welcome to Hotel Booking System!" << endl;
    do
    {
        cout << "\nMenu:\n1. Display Booking Details\n2. Update Booking Information\n3. Exit\nEnter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            cout << "\nBooking Details:\n";
            booking.getBookingDetails();
            break;
        case 2:
            cout << "\nEnter new Check-in Date (DD/MM/YY): ";
            cin >> newCheckIn;
            cout << "Enter new Check-out Date (DD/MM/YY): ";
            cin >> newCheckOut;
            booking.updateBookingInfo(newCheckIn, newCheckOut);
            cout << "Booking information updated successfully!\n";
            break;
        case 3:
            cout << "Exiting...";
            break;
        default:
            cout << "Invalid choice! Please enter a valid option.\n";
        }

    } while (choice != 3);

    return 0;
}