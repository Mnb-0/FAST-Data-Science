// Muhammad Muneeb Lone || 23i-2623 || Assignment #3
#include <iostream>
#include <cstring>
using namespace std;

class Library
{
private:
    char *bookTitle;
    char *author;
    int bookID;
    int quantity;
    float price;
    static int totalBooks;

public:
    Library() : bookTitle(nullptr), author(nullptr), bookID(0), quantity(0), price(0.0) {}
    Library(const char *title, const char *author, int bookID, int quantity, float price)
    {
        this->bookTitle = new char[strlen(title) + 1];
        strcpy(this->bookTitle, title);

        this->author = new char[strlen(author) + 1];
        strcpy(this->author, author);

        this->bookID = bookID;
        this->quantity = quantity;
        this->price = price;

        totalBooks += quantity;
    }

    ~Library()
    {
        delete[] bookTitle;
        delete[] author;
        totalBooks -= quantity;
    }

    char *getBookTitle() const
    {
        return bookTitle;
    }

    char *getAuthor() const
    {
        return author;
    }

    int getBookID() const
    {
        return bookID;
    }

    int getQuantity() const
    {
        return quantity;
    }

    float getPrice() const
    {
        return price;
    }

    void setBookTitle(const char *title)
    {
        delete[] bookTitle;
        bookTitle = new char[strlen(title) + 1];
        strcpy(bookTitle, title);
    }

    void setAuthor(const char *authorName)
    {
        delete[] author;
        author = new char[strlen(authorName) + 1];
        strcpy(author, authorName);
    }

    void setBookID(int bookID)
    {
        this->bookID = bookID;
    }

    void setQuantity(int quantity)
    {
        this->quantity = quantity;
    }

    void setPrice(float price)
    {
        this->price = price;
    }

    static void setTotalBooks(int totalBooks)
    {
        Library::totalBooks = totalBooks;
    }

    void calcTotalPrice()
    {
        cout << "Total Price: " << quantity * price << endl;
    }

    static int getTotalBooks()
    {
        return totalBooks;
    }
};

int Library::totalBooks = 0;
int sizeArr = 0;

Library getBook_at(Library books[], int index)
{
    if (index >= 0 && index < sizeArr)
    {
        return books[index];
    }
}

void addBook(Library books[], Library newBook, int MAX_BOOKS)
{
    if (newBook.getQuantity() < 0)
    {
        cout << "Quantity cannot be negative. Book not added." << endl;
        return;
    }

    if (sizeArr >= MAX_BOOKS)
    {
        cout << "Library is full. Cannot add more books." << endl;
        return;
    }

    for (int i = 0; i < MAX_BOOKS; ++i)
    {
        if (books[i].getBookID() == newBook.getBookID())
        {
            cout << "Book with the same ID already exists. Book not added." << endl;
            return;
        }
    }

    for (int i = 0; i < MAX_BOOKS; ++i)
    {
        if (books[i].getBookID() == 0)
        {
            books[i] = newBook;
            sizeArr++;
            return;
        }
    }
}

void removeBook(Library books[], int bookID)
{
    if (bookID < 0)
    {
        cout << "Invalid ID\n";
        return;
    }
    for (int i = 0; i < sizeArr; i++)
    {
        if (books[i].getBookID() == bookID)
        {
            for (int j = i; j < sizeArr - 1; j++)
            {
                books[j] = books[j + 1];
            }
        }
    }
}

void SortByTitle(Library books[])
{
    Library temp;
    for (int i = 0; i < sizeArr; i++)
    {
        for (int j = 0; j < sizeArr - 1; j++)
        {
            if (strcmp(books[j].getBookTitle(), books[j + 1].getBookTitle()) > 0)
            {
                temp = books[j];
                books[j] = books[j + 1];
                books[j + 1] = temp;
            }
        }
    }
}

void SortByAuthor(Library books[])
{
    Library temp;
    for (int i = 0; i < sizeArr; i++)
    {
        for (int j = 0; j < sizeArr - 1; j++)
        {
            if (strcmp(books[j].getAuthor(), books[j + 1].getAuthor()) > 0)
            {
                temp = books[j];
                books[j] = books[j + 1];
                books[j + 1] = temp;
            }
        }
    }
}

void SortByPrice(Library books[])
{
    Library temp;
    for (int i = 0; i < sizeArr; i++)
    {
        for (int j = 0; j < sizeArr - 1; j++)
        {
            if (books[j].getPrice() > books[j + 1].getPrice())
            {
                temp = books[j];
                books[j] = books[j + 1];
                books[j + 1] = temp;
            }
        }
    }
}

bool searchByTitle(Library books[], const char *titleName)
{
    for (int i = 0; i < sizeArr; i++)
    {
        if (strcmp(books[i].getBookTitle(), titleName) == 0)
        {
            cout << "Book found: " << books[i].getBookTitle() << " by " << books[i].getAuthor() << endl;
            return true;
        }
    }
    cout << "Book not found!" << endl;
    return false;
}

Library mostExpensiveBook(Library books[])
{
    if (sizeArr == 0)
    {
        cout << "Library is empty." << endl;
    }

    Library maxBook = books[0];
    for (int i = 1; i < sizeArr; i++)
    {
        if (books[i].getPrice() > maxBook.getPrice())
        {
            maxBook = books[i];
        }
    }

    cout << "Most expensive book: " << maxBook.getBookTitle() << " by " << maxBook.getAuthor() << endl;
    return maxBook;
}
int main()
{
    const int MAX_BOOKS = 10;
    Library books[MAX_BOOKS];
    int sizeArr = 0;

    addBook(books, Library("Book1", "Author1", 1, 4, 25.0), MAX_BOOKS);
    sizeArr++;
    addBook(books, Library("Book2", "Author2", 2, 3, 20.0), MAX_BOOKS);
    sizeArr++;
    addBook(books, Library("Book3", "Author3", 3, 7, 30.0), MAX_BOOKS);
    sizeArr++;

    removeBook(books, 2);

    SortByTitle(books);
    SortByAuthor(books);
    SortByPrice(books);

    if (searchByTitle(books, "Book1"))
    {
        cout << "Book found" << endl;
    }
    else
    {
        cout << "Book not found" << endl;
    }

    Library mostExpensive = mostExpensiveBook(books);
    cout << "Most expensive book: " << mostExpensive.getBookTitle() << endl;

    cout << "Total books in the library: " << sizeArr << endl;

    return 0;
}
