// Muhammad Muneeb Lone || 23i-2623 || Assignment #3
#include <iostream>
#include <string>
using namespace std;

class Student
{
private:
    int stdID;
    int numOfCourses;
    int *courseGrades;
    float gpa;
    string name;
    string *courseCodes;

public:
    Student(string name, int stdID)
    {
        this->stdID = stdID;
        this->name = name;
        gpa = 0.0;
        numOfCourses = 0;
        courseGrades = nullptr;
        courseCodes = nullptr;
    }

    ~Student()
    {
        delete[] courseGrades;
        delete[] courseCodes;
    }

    int getStdID() const
    {
        return stdID;
    }

    string getName() const
    {
        return name;
    }

    int getNumOfCourses() const
    {
        return numOfCourses;
    }

    string getCourseCode(int i) const
    {
        if (i >= 0 && i < numOfCourses)
        {
            return courseCodes[i];
        }
        return "Invalid Index";
    }

    int getCourseGrade(int i) const
    {
        if (i >= 0 && i < numOfCourses)
        {
            return courseGrades[i];
        }
        return -1;
    }

    float getGPA() const
    {
        return gpa;
    }

    void setStdID(int id)
    {
        stdID = id;
    }

    void setName(const string& firstName)
    {
        name = firstName;
    }

    void setCourseGrade(const string& courseCode, int grade)
    {
        for (int i = 0; i < numOfCourses; i++)
        {
            if (courseCodes[i] == courseCode)
            {
                courseGrades[i] = grade;
                return;
            }
        }
        cout << "\nCourse Not Found\n";
    }

    void addCourse(const string& courseCode, int grade)
    {
        numOfCourses++;
        string *newCourseCodes = new string[numOfCourses];
        int *newCourseGrades = new int[numOfCourses];

        for (int i = 0; i < numOfCourses - 1; i++)
        {
            newCourseCodes[i] = courseCodes[i];
            newCourseGrades[i] = courseGrades[i];
        }
        newCourseCodes[numOfCourses - 1] = courseCode;
        newCourseGrades[numOfCourses - 1] = grade;

        delete[] courseCodes;
        delete[] courseGrades;

        courseCodes = newCourseCodes;
        courseGrades = newCourseGrades;

        calcGPA();
    }

    void calcGPA()
    {
        if (numOfCourses == 0)
        {
            gpa = 0.0;
            return;
        }
        float totalGrade = 0;
        for (int i = 0; i < numOfCourses; i++)
        {
            totalGrade += courseGrades[i];
        }
        gpa = totalGrade / numOfCourses;
    }
};

void displayStudentMenu()
{
    cout << "\n\nStudent Menu\n";
    cout << "1. Add Course\n";
    cout << "2. View Student Info\n";
    cout << "3. Exit\n";
}

void addCourse(Student& student)
{
    string courseCode;
    int grade;

    cout << "\nEnter Course Code: ";
    cin >> courseCode;
    cout << "Enter Grade: ";
    cin >> grade;

    student.addCourse(courseCode, grade);
}

void viewStudentInfo(const Student& student)
{
    cout << "\nStudent Information:\n";
    cout << "Name: " << student.getName() << endl;
    cout << "Student ID: " << student.getStdID() << endl;
    cout << "Number of Courses: " << student.getNumOfCourses() << endl;
    cout << "GPA: " << student.getGPA() << endl;

    cout << "Courses:\n";
    for (int i = 0; i < student.getNumOfCourses(); i++)
    {
        cout << "Course Code: " << student.getCourseCode(i) << " - Grade: " << student.getCourseGrade(i) << endl;
    }
}

int main()
{
    string name;
    int id;
    
    cout << "Enter student name: ";
    cin >> name;
    cout << "Enter student ID: ";
    cin >> id;

    Student student(name, id);

    int choice;
    bool exit = false;

    while (!exit)
    {
        displayStudentMenu();
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
                addCourse(student);
                break;
            case 2:
                viewStudentInfo(student);
                break;
            case 3:
                exit = true;
                cout << "\nExiting...\n";
                break;
            default:
                cout << "\nInvalid choice. Please try again.\n";
                break;
        }
    }

    return 0;
}
