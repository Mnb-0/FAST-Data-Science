// Muhammad Muneeb Lone || 23i-2623 || Assignment #3
#include <iostream>
using namespace std;

class String
{
private:
    char *data;
    int length;

public:
    // Default constructor
    String() : data(nullptr), length(0)
    {
    }

    String(int size) : length(size)
    {
        data = new char[size + 1]; // for the null terminator
        data[0] = '\0';
    }

    // Alternate constructor with char*
    String(const char *str)
    {
        length = 0;
        while (str[length] != '\0')
        {
            ++length;
        }
        data = new char[length + 1]; // for the null terminator
        for (int i = 0; i <= length; ++i)
        {
            data[i] = str[i];
        }
    }

    // Copy constructor
    String(const String &str) : length(str.length)
    {
        data = new char[length + 1]; // for the null terminator
        for (int i = 0; i <= length; ++i)
        {
            data[i] = str.data[i];
        }
    }

    ~String()
    {
        delete[] data;
    }

    int strLength()
    {
        return length;
    }

    void clear()
    {
        for (int i = 0; i < length; i++)
        {
            data[i] = ' ';
        }
        length = 0;
    }
    bool empty()
    {
        if (data[0] == ' ')
        {
            return true;
        }
        return false;
    }

    int charAt(char c)
    {
        for (int i = 0; i < length; i++)
        {
            if (data[i] == c)
            {
                return i;
            }
        }
        return -1;
    }

    char *getData()
    {
        return data;
    }

    bool equals(char *str)
    {
        bool equal = true; // Initialize equal to true
        int i = 0;
        while (str[i] != '\0' && i < length)
        {
            if (data[i] != str[i])
            {
                equal = false;
            }
            i++;
        }

        return equal;
    }

    bool equalsIgnoreCase(const char *str)
    {
        int i = 0;
        while (i < length && str[i] != '\0')
        {
            char ch1 = data[i];
            char ch2 = str[i];

            if (ch1 >= 'A' && ch1 <= 'Z')
                ch1 += 32;

            if (ch2 >= 'A' && ch2 <= 'Z')
                ch2 += 32;

            if (ch1 != ch2)
                return false;

            i++;
        }
        return (i == length && str[i] == '\0');
    }

    char *substring(char *substr, int startIndex)
    {
        
        if (startIndex < 0 || startIndex >= length)
            return nullptr;

        
        int substrLength = 0;
        while (substr[substrLength] != '\0')
        {
            ++substrLength;
        }

        int index = -1;

        
        for (int i = startIndex; i < length; ++i)
        {
            bool found = true;
            for (int j = 0; j < substrLength; ++j)
            {
                if (data[i + j] != substr[j])
                {
                    found = false;
                    break;
                }
            }
            if (found)
            {
                index = i;
                break;
            }
        }

        
        if (index != -1)
        {
            int subLength = length - index;
            char *result = new char[subLength + 1];
            for (int i = 0; i < subLength; ++i)
            {
                result[i] = data[index + i];
            }
            result[subLength] = '\0'; // null-terminate
            return result;
        }
        else
        {
            return nullptr; 
        }
    }

    void print()
    {
        if (length == 0)
        {
            cout << "NULL" << endl;
            return;
        }
        for (int i = 0; i < length; i++)
        {
            cout << data[i];
        }
        cout << endl;
    }
    void toUpperCase()
    {
        for (int i = 0; i < length; i++)
        {
            if (data[i] >= 'a' && data[i] <= 'z')
            {
                data[i] = data[i] - 32;
            }
        }
    }

    void toLowerCase()
    {
        for (int i = 0; i < length; i++)
        {
            if (data[i] >= 'A' && data[i] <= 'Z')
            {
                data[i] = data[i] + 32;
            }
        }
    }
};

int main()
{
    // Test cases
    String str1("Hello, World!");
    String str2("world");
    String str3("llo");

    cout << "String 1: ";
    str1.print();

    cout << "Is str1 equals to \"Hello, World!\"? ";
    cout << (str1.equals("Hello, World!") ? "Yes" : "No") << endl;

    cout << "Is str1 equalsIgnoreCase to \"hello, world!\"? ";
    cout << (str1.equalsIgnoreCase("hello, world!") ? "Yes" : "No") << endl;


    char* substr = str1.substring(str3.getData(), 2);
    cout << "Substring of str1 starting from index 2 with substring \"llo\": ";
    if (substr != nullptr)
    {
        cout << substr << endl;
        delete[] substr;
    }
    else
    {
        cout << "Substring not found" << endl;
    }

    cout << "str1 in uppercase: ";
    str1.toUpperCase();
    str1.print();


    cout << "str2 in lowercase: ";
    str2.toLowerCase();
    str2.print();

    return 0;
}
