// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
#include <string>
using namespace std;
bool orderCheck(char open, char close);
bool helper(string inStr, int index, char prev);
bool isBalanced(string inStr);

int main()
{
    string str;
    cout << "Enter a string: ";
    cin >> str;

    isBalanced(str);

    return 0;
}
bool orderCheck(char open, char close)
{
    if (open == '(' && close == ')')
        return true;
    else if (open == '{' && close == '}')
        return true;
    else if (open == '[' && close == ']')
        return true;
    else
        return false;
}

bool helper(string inStr, int index, char prev)
{
    if (index == inStr.size())
    {
        return prev == '\0';
    }
    else
    {
        if (inStr[index] == '(' || inStr[index] == '{' || inStr[index] == '[')
        {
            return helper(inStr, index + 1, inStr[index]);
        }
        else if (inStr[index] == ')' || inStr[index] == '}' || inStr[index] == ']')
        {
            if (orderCheck(prev, inStr[index]) == 1)
                return helper(inStr, index + 1, '\0');
            else
                return false;
        }
        else
        {
            return helper(inStr, index + 1, prev);
        }
    }
}
bool isBalanced(string inStr)
{
    if (helper(inStr, 0, '\0') == 1)
    {
        cout << "The string is balanced." << endl;
        return true;
    }
    else
    {
        cout << "The string is not balanced." << endl;
        return false;
    }
}