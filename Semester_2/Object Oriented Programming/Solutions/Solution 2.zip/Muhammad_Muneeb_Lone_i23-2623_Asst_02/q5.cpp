// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
using namespace std;
int countAllOrderings(int a, int b);
int countGoodOrderings(int a, int b);

int main()
{
    int a, b;
    cout << "Enter A-Ballots: ";
    cin >> a;
    cout << "Enter B-Ballots: ";
    cin >> b;

    int totalOrderings = countAllOrderings(a, b);
    int goodOrderings = countGoodOrderings(a, b);

    cout << "Total Orderings: " << totalOrderings << endl;
    cout << "Good Orderings: " << goodOrderings << endl;

    return 0;
}

int countAllOrderings(int a, int b)
{
    if (a == 0 || b == 0) // One of the candidates has no ballots remaining
    {
        return 1; // Base case: 1 ordering
    }
    return countAllOrderings(a - 1, b) + countAllOrderings(a, b - 1); // number of ways to order the votes for candidates A and B
}

int countGoodOrderings(int a, int b)
{
    if (a == 0 || b == 0) // One of the candidates has no ballots remaining
    {
        return 1; // Base case: 1 good ordering
    }

    if (a > b)
    {
        return countGoodOrderings(a - 1, b) + countGoodOrderings(a, b - 1); // A is ahead
    }
    else if (a == b)
    {

        return countGoodOrderings(a - 1, b); // A and B are tied
    }
    else
    {

        return 0; // B is ahead
    }
}