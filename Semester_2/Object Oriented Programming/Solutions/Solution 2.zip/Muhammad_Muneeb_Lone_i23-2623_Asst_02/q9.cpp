// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
using namespace std;
void hollowDiamondPattern(int, int);
void spaces(int, int);
void stars(int);

int main()
{
	int n = 0;
	cout << "Enter an odd number: " << endl;
	cin >> n;
	n=n/2;
	if (n % 2 == 0)
	{
		n = n + 1;
		if (n > 0)
		{
			hollowDiamondPattern(n, n);
		}
		else
		{
			n = n * -1;
			hollowDiamondPattern(n, n);
		}
	}
	else
	{
		if (n > 0)
		{
			hollowDiamondPattern(n, n);
		}
		else
		{
			n = n * -1;
			hollowDiamondPattern(n, n);
		}
	}
}
void hollowDiamondPattern(int i, int j)
{
	if (i == 0 && j == 0)
	{
		return;
	}
	stars(i);
	spaces(j, i);
	stars(i);
	if (i > 1)
	{
		cout << endl;
		hollowDiamondPattern(i - 1, j);
	}
	if (i == 1)
	{
		cout << endl;
	}
	stars(i);
	spaces(j, i);
	stars(i);
	cout << endl;
}
void spaces(int num, int n)
{
	if (n == num)
	{
		return;
	}
	cout << "  ";
	spaces(num, n + 1);
}

void stars(int num)
{
	if (num <= 0)
	{
		return;
	}
	cout << "*";
	stars(num - 1);
}
