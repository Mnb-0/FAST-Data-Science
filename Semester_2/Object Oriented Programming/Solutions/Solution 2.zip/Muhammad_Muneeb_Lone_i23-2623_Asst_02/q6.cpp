// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
using namespace std;
void white(int size, int row, int col, char k);
void black(int size, int row, int col);
void chessboard(int size, int i, int j, char k, char wb);

int main()
{
    int size = 0;
    char k = '0', wb = '0';
    cout << "Enter a character for the white square: \n";
    cin >> k;
    cout << "Enter a size (EVEN): \n";
    cin >> size;
    if (size % 2 != 0)
    {
        cout << "Size is not an even number. Adding one to make it even.\n";
        size += 1;
    }
    cout << "Enter white or black: \n";
    cin >> wb;
    cout << endl;
    chessboard(size, 0, 0, k, wb);
    return 0;
}
void white(int size, int row, int col, char k)
{
    if (row < size)
    {
        if (col < size)
        {
            cout << k;
            white(size, row, col + 1, k);
        }
        else
        {
            cout << endl;
            white(size, row + 1, 0, k);
        }
    }
}

void black(int size, int row, int col)
{
    if (row < size)
    {
        if (col < size)
        {
            cout << "  ";
            black(size, row, col + 1);
        }
        else
        {
            cout << endl;
            black(size, row + 1, 0);
        }
    }
}

void chessboard(int size, int i, int j, char k, char wb)
{
    if (i < size)
    {
        if (j < size)
        {
            if ((i + j) % 2 == 0)
            {
                white(size, 0, 0, k);
            }
            else
            {
                black(6, 0, 0);
            }
            chessboard(size, i, j + 1, k, wb);
        }
        else
        {
            cout << "\n";
            chessboard(size, i + 1, 0, k, wb);
        }
    }
    return;
}
