// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
#include <string>
using namespace std;
void capitalize(string &name, int size);
void conversion(string &name, int iterator);
void removeDupes(string &name, string &temp, int i);
string removeDupes(string &name);
void removeZeroes(string &name, string &result, int iterator);
string trunc(string &name, string &result, int iterator);
string pad(string &name, int iterator);
string removeSpecials(string &name, int i);
string soundex(const string &name);

int main()
{
    string name;
    cout << "Enter your name to be checked in the Soundex Program: \n";
    getline(cin, name);

    // Step 1: Capitalize the string
    capitalize(name, name.length());
    cout << "Capitalized: " << name << endl;

    // Step 2: Remove special characters
    removeSpecials(name, 0);

    // Step 3: Convert characters
    conversion(name, 1);
    cout << "Converted: " << name << endl;

    // Step 4: Remove duplicates
    name = removeDupes(name);
    cout << "Without Duplicates: " << name << endl;

    // Step 5: Remove zeroes
    string result;
    removeZeroes(name, result, 0);
    cout << "Without Zeroes: " << result << endl;

    // Step 6: Truncate or Pad (assuming trunc and pad functions exist)
    if (result.length() > 4)
    {
        string truncatedResult = ""; // Initialize an empty string
        cout << "Truncated: " << trunc(result, truncatedResult, 0) << endl;
        cout << "Final Result: " << soundex(truncatedResult) << endl;
    }
    else if (result.length() < 4)
    {
        result = pad(result, result.size());
        cout << "Padded: " << result << endl;
        cout << "Final Result: " << soundex(result) << endl;
    }
    else
    {
        cout << "Result: " << result << endl;
        cout << "Final Result: " << soundex(result) << endl;
    }

    return 0;
}

void capitalize(string &name, int size)
{
    // Base case
    if (size <= 0)
    {
        return;
    }

    name[size - 1] = toupper(name[size - 1]);

    capitalize(name, size - 1);
}
void conversion(string &name, int iterator)
{
    // Base Case:
    if (iterator < name.size())
    {
        // Check for the characters and perform replacements
        char currentChar = name[iterator];
        if (currentChar == 'A' || currentChar == 'E' || currentChar == 'I' || currentChar == 'O' ||
            currentChar == 'U' || currentChar == 'H' || currentChar == 'W' || currentChar == 'Y')
        {
            name[iterator] = '0';
        }
        else if (currentChar == 'B' || currentChar == 'F' || currentChar == 'P' || currentChar == 'V')
        {
            name[iterator] = '1';
        }
        else if (currentChar == 'C' || currentChar == 'G' || currentChar == 'J' || currentChar == 'K' ||
                 currentChar == 'Q' || currentChar == 'S' || currentChar == 'X' || currentChar == 'Z')
        {
            name[iterator] = '2';
        }
        else if (currentChar == 'D' || currentChar == 'T')
        {
            name[iterator] = '3';
        }
        else if (currentChar == 'M' || currentChar == 'N')
        {
            name[iterator] = '4';
        }
        else if (currentChar == 'L')
        {
            name[iterator] = '5';
        }
        else if (currentChar == 'R')
        {
            name[iterator] = '6';
        }

        conversion(name, iterator + 1);
    }
}
void removeDupes(string &name, string &temp, int i)
{
    // Base case:
    if (i == name.size() - 1)
    {
        temp += name[i];
        return;
    }

    // Check if the current character is different from the next one
    if (name[i] != name[i + 1])
    {
        temp += name[i];
    }

    removeDupes(name, temp, i + 1);
}

string removeDupes(string &name)
{
    string temp;
    removeDupes(name, temp, 0);
    return temp;
}
void removeZeroes(string &name, string &result, int iterator)
{
    if (iterator < name.length())
    {
        if (name[iterator] != '0')
        {
            result += name[iterator];
        }
        removeZeroes(name, result, iterator + 1);
    }
    else
    {
        return;
    }
}

string trunc(string &name, string &result, int iterator)
{
    if (iterator < 4 && iterator < name.size())
    {
        result += name[iterator];
        return trunc(name, result, iterator + 1);
    }
    return result;
}

string pad(string &name, int iterator)
{
    if (iterator < 4)
    {

        name += '0';

        pad(name, iterator + 1);
    }
    return name;
}
string removeSpecials(string &name, int i)
{
    if (i < name.size())
    {
        if (name[i] <= 'A' || name[i] >= 'Z')
        {
            name[i] = '0';
        }

        removeSpecials(name, i + 1);
    }
    return name;
}
string soundex(const string &name)
{
    return name;
}