// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
using namespace std;
void printPattern(int row, int col, int size);
void printLine(int size, int row, int col);

int main()
{
    printPattern(0, 0, 5);
    return 0;
}
void printLine(int size, int row, int col)
{
    if (size > 0)
    {
        if (row == 0 || row == size)
        {
            cout << "*";
            printLine(size - 1, row, col);
        }
        else
        {
            printLine(size - 1, row, col - 1);
        }
    }
}
void printPattern(int row, int col, int size)
{
    if (size == 0)
    {
        return;
    }
    else
    {
        printLine(size, row, col);
        cout << endl;
        printPattern(row, col, size - 1);
    }
}