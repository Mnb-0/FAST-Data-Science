// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
using namespace std;
void populateArray(int **arr, int m, int n, int cols);
void createArray(int **&arr, int m, int n);
void displayArray(int **arr, int m, int n, int rows, int cols);
void deleteArray(int **&arr, int m);
int calc(int **arr, int i, int j, int maxSum);
void maxHourGlass(int **inputArr, int inputRows, int inputCols);
int rows, cols;

int main()
{
    int rows, cols;
    cout << "Enter the number of rows: ";
    cin >> rows;
    cout << "Enter the number of columns: ";
    cin >> cols;

    int **arr = new int *[rows];
    createArray(arr, rows, cols);
    populateArray(arr, rows, cols, cols);
    cout << "Array elements: \n";
    displayArray(arr, 0, 0, rows, cols);
    maxHourGlass(arr, rows, cols);
    deleteArray(arr, rows);
    delete[] arr;

    return 0;
}

void populateArray(int **arr, int m, int n, int cols)
{
    if (m > 0)
    {
        if (n > 0)
        {
            cout << "Enter a value for arr[" << m - 1 << "][" << n - 1 << "]: ";
            cin >> arr[m - 1][n - 1];
            populateArray(arr, m, n - 1, cols);
        }
        else
        {
            populateArray(arr, m - 1, cols, cols);
        }
    }
}

void createArray(int **&arr, int m, int n)
{
    if (m > 0)
    {
        createArray(arr, m - 1, n);
        arr[m - 1] = new int[n];
    }
}

void displayArray(int **arr, int m, int n, int rows, int cols)
{
    if (m < rows)
    {
        if (n < cols)
        {
            cout << arr[m][n] << " ";
            displayArray(arr, m, n + 1, rows, cols);
        }
        else
        {
            cout << endl;
            displayArray(arr, m + 1, 0, rows, cols);
        }
    }
    return;
}
void deleteArray(int **&arr, int m)
{
    if (m > 0)
    {
        delete[] arr[m - 1];
        deleteArray(arr, m - 1);
    }
}
int calc(int **arr, int i, int j, int maxSum)
{
    if (i >= rows - 2)
    {
        return maxSum;
    }
    if (j >= cols - 2)
    {
        return calc(arr, i + 1, 0, maxSum);
    }
    int sum = arr[i][j] + arr[i][j + 1] + arr[i][j + 2] + arr[i + 1][j + 1] + arr[i + 2][j] + arr[i + 2][j + 1] + arr[i + 2][j + 2];
    if (sum > maxSum)
    {
        maxSum = sum;
    }
    return calc(arr, i, j + 1, maxSum);
}

void maxHourGlass(int **inputArr, int inputRows, int inputCols)
{
    rows = inputRows;
    cols = inputCols;
    int maxSum = calc(inputArr, 0, 0, -1);
    cout << "Maximum Hourglass Sum: " << maxSum << endl;
}