// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
using namespace std;
void populateArray(int **arr, int m, int n, int cols);
void createArray(int **&arr, int m, int n);
void displayArray(int **arr, int m, int n, int rows, int cols);
void deleteArray(int **&arr, int m);
void getInput(int &val);
int liveCell();
int main()
{
    int rows, cols;
    cout << "Enter the number of rows: ";
    cin >> rows;
    cout << "Enter the number of columns: ";
    cin >> cols;

    int **arr = new int *[rows];
    createArray(arr, rows, cols);         // creation
    populateArray(arr, rows, cols, cols); // population
    cout << "Array elements: \n";
    displayArray(arr, 0, 0, rows, cols); // display
    deleteArray(arr, rows);              // deletion
    delete[] arr;

    return 0;
}

void populateArray(int **arr, int m, int n, int cols)
{
    if (m > 0)
    {
        if (n > 0)
        {
            cout << "Enter a value for arr[" << m - 1 << "][" << n - 1 << "]: ";
            cin >> arr[m - 1][n - 1];
            populateArray(arr, m, n - 1, cols);
        }
        else
        {
            populateArray(arr, m - 1, cols, cols); // Move to the next row and reset n to cols
        }
    }
}

void createArray(int **&arr, int m, int n)
{
    if (m > 0)
    {
        createArray(arr, m - 1, n);
        arr[m - 1] = new int[n]; // Allocate memory for each row
    }
}

void displayArray(int **arr, int m, int n, int rows, int cols)
{
    if (m < rows)
    {
        if (n < cols)
        {
            cout << arr[m][n] << " ";
            displayArray(arr, m, n + 1, rows, cols); // Continue to the next column
        }
        else
        {
            cout << endl;                            // New line for the next row
            displayArray(arr, m + 1, 0, rows, cols); // Move to the next row and reset n to 0
        }
    }
    return;
}
void deleteArray(int **&arr, int m)
{
    if (m > 0)
    {
        delete[] arr[m - 1];
        deleteArray(arr, m - 1);
    }
}
void getInput(int &val)
{
    cin >> val;
    if (val != 0 && val != 1)
    {
        cout << "Invalid input. Please enter either 0 or 1: ";
        getInput(val);
    }
}