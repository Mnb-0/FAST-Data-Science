// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
using namespace std;
int countRoutes(int street, int avenue);
int main()
{
    int street, avenue;
    cout << "Enter a street and an avenue: \n";
    cin >> street >> avenue;
    cout << countRoutes(street, avenue);
    return 0;
}
int countRoutes(int street, int avenue)
{
    if (street == 1 && avenue == 1)
    {
        return 1;
    }

    int westMove = 0;
    int southMove = 0;
    if (avenue > 1)
    {
        westMove = westMove + countRoutes(street, avenue - 1);
    }
    if (street > 1)
    {
        southMove = southMove + countRoutes(street - 1, avenue);
    }
    return westMove + southMove;
}