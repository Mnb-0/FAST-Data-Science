// Muhammad Muneeb Lone || 23i-2623 || Assignment #2
#include <iostream>
#include <string>
using namespace std;
void lowerHalf(int count, int size);
void printLine(const string &line);
void upperHalf(int count, int size);

int main()
{
    int count, Trows, Brows;
    cout << "Enter count: ";
    cin >> count;
    cout << "\nEnter Top Rows: ";
    cin >> Trows;
    cout << "\nEnter Bottom Rows: ";
    cin >> Brows;
    cout << endl;
    upperHalf(count, Trows);
    lowerHalf(count, Brows);
    return 0;
}
void printLine(const string &line)
{
    cout << line << endl;
}

void lowerHalf(int count, int size)
{
    if (size <= 0)
        return;

    string line(count - size, ' ');
    line += string(2 * size - 1, '*');
    printLine(line);

    lowerHalf(count, size - 1);
}
void upperHalf(int count, int size)
{
    if (size <= 0)
        return;

    string line(count - size, ' ');
    line += string(2 * size - 1, '*');
    printLine(line);

    upperHalf(count, size - 1);
}