#ifndef PLAYER_H
#define PLAYER_H

#include <string>

class Player
{
protected:
    std::string name;
    int score;
    int lives;
    static int playerNum;

public:
    // Constructors
    Player();

    // Getters
    std::string getName() const;
    int getScore() const;
    int getLives() const;
    static int getPlayerNum();

    // Setters
    void setName(std::string name);
    void setScore(int score);
    void setLives(int lives);

    // Other
    void resetPlayer();
    void addScore();
    void subLives();
};

#endif // PLAYER_H
