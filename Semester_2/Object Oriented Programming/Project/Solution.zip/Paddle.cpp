#include "Paddle.h"
#include "util.h" 

// Constructors
Paddle::Paddle() : x(60), y(80), width(100), height(20), color(colors[BLACK])
{
}

Paddle::Paddle(float y) : x(60), y(y), width(100), height(20), color(colors[BLACKO])
{
}

// Getters
float Paddle::getX() const
{
    return x;
}

float Paddle::getY() const
{
    return y;
}

float Paddle::getWidth() const
{
    return width;
}

float Paddle::getHeight() const
{
    return height;
}

float *Paddle::getColor() const
{
    return color;
}

// Setters
void Paddle::setX(float x)
{
    this->x = x;
}

void Paddle::setY(float y)
{
    this->y = y;
}

void Paddle::setWidth(float width)
{
    this->width = width;
}

void Paddle::setColor(float *color)
{
    this->color = color;
}

// Other
void Paddle::Draw() const
{
    DrawRectangle(x, y, width, height, color);
}
