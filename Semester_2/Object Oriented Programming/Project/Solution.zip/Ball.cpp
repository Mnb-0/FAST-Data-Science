#include "Ball.h"
#include "util.h" 

// Constructor
Ball::Ball(float startX, float startY, float startRadius, float startDx, float startDy, float *ballColor)
    : x(startX), y(startY), radius(startRadius), dx(startDx), dy(startDy), color(ballColor)
{
}

// Getter methods
float Ball::getX() const
{
    return x;
}

float Ball::getY() const
{
    return y;
}

float Ball::getRadius() const
{
    return radius;
}

float Ball::getDx() const
{
    return dx;
}

float Ball::getDy() const
{
    return dy;
}

float *Ball::getColor() const
{
    return color;
}

// Setter methods
void Ball::setPosition(float x, float y)
{
    this->x = x;
    this->y = y;
}

void Ball::setVelocity(float dx, float dy)
{
    this->dx = dx;
    this->dy = dy;
}

void Ball::setColor(float *newColor)
{
    color = newColor;
}

// General Functions
void Ball::Draw() const
{
    DrawCircle(x, y, radius, color);
}
