#ifndef PADDLE_H
#define PADDLE_H

class Paddle
{
protected:
    float x;
    float y;
    float width;
    float height;
    float *color;

public:
    // Constructors
    Paddle();
    Paddle(float y);

    // Getters
    float getX() const;
    float getY() const;
    float getWidth() const;
    float getHeight() const;
    float *getColor() const;

    // Setters
    void setX(float x);
    void setY(float y);
    void setWidth(float width);
    void setColor(float *color);

    // Other
    virtual void Draw() const;
};

#endif // PADDLE_H
