//============================================================================
// Name        : .cpp
// Author      : Sibt ul Hussain
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Brickbreaker
//============================================================================
#ifndef BRICKBREAKER_CPP
#define BRICKBREAKER_CPP
#include "util.h"
#include <iostream>
#include <string>
#include <cmath> // for basic math functions such as cos, sin, sqrt
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
// #include "Player.h"
// #include "Paddle.h"
// #include "Brick.h"
// #include "Stage.h"
// #include "Food.h"
// #include "Ball.h"
// #include "Game.h"

using namespace std;

class DrawableObject
{
public:
	virtual void Draw() const = 0;
	virtual ~DrawableObject() {}
};
class Player
{
protected:
	string name;
	int score;
	int lives;
	static int playerNum;

public:
	// Constructors
	Player() : score(0), lives(2)
	{
		name = "Player " + to_string(++playerNum);
	}

	// Getters
	string getName() const { return name; }
	int getScore() const { return score; }
	int getLives() const { return lives; }
	static int getPlayerNum() { return playerNum; }

	// Setters
	void setName(string name) { this->name = name; }
	void setScore(int score) { this->score = score; }
	void setLives(int lives) { this->lives = lives; }

	// Other
	void resetPlayer()
	{
		this->lives = 2;
		this->score = 0;
	}

	void addScore()
	{
		this->score += 1;
	}

	void subLives()
	{
		lives--;
	}
};
int Player::playerNum = 0;
class Paddle
{
protected:
	float x;
	float y;
	float width;
	float height;
	float *color;

public:
	// Constructors
	Paddle() : x(60), y(80), width(100), height(20), color(colors[BLACK]) {}

	Paddle(float y) : x(60), y(y), width(100), height(20), color(colors[BLACKO]) {}

	// Getters
	float getX() const { return x; }
	float getY() const { return y; }
	float getWidth() const { return width; }
	float getHeight() const { return height; }
	float *getColor() const { return color; }

	// Setters
	void setX(float x) { this->x = x; }
	void setY(float y) { this->y = y; }
	void setWidth(float width) { this->width = width; }
	void setColor(float *color) { this->color = color; }

	virtual void Draw() const
	{
		DrawRectangle(x, y, width, height, color);
	}
};

class Brick
{
protected:
	float x;
	float y;
	int durability;
	float *color;

public:
	// Constructors
	Brick() : x(10000), y(10000), durability(1), color(colors[GREEN]) {}
	Brick(float x, float y, int durability, float *color) : x(x), y(y), durability(durability), color(color) {}

	// Getters
	float getX() const { return x; }
	float getY() const { return y; }
	int getDurability() const { return durability; }
	float *getColor() const { return color; }

	// Setters
	void setX(float x) { this->x = x; }
	void setY(float y) { this->y = y; }
	void setDurabilitiy(int durability) { this->durability = durability; }
	void setColor(float *color) { this->color = color; }
	void setPos(float x, float y)
	{
		this->x = x;
		this->y = y;
	}

	virtual void Draw()
	{
		DrawRectangle(x, y, 100, 20, color);
	}
};

class Stage : public Brick
{
protected:
	int lvl;
	int maxScore;
	int players;
	int rows;
	int cols;
	bool lvlChange;
	Brick **grid;

public:
	// Constructor
	Stage(int lvl = 1, int rows = 5, int cols = 10) : lvl(lvl), rows(rows), cols(cols)
	{
		grid = new Brick *[rows];
		for (int i = 0; i < rows; i++)
		{
			grid[i] = new Brick[cols];
		}
		if (lvl == 1)
		{
			players = 1;
			maxScore = 50;
			level1();
		}
		else if (lvl == 2)
		{
			players = 1;
			maxScore = 55;
			level2();
		}
		else if (lvl == 3)
		{
			lvlChange = true;
			players = 2;
			maxScore = 105;
			level3();
		}
	}
	// Getters
	int getLevel() const { return lvl; }
	Brick **getGrid() { return grid; }
	int getRows() const { return rows; }
	int getCols() const { return cols; }

	// Levels Logic

	void loadLevel()
	{
		switch (lvl)
		{
		case 2:
			players = 1;
			maxScore = 40;
			level2();
			break;

		case 3:
			players = 2;
			maxScore = 100;
			level3();
			break;

		default:
			players = 1;
			maxScore = INT_MAX;
			// levelDef();
			break;
		}
	}
	void level1()
	{
		srand(time(NULL));
		int num = 0;
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				num = rand() % 5;
				switch (num)
				{
				case 4:
					grid[i][j] = Brick(j * 100, 650 - i * 20, 2, colors[DARK_GOLDEN_ROD]); // Yellow
					break;
				case 3:
					grid[i][j] = Brick(j * 100, 650 - i * 20, 1, colors[GREEN]);
					break;
				case 2:
					grid[i][j] = Brick(j * 100, 650 - i * 20, 2, colors[DEEP_PINK]);
					break;
				case 1:
					grid[i][j] = Brick(j * 100, 650 - i * 20, 3, colors[RED]);
					break;
				case 0:
					grid[i][j] = Brick(j * 100, 650 - i * 20, 3, colors[BLUE]);
					break;
				default:
					break;
				}
			}
		}
	}
	void level2()
	{
		srand(time(NULL));

		int numBricks = 5;
		int brickPattern[5][3] = {
			{0, 650, 3},   // Brick at (0, 650)
			{200, 630, 3}, // Brick at (200, 630)
			{430, 595, 1}, // Brick at (430, 595)
			{200, 530, 2}, // Brick at (200, 530)
			{0, 500, 2}	   // Brick at (0, 500)
		};

		// Loop through each brick in the pattern
		for (int i = 0; i < numBricks; ++i)
		{
			int num = rand() % 5;
			float *color;
			int dur;
			switch (num)
			{
			case 4:
				color = colors[DARK_GOLDEN_ROD]; // Yellow
				dur = 2;
				break;
			case 3:
				color = colors[GREEN];
				dur = 1;
				break;
			case 2:
				color = colors[DEEP_PINK];
				dur = 2;
				break;
			case 1:
				color = colors[RED];
				dur = 3;
				break;
			case 0:
				color = colors[BLUE];
				dur = 3;
				break;
			default:
				break;
			}

			// Assign the randomly selected color and durability to the current brick
			grid[i][0] = Brick(brickPattern[i][0], brickPattern[i][1], dur, color);
		}
	}
	void seeder()
	{
		srand(time(NULL));
	}

	void level3(int i = 0, int j = 0)
	{
		seeder();
		if (i == rows)
		{
			lvlChange = true;
			return; // Base case: if we have filled all rows
		}

		if (j == cols)
		{
			level3(i + 1, 0); // Move to the next row
			return;
		}

		int num = rand() % 5;
		switch (num)
		{
		case 4:
			grid[i][j] = Brick(j * 100, 650 - i * 20, 2, colors[DARK_GOLDEN_ROD]); // Yellow
			break;
		case 3:
			grid[i][j] = Brick(j * 100, 650 - i * 20, 1, colors[GREEN]);
			break;
		case 2:
			grid[i][j] = Brick(j * 100, 650 - i * 20, 2, colors[DEEP_PINK]);
			break;
		case 1:
			grid[i][j] = Brick(j * 100, 650 - i * 20, 3, colors[RED]);
			break;
		case 0:
			grid[i][j] = Brick(j * 100, 650 - i * 20, 3, colors[BLUE]);
			break;
		default:
			break;
		}

		level3(i, j + 1); // Move to the next column
	}
	void setLevel(int lvl)
	{
		this->lvl = lvl;
	}
	virtual void Draw()
	{
		for (int i = 0; i < rows; ++i)
		{
			for (int j = 0; j < cols; ++j)
			{
				// Place the brick
				grid[i][j].Draw();
			}
		}
	}

	// Copy Constructor
	Stage(const Stage &other)
	{
		lvl = other.lvl;
		maxScore = other.maxScore;
		players = other.players;
		rows = other.rows;
		cols = other.cols;
		lvlChange = other.lvlChange;

		// Deep copy the grid
		grid = new Brick *[rows];
		for (int i = 0; i < rows; i++)
		{
			grid[i] = new Brick[cols];
			for (int j = 0; j < cols; j++)
			{
				grid[i][j] = other.grid[i][j];
			}
		}
	}

	// Destructor
	~Stage()
	{
		// Deallocate the grid
		for (int i = 0; i < rows; i++)
		{
			delete[] grid[i];
		}
		delete[] grid;
	}
};

class Food
{
protected:
	float foodX;
	float foodY;
	float dy;
	float *color;
	char shape;
	bool active;
	bool drawn;

public:
	Food() : foodX(-1000), foodY(-1000), dy(-2.0), color(colors[WHITE]), shape('/0'), active(false), drawn(false) {}

	// Getters
	float getX() const { return foodX; }
	float getY() const { return foodY; }
	int getDy() const { return dy; }
	bool getPowerStatus() const { return active; }
	bool getDrawStatus() const { return drawn; }
	char getShape() const { return shape; }

	// Setters
	void setStatus(bool active) { this->active = active; }
	void setX(float x) { foodX = x; }
	void setY(float y) { foodY = y; }
	void setColor(float *color) { this->color = color; }

	// Other
	virtual void Draw()
	{

		if (!(active && !drawn))
		{
			const int size = 15;
			if (color == colors[GREEN])
			{
				DrawTriangle(foodX + 50, foodY, foodX + 50 + size, foodY + size, foodX + 50 - size, foodY + size, colors[GREEN]);
				shape = 'T';
			}
			else if (color == colors[DEEP_PINK])
			{
				DrawSquare(foodX + 50, foodY, size, colors[DEEP_PINK]);
				shape = 'S';
			}
			else if (color == colors[BLUE])
			{
				DrawCircle(foodX + 50, foodY, size, colors[BLUE]);
				shape = 'C';
			}
			else if (color == colors[RED])
			{
				DrawSquare(foodX + 50, foodY, size, colors[RED]);
				shape = 's';
			}
			else if (color == colors[DARK_GOLDEN_ROD])
			{
				DrawSquare(foodX + 50, foodY, size, colors[DARK_GOLDEN_ROD]);
			}
			else
			{
			}
			drawn = true;
		}
	}

	void spawnFood(float x, float y)
	{
		foodX = x;
		foodY = y;
		drawn = false;
	}

	void move()
	{
		foodY += dy; // Move downwards
	}
};

class Ball
{
protected:
	float x;
	float y;
	float dx;
	float dy;
	float radius;
	float *color;

public:
	Ball(float startX = 400, float startY = 300, float startRadius = 10, float startDx = 5, float startDy = 5, float *ballColor = colors[CRIMSON]) : x(startX), y(startY), radius(startRadius), dx(startDx), dy(startDy), color(ballColor) {}

	// Getter methods

	float getX() const { return x; }
	float getY() const { return y; }
	float getRadius() const { return radius; }
	float getDx() const { return dx; }
	float getDy() const { return dy; }
	float *getColor() const { return color; }

	// Setter methods
	void setPosition(float x, float y)
	{
		this->x = x;
		this->y = y;
	}
	void setVelocity(float dx, float dy)
	{
		this->dx = dx;
		this->dy = dy;
	}
	void setColor(float *newColor) { color = newColor; }

	// General Functions

	void Draw() const // Drawing the ball
	{
		DrawCircle(x, y, radius, color);
	}
};

class Game : public Stage, public Player, public Paddle, public Brick, public Food, public Ball
{
public:
	bool gameOver;
	bool saved;
	bool state;
	Paddle paddle2;

public:
	// Constructor
	Game() : gameOver(false), saved(false), paddle2(750) {}

	// Display Function
	void Display()
	{
		if (getLives() > 0)
		{
			DrawString(5, 820, " 23i-2623 || Muneeb Lone ", colors[BLACK]);
			string score = to_string(getScore());
			DrawString(330, 820, " Score: ", colors[BLACK]);
			DrawString(400, 820, score, colors[BLACK]);
			DrawString(500, 820, "High Score: ", colors[BLACK]);
			DrawString(620, 820, to_string(retrieveScore()), colors[BLACK]);
			DrawString(700, 820, "Lives: ", colors[BLACK]);
			DrawString(760, 820, to_string(getLives()), colors[BLACK]);

			if (Player::getScore() >= 50)
			{
				Stage::setLevel(2);
				Stage::loadLevel();
				state = false;
			}

			if (Player::getScore() >= 55)
			{
				Stage::setLevel(3);
				Stage::loadLevel();
			}

			Stage::Draw();
			Paddle::Draw();
			if (Stage::getLevel() == 3)
			{
				paddle2.Draw();
			}
			Ball::Draw();
			Food::Draw();
		}
		else
		{
			DrawString(410, 384, "GAME OVER", colors[CRIMSON]);
			if (saved == false)
			{
				saveScore();
				saved = true;
			}
		}
	}

	// Movement Logics
	void ballMove()
	{
		Ball::setPosition(Ball::getX() + Ball::getDx(), Ball::getY() + Ball::getDy());

		// Get the ball's position and radius
		float ballX = Ball::getX();
		float ballY = Ball::getY();
		float ballRadius = Ball::getRadius();

		// Get the window dimensions
		int windowWidth = 1020; // Assuming the window width is 1020
		int windowHeight = 800; // Assuming the window height is 840

		// Bounce off the left and right edges
		if (ballX - ballRadius <= 0 || ballX + ballRadius >= windowWidth)
		{
			Ball::setVelocity(-Ball::getDx(), Ball::getDy()); // Reverse the horizontal velocity
		}

		// Bounce off the top edge
		if (ballY + ballRadius >= windowHeight)
		{
			Ball::setVelocity(Ball::getDx(), -Ball::getDy()); // Reverse the vertical velocity
		}

		// Check for game over (ball falls off the bottom edge)
		if (ballY - ballRadius <= 0)
		{
			Ball::setPosition(400, 400); // Reset ball position
			Ball::setVelocity(5, 5);	 // Reset ball velocity
			subLives();					 // Subtract a life
		}
	}

	void paddleMove(int x)
	{
		float newX = x - Paddle::getWidth() / 2;

		if (newX < 0)
		{
			newX = 0;
		}
		else if (newX + Paddle::getWidth() > 1020)
		{
			newX = 1020 - Paddle::getWidth(); // Adjust to the right boundary
		}

		// Update the x-coordinate of the paddle
		Paddle::setX(newX);
	}

	void paddle2Move(int x)
	{
		float newX = x;
		if (newX < 0)
		{
			newX = 0;
		}
		else if (newX + paddle2.getWidth() > 1020)
		{
			newX = 1020 - paddle2.getWidth();
		}
		paddle2.setX(newX);
	}

	void foodMove()
	{
		Food::setY(Food::getY() + Food::getDy());
	}

	void spawnFood(float x, float y)
	{
		Food::spawnFood(x, y);
	}

	// Collision Logics

	void paddleCollision()
	{
		float ballTop = Ball::getY() + Ball::getRadius();
		float ballBottom = Ball::getY() - Ball::getRadius();
		float ballRight = Ball::getX() + Ball::getRadius();
		float ballLeft = Ball::getX() - Ball::getRadius();

		float paddle1Top = Paddle::getY() + Paddle::getHeight();
		float paddle1Right = Paddle::getX() + Paddle::getWidth();

		// Calculate the ball's next position in the next frame
		float nextBallX = Ball::getX() + Ball::getDx();
		float nextBallY = Ball::getY() + Ball::getDy();

		// Check collision with the first paddle
		if (nextBallX + Ball::getRadius() >= Paddle::getX() && nextBallX - Ball::getRadius() <= paddle1Right &&
			nextBallY - Ball::getRadius() <= paddle1Top && nextBallY + Ball::getRadius() >= Paddle::getY())
		{
			// Collision detected, adjust the ball's position and direction
			Paddle::setColor(Ball::getColor()); // Paddle color change bonus
			Ball::setPosition(Ball::getX(), Paddle::getY() + Paddle::getHeight() + Ball::getRadius());
			Ball::setVelocity(Ball::getDx(), -Ball::getDy());
		}

		// Check collision with the second paddle
		float paddle2Top = paddle2.getY() + paddle2.getHeight();
		float paddle2Right = paddle2.getX() + paddle2.getWidth();

		if (nextBallX + Ball::getRadius() >= paddle2.getX() && nextBallX - Ball::getRadius() <= paddle2Right &&
			nextBallY - Ball::getRadius() <= paddle2Top && nextBallY + Ball::getRadius() >= paddle2.getY())
		{
			// Collision detected, adjust the ball's position and direction
			paddle2.setColor(Ball::getColor()); // Paddle color change bonus
			Ball::setPosition(Ball::getX(), paddle2.getY() - Ball::getRadius());
			Ball::setVelocity(Ball::getDx(), -Ball::getDy());
		}
	}

	void brickCollision()
	{
		float ballTop = Ball::getY() + Ball::getRadius();
		float ballBottom = Ball::getY() - Ball::getRadius();
		float ballRight = Ball::getX() + Ball::getRadius();
		float ballLeft = Ball::getX() - Ball::getRadius();
		Brick **grid = Stage::getGrid(); // Copy constructor bonus
		for (int i = 0; i < Stage::getRows(); i++)
		{
			for (int j = 0; j < Stage::getCols(); j++)
			{
				Brick &brick = grid[i][j];
				if (brick.getDurability() > 0)
				{
					float brickRight = brick.getX() + 100;
					float brickBottom = brick.getY() - 20;

					bool xCollision = ballRight >= brick.getX() && ballLeft <= brickRight;
					bool yCollision = ballTop >= brickBottom && ballBottom <= brick.getY();

					if (xCollision && yCollision)
					{
						Ball::setColor(brick.getColor()); // Ball color change bonus
						brick.setDurabilitiy(brick.getDurability() - 1);
						if (brick.getDurability() == 0)
						{
							addScore();
							spawnFood(brick.getX(), brick.getY());
							brick.setPos(-1000, -1000); // brick shifted off screen
						}

						// Reverse the ball's velocity
						Ball::setVelocity(Ball::getDx(), -Ball::getDy());
						Food::setColor(brick.getColor());
						return;
					}
				}
			}
		}
	}

	// File Handling

	void saveScore()
	{
		static bool saved = false; // Static variable to keep track of whether score has been saved
		if (!saved)				   // Check if score hasn't been saved already
		{
			ofstream outFile("score.txt", ios::app);
			if (outFile.is_open())
			{
				// Write player's name and score to the file
				outFile << name << endl;
				outFile << score << endl;
				outFile.close();
				cout << "Score added." << endl;
			}
			else
			{
				cout << "Error creating file!" << endl;
			}
			saved = true;
		}
	}

	int retrieveScore(string fileName = "score.txt")
	{
		ifstream inFile("score.txt");
		int highScore = 0;
		if (inFile.is_open())
		{
			string Playername;
			string scoreSt;
			while (!inFile.eof()) // Read name and score pair until end of file
			{
				getline(inFile, Playername);
				getline(inFile, scoreSt);
				int score = stoi(scoreSt);
				if (int(score) > highScore)
				{
					highScore = int(score);
				}
			}
			inFile.close();
		}
		else
		{
			cout << "Error: Unable to open file!" << endl;
		}
		return highScore;
	}

	// Powerup logics
	void applyPower(float *color)
	{
		if (Food::getPowerStatus() == false)
		{
			Food::setStatus(true);
			if (color == colors[GREEN])
			{
				Paddle::setWidth(Paddle::getWidth() * 2);
			}
			else if (color == colors[DEEP_PINK])
			{
				Paddle::setWidth(Paddle::getWidth() / 2);
			}
			else if (color == colors[BLUE])
			{
				Ball::setVelocity(Ball::getDx() / 1.3, Ball::getDy() / 1.3);
			}
			else if (color == colors[RED])
			{
				Ball::setVelocity(Ball::getDx() * 1.3, Ball::getDy() * 1.3);
			}
		}
	}
	// Idk why I made this
	void setGameState(bool state)
	{
		this->state = state;
	}
};

// GLOBAL VARIABLE
Game game;
// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

/*
 * Main Canvas drawing function.
 * */
void GameDisplay()
{
	// Clear the screen first
	glClearColor(1, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT);

	// Display game elements
	game.Display();
	game.ballMove();
	game.brickCollision();
	game.paddleCollision();
	game.foodMove();
	glutPostRedisplay();
	// Swap buffers
	glutSwapBuffers();
}

/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int x, int y)
{
	if (key == GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/)
	{
		// what to do when left key is pressed...
	}
	else if (key == GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/)
	{
	}
	else if (key == GLUT_KEY_UP /*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/)
	{
	}

	else if (key == GLUT_KEY_DOWN /*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/)
	{
	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();
}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y)
{
	if (key == 27 /* Escape key ASCII*/)
	{
		exit(1); // exit the program when escape key is pressed.
	}

	if (key == 'b' || key == 'B')
	{
		// do something if b is pressed
		game.setGameState(true);
	}
	if (key == 'r' || key == 'R')
	{
		game.paddle2Move(game.paddle2.getX() + 50);
	}
	if (key == 'w' || key == 'W')
	{
		game.paddle2Move(game.paddle2.getX() - 50);
	}

	glutPostRedisplay();
}

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m)
{
	game.ballMove();
	game.brickCollision();
	game.paddleCollision();

	// implement your functionality here

	// once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(1000.0, Timer, 0);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y)
{
	glutPostRedisplay();
}
void MouseMoved(int x, int y)
{
	game.paddleMove(x);
	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y)
{

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
	{
	}
	else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
	{
	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */
int main(int argc, char *argv[])
{

	int width = 1020, height = 840; // i have set my window size to be 800 x 600

	InitRandomizer();							  // seed the random number generator...
	glutInit(&argc, argv);						  // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(600, 60);			  // set the initial position of our window
	glutInitWindowSize(width, height);			  // set the size of our window
	glutCreateWindow("Meow");					  // set the title of our game window
	SetCanvasSize(width, height);				  // set the number of pixels...
	game.ballMove();
	game.brickCollision();
	game.paddleCollision();
	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	// glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay);	   // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys);   // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved);	  // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// Redraw the display
	glutPostRedisplay();

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif // !BRICKBREAKER_CPP
