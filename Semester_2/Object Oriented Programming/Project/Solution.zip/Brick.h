#ifndef BRICK_H
#define BRICK_H

class Brick
{
protected:
    float x;
    float y;
    int durability;
    float *color;

public:
    // Constructors
    Brick();
    Brick(float x, float y, int durability, float *color);

    // Getters
    float getX() const;
    float getY() const;
    int getDurability() const;
    float *getColor() const;

    // Setters
    void setX(float x);
    void setY(float y);
    void setDurability(int durability);
    void setColor(float *color);
    void setPos(float x, float y);

    // Other
    virtual void Draw();
};

#endif // BRICK_H
