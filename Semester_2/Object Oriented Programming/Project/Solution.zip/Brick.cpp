#include "Brick.h"
#include "util.h" 
// Constructors
Brick::Brick() : x(10000), y(10000), durability(1), color(colors[GREEN])
{
}

Brick::Brick(float x, float y, int durability, float *color) : x(x), y(y), durability(durability), color(color)
{
}

// Getters
float Brick::getX() const
{
    return x;
}

float Brick::getY() const
{
    return y;
}

int Brick::getDurability() const
{
    return durability;
}

float *Brick::getColor() const
{
    return color;
}

// Setters
void Brick::setX(float x)
{
    this->x = x;
}

void Brick::setY(float y)
{
    this->y = y;
}

void Brick::setDurability(int durability)
{
    this->durability = durability;
}

void Brick::setColor(float *color)
{
    this->color = color;
}

void Brick::setPos(float x, float y)
{
    this->x = x;
    this->y = y;
}

// Other
void Brick::Draw()
{
    DrawRectangle(x, y, 100, 20, color);
}
