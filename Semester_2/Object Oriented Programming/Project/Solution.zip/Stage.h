#ifndef STAGE_H
#define STAGE_H

#include "Brick.h"

class Stage : public Brick
{
protected:
    int lvl;
    int maxScore;
    int players;
    int rows;
    int cols;
    bool lvlChange;
    Brick **grid;

public:
    // Constructor
    Stage(int lvl = 1, int rows = 5, int cols = 10);

    // Getters
    int getLevel() const;
    Brick **getGrid();
    int getRows() const;
    int getCols() const;

    // Levels Logic
    void loadLevel();
    void level1();
    void level2();
    void seeder();
    void level3(int i = 0, int j = 0);
    void setLevel(int lvl);

    // Draw function
    virtual void Draw();

    // Copy Constructor
    Stage(const Stage &other);

    // Destructor
    ~Stage();
};

#endif // STAGE_H
