#ifndef FOOD_H
#define FOOD_H

class Food
{
protected:
    float foodX;
    float foodY;
    float dy;
    float *color;
    char shape;
    bool active;
    bool drawn;

public:
    // Constructor
    Food();

    // Getters
    float getX() const;
    float getY() const;
    float getDy() const;
    bool getPowerStatus() const;
    bool getDrawStatus() const;
    char getShape() const;

    // Setters
    void setStatus(bool active);
    void setX(float x);
    void setY(float y);
    void setColor(float *color);

    // Other
    virtual void Draw();
    void spawnFood(float x, float y);
    void move();
};

#endif // FOOD_H
