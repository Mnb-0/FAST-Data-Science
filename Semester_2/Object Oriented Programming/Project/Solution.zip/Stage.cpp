#include "Stage.h"
#include "util.h" 

// Constructor
Stage::Stage(int lvl, int rows, int cols) : lvl(lvl), rows(rows), cols(cols)
{
    grid = new Brick *[rows];
    for (int i = 0; i < rows; i++)
    {
        grid[i] = new Brick[cols];
    }
    if (lvl == 1)
    {
        players = 1;
        maxScore = 50;
        level1();
    }
    else if (lvl == 2)
    {
        players = 1;
        maxScore = 55;
        level2();
    }
    else if (lvl == 3)
    {
        lvlChange = true;
        players = 2;
        maxScore = 105;
        level3();
    }
}

// Getters
int Stage::getLevel() const
{
    return lvl;
}

Brick **Stage::getGrid()
{
    return grid;
}

int Stage::getRows() const
{
    return rows;
}

int Stage::getCols() const
{
    return cols;
}

// Levels Logic
void Stage::loadLevel()
{
    switch (lvl)
    {
    case 2:
        players = 1;
        maxScore = 40;
        level2();
        break;

    case 3:
        players = 2;
        maxScore = 100;
        level3();
        break;

    default:
        players = 1;
        maxScore = INT_MAX;
        // levelDef();
        break;
    }
}

void Stage::level1()
{
    seeder();
    int num = 0;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            num = rand() % 5;
            switch (num)
            {
            case 4:
                grid[i][j] = Brick(j * 100, 650 - i * 20, 2, colors[DARK_GOLDEN_ROD]); // Yellow
                break;
            case 3:
                grid[i][j] = Brick(j * 100, 650 - i * 20, 1, colors[GREEN]);
                break;
            case 2:
                grid[i][j] = Brick(j * 100, 650 - i * 20, 2, colors[DEEP_PINK]);
                break;
            case 1:
                grid[i][j] = Brick(j * 100, 650 - i * 20, 3, colors[RED]);
                break;
            case 0:
                grid[i][j] = Brick(j * 100, 650 - i * 20, 3, colors[BLUE]);
                break;
            default:
                break;
            }
        }
    }
}

void Stage::level2()
{
    seeder();
    int numBricks = 5;
    int brickPattern[5][3] = {
        {0, 650, 3},   // Brick at (0, 650)
        {200, 630, 3}, // Brick at (200, 630)
        {430, 595, 1}, // Brick at (430, 595)
        {200, 530, 2}, // Brick at (200, 530)
        {0, 500, 2}    // Brick at (0, 500)
    };

    for (int i = 0; i < numBricks; ++i)
    {
        int num = rand() % 5;
        float *color;
        int dur;
        switch (num)
        {
        case 4:
            color = colors[DARK_GOLDEN_ROD]; // Yellow
            dur = 2;
            break;
        case 3:
            color = colors[GREEN];
            dur = 1;
            break;
        case 2:
            color = colors[DEEP_PINK];
            dur = 2;
            break;
        case 1:
            color = colors[RED];
            dur = 3;
            break;
        case 0:
            color = colors[BLUE];
            dur = 3;
            break;
        default:
            break;
        }

        grid[i][0] = Brick(brickPattern[i][0], brickPattern[i][1], dur, color);
    }
}

void Stage::seeder()
{
    srand(time(NULL));
}

void Stage::level3(int i, int j)
{
    seeder();
    if (i == rows)
    {
        lvlChange = true;
        return;
    }

    if (j == cols)
    {
        level3(i + 1, 0);
        return;
    }

    int num = rand() % 5;
    switch (num)
    {
    case 4:
        grid[i][j] = Brick(j * 100, 650 - i * 20, 2, colors[DARK_GOLDEN_ROD]); // Yellow
        break;
    case 3:
        grid[i][j] = Brick(j * 100, 650 - i * 20, 1, colors[GREEN]);
        break;
    case 2:
        grid[i][j] = Brick(j * 100, 650 - i * 20, 2, colors[DEEP_PINK]);
        break;
    case 1:
        grid[i][j] = Brick(j * 100, 650 - i * 20, 3, colors[RED]);
        break;
    case 0:
        grid[i][j] = Brick(j * 100, 650 - i * 20, 3, colors[BLUE]);
        break;
    default:
        break;
    }

    level3(i, j + 1);
}

void Stage::setLevel(int lvl)
{
    this->lvl = lvl;
}

// Draw function
void Stage::Draw()
{
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            grid[i][j].Draw();
        }
    }
}

// Copy Constructor
Stage::Stage(const Stage &other)
{
    lvl = other.lvl;
    maxScore = other.maxScore;
    players = other.players;
    rows = other.rows;
    cols = other.cols;
    lvlChange = other.lvlChange;

    grid = new Brick *[rows];
    for (int i = 0; i < rows; i++)
    {
        grid[i] = new Brick[cols];
        for (int j = 0; j < cols; j++)
        {
            grid[i][j] = other.grid[i][j];
        }
    }
}

// Destructor
Stage::~Stage()
{
    for (int i = 0; i < rows; i++)
    {
        delete[] grid[i];
    }
    delete[] grid;
}
