#include "Player.h"
#include <string>

// Initialize static member
int Player::playerNum = 0;

// Constructors
Player::Player() : score(0), lives(2)
{
    name = "Player " + std::to_string(++playerNum);
}

// Getters
std::string Player::getName() const
{
    return name;
}

int Player::getScore() const
{
    return score;
}

int Player::getLives() const
{
    return lives;
}

int Player::getPlayerNum()
{
    return playerNum;
}

// Setters
void Player::setName(std::string name)
{
    this->name = name;
}

void Player::setScore(int score)
{
    this->score = score;
}

void Player::setLives(int lives)
{
    this->lives = lives;
}

// Other
void Player::resetPlayer()
{
    this->lives = 2;
    this->score = 0;
}

void Player::addScore()
{
    this->score += 1;
}

void Player::subLives()
{
    lives--;
}
