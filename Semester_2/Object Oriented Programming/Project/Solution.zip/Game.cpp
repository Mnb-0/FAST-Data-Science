#include "Game.h"
#include <iostream>

// Constructor
Game::Game() : gameOver(false), saved(false), paddle2(750)
{
}

// Display Function
void Game::Display()
{
    if (getLives() > 0)
    {
        DrawString(5, 820, " 23i-2623 || Muneeb Lone ", colors[BLACK]);
        std::string scoreStr = std::to_string(getScore());
        DrawString(330, 820, " Score: ", colors[BLACK]);
        DrawString(400, 820, scoreStr, colors[BLACK]);
        DrawString(500, 820, "High Score: ", colors[BLACK]);
        DrawString(620, 820, std::to_string(retrieveScore()), colors[BLACK]);
        DrawString(700, 820, "Lives: ", colors[BLACK]);
        DrawString(760, 820, std::to_string(getLives()), colors[BLACK]);

        if (Player::getScore() >= 50)
        {
            Stage::setLevel(2);
            Stage::loadLevel();
            state = false;
        }

        if (Player::getScore() >= 55)
        {
            Stage::setLevel(3);
            Stage::loadLevel();
        }

        Stage::Draw();
        Paddle::Draw();
        if (Stage::getLevel() == 3)
        {
            paddle2.Draw();
        }
        Ball::Draw();
        Food::Draw();
    }
    else
    {
        DrawString(410, 384, "GAME OVER", colors[CRIMSON]);
        if (saved == false)
        {
            saveScore();
            saved = true;
        }
    }
}

// Movement Logics
void Game::ballMove()
{
    Ball::setPosition(Ball::getX() + Ball::getDx(), Ball::getY() + Ball::getDy());

    // Get the ball's position and radius
    float ballX = Ball::getX();
    float ballY = Ball::getY();
    float ballRadius = Ball::getRadius();

    // Get the window dimensions
    int windowWidth = 1020;  // Assuming the window width is 1020
    int windowHeight = 800;  // Assuming the window height is 840

    // Bounce off the left and right edges
    if (ballX - ballRadius <= 0 || ballX + ballRadius >= windowWidth)
    {
        Ball::setVelocity(-Ball::getDx(), Ball::getDy()); // Reverse the horizontal velocity
    }

    // Bounce off the top edge
    if (ballY + ballRadius >= windowHeight)
    {
        Ball::setVelocity(Ball::getDx(), -Ball::getDy()); // Reverse the vertical velocity
    }

    // Check for game over (ball falls off the bottom edge)
    if (ballY - ballRadius <= 0)
    {
        Ball::setPosition(400, 300);  // Reset ball position
        Ball::setVelocity(5, 5);      // Reset ball velocity
        subLives();                    // Subtract a life
    }
}

void Game::paddleMove(int x)
{
    float newX = x - Paddle::getWidth() / 2;

    if (newX < 0)
    {
        newX = 0;
    }
    else if (newX + Paddle::getWidth() > 1020)
    {
        newX = 1020 - Paddle::getWidth(); // Adjust to the right boundary
    }

    // Update the x-coordinate of the paddle
    Paddle::setX(newX);
}

void Game::paddle2Move(int x)
{
    float newX = x;
    if (newX < 0)
    {
        newX = 0;
    }
    else if (newX + paddle2.getWidth() > 1020)
    {
        newX = 1020 - paddle2.getWidth();
    }
    paddle2.setX(newX);
}

void Game::foodMove()
{
    Food::setY(Food::getY() + Food::getDy());
}

void Game::spawnFood(float x, float y)
{
    Food::spawnFood(x, y);
}

// Collision Logics
void Game::paddleCollision()
{
    float ballTop = Ball::getY() + Ball::getRadius();
    float ballBottom = Ball::getY() - Ball::getRadius();
    float ballRight = Ball::getX() + Ball::getRadius();
    float ballLeft = Ball::getX() - Ball::getRadius();

    float paddle1Top = Paddle::getY() + Paddle::getHeight();
    float paddle1Right = Paddle::getX() + Paddle::getWidth();

    // Calculate the ball's next position in the next frame
    float nextBallX = Ball::getX() + Ball::getDx();
    float nextBallY = Ball::getY() + Ball::getDy();

    // Check collision with the first paddle
    if (nextBallX + Ball::getRadius() >= Paddle::getX() && nextBallX - Ball::getRadius() <= paddle1Right &&
        nextBallY - Ball::getRadius() <= paddle1Top && nextBallY + Ball::getRadius() >= Paddle::getY())
    {
        // Collision detected, adjust the ball's position and direction
        Paddle::setColor(Ball::getColor()); // Paddle color change bonus
        Ball::setPosition(Ball::getX(), Paddle::getY() + Paddle::getHeight() + Ball::getRadius());
        Ball::setVelocity(Ball::getDx(), -Ball::getDy());
    }

    // Check collision with the second paddle
    float paddle2Top = paddle2.getY() + paddle2.getHeight();
    float paddle2Right = paddle2.getX() + paddle2.getWidth();

    if (nextBallX + Ball::getRadius() >= paddle2.getX() && nextBallX - Ball::getRadius() <= paddle2Right &&
        nextBallY - Ball::getRadius() <= paddle2Top && nextBallY + Ball::getRadius() >= paddle2.getY())
    {
        // Collision detected, adjust the ball's position and direction
        paddle2.setColor(Ball::getColor()); // Paddle color change bonus
        Ball::setPosition(Ball::getX(), paddle2.getY() - Ball::getRadius());
        Ball::setVelocity(Ball::getDx(), -Ball::getDy());
    }
}

void Game::brickCollision()
{
    float ballTop = Ball::getY() + Ball::getRadius();
    float ballBottom = Ball::getY() - Ball::getRadius();
    float ballRight = Ball::getX() + Ball::getRadius();
    float ballLeft = Ball::getX() - Ball::getRadius();
    Brick **grid = Stage::getGrid(); // Copy constructor bonus
    for (int i = 0; i < Stage::getRows(); i++)
    {
        for (int j = 0; j < Stage::getCols(); j++)
        {
            Brick &brick = grid[i][j];
            if (brick.getDurability() > 0)
            {
                float brickRight = brick.getX() + 100;
                float brickBottom = brick.getY() - 20;

                bool xCollision = ballRight >= brick.getX() && ballLeft <= brickRight;
                bool yCollision = ballTop >= brickBottom && ballBottom <= brick.getY();

                if (xCollision && yCollision)
                {
                    Ball::setColor(brick.getColor()); // Ball color change bonus
                    brick.setDurability(brick.getDurability() - 1);
                    if (brick.getDurability() == 0)
                    {
                        addScore();
                        spawnFood(brick.getX(), brick.getY());
                        brick.setPos(-1000, -1000); // brick shifted off screen
                    }

                    // Reverse the ball's velocity
                    Ball::setVelocity(Ball::getDx(), -Ball::getDy());
                    Food::setColor(brick.getColor());
                    return;
                }
            }
        }
    }
}

// File Handling
void Game::saveScore()
{
    static bool saved = false; // Static variable to keep track of whether score has been saved
    if (!saved)                // Check if score hasn't been saved already
    {
        std::ofstream outFile("score.txt", std::ios::app);
        if (outFile.is_open())
        {
            // Write player's name and score to the file
            outFile << name << std::endl;
            outFile << score << std::endl;
            outFile.close();
            std::cout << "Score added." << std::endl;
        }
        else
        {
            std::cout << "Error creating file!" << std::endl;
        }
        saved = true;
    }
}

int Game::retrieveScore(std::string fileName)
{
    std::ifstream inFile(fileName);
    int highScore = 0;
    if (inFile.is_open())
    {
        std::string Playername;
        std::string scoreStr;
        while (!inFile.eof()) // Read name and score pair until end of file
        {
            getline(inFile, Playername);
            getline(inFile, scoreStr);
            int score = std::stoi(scoreStr);
            if (score > highScore)
            {
                highScore = score;
            }
        }
        inFile.close();
    }
    else
    {
        std::cout << "Error: Unable to open file!" << std::endl;
    }
    return highScore;
}

// Powerup logics
void Game::applyPower(float *color)
{
    if (Food::getPowerStatus() == false)
    {
        Food::setStatus(true);
        if (color == colors[GREEN])
        {
            Paddle::setWidth(Paddle::getWidth() * 2);
        }
        else if (color == colors[DEEP_PINK])
        {
            Paddle::setWidth(Paddle::getWidth() / 2);
        }
        else if (color == colors[BLUE])
        {
            Ball::setVelocity(Ball::getDx() / 1.3, Ball::getDy() / 1.3);
        }
        else if (color == colors[RED])
        {
            Ball::setVelocity(Ball::getDx() * 1.3, Ball::getDy() * 1.3);
        }
    }
}

// Idk why I made this
void Game::setGameState(bool state)
{
    this->state = state;
}
