#ifndef BALL_H
#define BALL_H
#include "util.h"

class Ball
{
protected:
    float x;
    float y;
    float dx;
    float dy;
    float radius;
    float *color;

public:
    // Constructor
    Ball(float startX = 400, float startY = 300, float startRadius = 10, float startDx = 5, float startDy = 5, float *ballColor = colors[CRIMSON]);

    // Getter methods
    float getX() const;
    float getY() const;
    float getRadius() const;
    float getDx() const;
    float getDy() const;
    float *getColor() const;

    // Setter methods
    void setPosition(float x, float y);
    void setVelocity(float dx, float dy);
    void setColor(float *newColor);

    // General Functions
    void Draw() const; // Drawing the ball
};

#endif // BALL_H
