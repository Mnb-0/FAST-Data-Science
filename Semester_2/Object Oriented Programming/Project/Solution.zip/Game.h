#ifndef GAME_H
#define GAME_H

#include "Stage.h"
#include "Player.h"
#include "Paddle.h"
#include "Brick.h"
#include "Food.h"
#include "Ball.h"
#include <fstream>

class Game : public Stage, public Player, public Paddle, public Brick, public Food, public Ball
{
public:
    bool gameOver;
    bool saved;
    bool state;
    Paddle paddle2;

public:
    // Constructor
    Game();

    // Display Function
    void Display();

    // Movement Logics
    void ballMove();
    void paddleMove(int x);
    void paddle2Move(int x);
    void foodMove();
    void spawnFood(float x, float y);

    // Collision Logics
    void paddleCollision();
    void brickCollision();

    // File Handling
    void saveScore();
    int retrieveScore(std::string fileName = "score.txt");

    // Powerup logics
    void applyPower(float *color);

    // Idk why I made this
    void setGameState(bool state);
};

#endif // GAME_H
