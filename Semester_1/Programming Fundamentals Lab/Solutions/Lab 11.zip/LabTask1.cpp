#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>

using namespace std;

int SIZE = 0;

int main() {
    cout << "Enter the size of array n x n: \n";
    int newSize;
    cin >> newSize;

    srand(time(0));

    int arrayA[newSize][newSize];
    int arrayB[newSize][newSize];

    int i = 0;
    while (i < newSize) {
        int j = 0;
        while (j < newSize) {
            arrayA[i][j] = rand() % 100 + 1;
            arrayB[i][j] = rand() % 100 + 1;
            ++j;
        }
        ++i;
    }

    cout << "Matrix A:" << endl;
    int row = 0;
    while (row < newSize) {
        int col = 0;
        while (col < newSize) {
            cout << setw(3) << arrayA[row][col] << " ";
            ++col;
        }
        cout << "\n";
        ++row;
    }

    cout << "\nMatrix B:" << endl;
    row = 0;
    while (row < newSize) {
        int col = 0;
        while (col < newSize) {
            cout << setw(3) << arrayB[row][col] << " ";
            ++col;
        }
        cout << "\n";
        ++row;
    }

    int sum = 0;
    row = 0;
    while (row < newSize) {
        int col = 0;
        while (col < newSize) {
            sum += arrayA[row][col];
            ++col;
        }
        ++row;
    }
    cout << "\nSum of all elements in Matrix A: " << sum << "\n";

    int transposedArrayB[newSize][newSize];
    row = 0;
    while (row < newSize) {
        int col = 0;
        while (col < newSize) {
            transposedArrayB[row][col] = arrayB[col][row];
            ++col;
        }
        ++row;
    }

    cout << "\nTranspose of Matrix B:" << endl;
    row = 0;
    while (row < newSize) {
        int col = 0;
        while (col < newSize) {
            cout << setw(3) << transposedArrayB[row][col] << " ";
            ++col;
        }
        cout << "\n";
        ++row;
    }

    int searchElement = 5;
    int foundRow = -1, foundCol = -1;
    row = 0;
    while (row < newSize && foundRow == -1) {
        int col = 0;
        while (col < newSize && foundCol == -1) {
            if (arrayA[row][col] == searchElement) {
                foundRow = row;
                foundCol = col;
            }
            ++col;
        }
        ++row;
    }
    if (foundRow != -1) {
        cout << "\nElement " << searchElement << " found at indices: (" << foundRow << ", " << foundCol << ")\n";
    } else {
        cout << "\nElement " << searchElement << " not found in Matrix A\n";
    }

    int rowSums[newSize];
    int colSums[newSize];
    row = 0;
    while (row < newSize) {
        int col = 0;
        rowSums[row] = 0;
        colSums[row] = 0;
        while (col < newSize) {
            rowSums[row] += arrayA[row][col];
            colSums[row] += arrayA[col][row];
            ++col;
        }
        ++row;
    }

    cout << "\nSum of each row in Matrix A:" << endl;
    row = 0;
    while (row < newSize) {
        cout << rowSums[row] << " ";
        ++row;
    }
    cout << "\n";

    cout << "Sum of each column in Matrix A:" << endl;
    row = 0;
    while (row < newSize) {
        cout << colSums[row] << " ";
        ++row;
    }
    cout << "\n";

    int mainDiagonalSum = 0;
    row = 0;
    while (row < newSize) {
        mainDiagonalSum += arrayA[row][row];
        ++row;
    }
    cout << "\nSum of main diagonal elements in Matrix A: " << mainDiagonalSum << "\n";

    int rotatedArrayA[newSize][newSize];
    row = 0;
    while (row < newSize) {
        int col = 0;
        while (col < newSize) {
            rotatedArrayA[row][col] = arrayA[newSize - 1 - row][newSize - 1 - col];
            ++col;
        }
        ++row;
    }

    cout << "\nMatrix A rotated by 180 degrees clockwise:" << endl;
    row = 0;
    while (row < newSize) {
        int col = 0;
        while (col < newSize) {
            cout << setw(3) << rotatedArrayA[row][col] << " ";
            ++col;
        }
        cout << "\n";
        ++row;
    }

    bool isIdentity = true;
    row = 0;
    while (row < newSize && isIdentity) {
        int col = 0;
        while (col < newSize && isIdentity) {
            if ((row == col && arrayA[row][col] != 1) || (row != col && arrayA[row][col] != 0)) {
                isIdentity = false;
            }
            ++col;
        }
        ++row;
    }
    cout << "\nMatrix A is an identity matrix: " << (isIdentity ? "true" : "false") << "\n";

    return 0;
}
