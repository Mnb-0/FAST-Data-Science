#include <iostream>

using namespace std;

// Function prototypes
void showChoices();
void task1();
void task2();
int task3(int *arr, int size);
void task4(int base, int *ptr);

int main() {
    char choice;

    do {
        // Display menu
        showChoices();

        // Get user choice
        cout << "Enter your choice (E to quit): ";
        cin >> choice;

        switch (choice) {
            case '1':
                task1();
                break;
            case '2':
                task2();
                break;
            case '3': {
                int numbers[] = {45, 78, 12, 67, 89, 34, 56};
                int size = sizeof(numbers) / sizeof(numbers[0]);
                int result = task3(numbers, size);
                cout << "The largest number in the array is: " << result << endl;
                break;
            }
            case '4': {
                int tableOfTwo = 2;
                int *ptrTable = &tableOfTwo;
                task4(2, ptrTable);
                break;
            }
            case 'E':
                cout << "Exiting program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }

    } while (choice != 'E');

    return 0;
}

// Function to display menu choices
void showChoices() {
    cout << "Menu:" << endl;
    cout << "1. Press 1 for Task 1" << endl;
    cout << "2. Press 2 for Task 2" << endl;
    cout << "3. Press 3 for Task 3" << endl;
    cout << "4. Press 4 for Task 4" << endl;
    cout << "E(sc). Quit" << endl;
}

// Function for Task 1
void task1() {
    cout << "Executing Task 1..." << endl;
    int num1 = 1, num2 = 2, num3 = 3, num4 = 4, num5 = 5;
    int sum = num1 + num2 + num3 + num4 + num5;
    cout << "Sum of 5 numbers: " << sum << endl;
}

// Function for Task 2
void task2() {
    cout << "Executing Task 2..." << endl;
    int a = 10, b = 20;
    cout << "Before swapping: a = " << a << ", b = " << b << endl;
    int temp = a;
    a = b;
    b = temp;
    cout << "After swapping: a = " << a << ", b = " << b << endl;
}

// Function for Task 3
int task3(int *arr, int size) {
    cout << "Executing Task 3..." << endl;
    int max = arr[0];
    int i = 1;
    while (i < size) {
        if (arr[i] > max) {
            max = arr[i];
        }
        ++i;
    }
    return max;
}

// Function for Task 4
void task4(int base, int *ptr) {
    cout << "Executing Task 4..." << endl;
    int i = 1;
    while (i <= 12) {
        cout << base << " * " << i << " = " << (*ptr) << endl;
        (*ptr) += base;
        ++i;
    }
}
