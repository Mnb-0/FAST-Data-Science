#include <iostream>
using namespace std;
int main()
{
double sum = 0;
double arr[] ={32.20,41.88,16.12,23.88, 7.21};
int size = sizeof(arr) / sizeof(arr[0]); //Total size in bytes divided by the size of one element of the array
for (int i = 0 ; i < size ; i++)
{
	arr[i] = arr[i] / 2;
	cout<<arr[i]<<endl;
	sum = sum + arr[i];
}
cout<<"Sum: "<<sum<<endl;;
return 0;
}

