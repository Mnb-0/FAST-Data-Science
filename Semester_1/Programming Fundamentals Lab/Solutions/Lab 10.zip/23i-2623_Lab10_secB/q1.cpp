#include <iostream>
using namespace std;
int main()
{
int sum = 0, max = 0, min = 0;
float average = 0.0;
int arr[5] = {0, 0, 0, 0, 0};
for (int i = 0 ; i <= 4 ; i++)
{
	cout<<"Enter a number: ";
	cin>>arr[i];
	sum = sum + arr[i];
}
max = arr[0];
min = arr[0];
for (int j = 0 ; j <= 4 ; j++)
{
	if (arr[j] > max)
	{
		max = arr[j];
	}
	if (arr[j] < min)
	{
		min = arr[j];
	}
}
    average = static_cast<float>(sum) / 5;
    cout << "Average: " << average << endl;
    cout << "Sum: " << sum << endl;
    cout << "Max: " << max << endl;
    cout << "Min: " << min << endl;
return 0;
}

