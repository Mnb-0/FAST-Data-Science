#include <iostream>

int main() {
    // Input the number of elements
    int n;
    std::cout << "Enter the number of elements: ";
    std::cin >> n;

    // Input array elements
    int arr[n];
    std::cout << "Enter the elements of the array:" << std::endl;
    for (int i = 0; i < n; ++i) {
        std::cout << "Element " << i << ": ";
        std::cin >> arr[i];
    }

    // Find the index of the highest element in the array
    int maxIndex = 0;
    for (int i = 1; i < n; ++i) {
        if (arr[i] > arr[maxIndex]) {
            maxIndex = i;
        }
    }

    // Find the next highest element in the array
    int nextHighestIndex = 0;
    for (int i = 0; i < n; ++i) {
        if (i != maxIndex && arr[i] > arr[nextHighestIndex]) {
            nextHighestIndex = i;
        }
    }

    // Calculate the required additive entity
    int additiveEntity = arr[maxIndex] - arr[nextHighestIndex];

    // Output the result
    std::cout << arr[maxIndex] << " " << arr[nextHighestIndex] << " " << additiveEntity << std::endl;

    return 0;
}

