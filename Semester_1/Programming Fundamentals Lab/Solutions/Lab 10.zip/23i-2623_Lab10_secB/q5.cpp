#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() 
{
const int arraySize = 100;
int num[arraySize];
bool found[100] = {false};
srand(static_cast<unsigned>(time(nullptr)));

for (int i = 0; i < arraySize; ++i) 
{
	num[i] = rand() % 100 + 1;
	found[num[i] - 1] = true;
}

cout << "Randomly generated array: ";
for (int i = 0; i < arraySize; ++i) 
{
	cout << num[i] << " ";
}
cout << endl;
cout << "Numbers not generated: ";
for (int i = 0; i < 100; ++i) 
{
	if (!found[i]) 
	{
	cout << i + 1 << " ";
	}
}
cout << endl;

return 0;
}
