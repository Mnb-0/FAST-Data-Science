#include <iostream>
using namespace std;
int main()
{
int my_array[] = {13, 99, 6, 76, 11, 83, 8, 67, 66, 22, 96, 46, 21, 65, 48, 22, 28, 11, 83, 87, 10};
for (int i = 20 ; i >=0 ; i--)
	cout<<my_array[i]<<"\n";
return 0;
}
