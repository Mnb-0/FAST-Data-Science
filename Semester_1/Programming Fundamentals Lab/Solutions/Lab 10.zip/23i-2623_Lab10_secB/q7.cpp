#include <iostream>
using namespace std;
int main() 
{

int rates[] = {1500000, 140000, 130000, 120000, 110000, 100000, 90000};

cout<<"The best day to buy the property is:Day " << rate[0]<<endl;
cout<<"The best day to sell the property is:Day " << rate[6]<<endl;

    return 0;
}

