#include <iostream>
using std::cout, std::cin;

int main() 
{
    float x, sinx = 0, num = 1, den = 1;
    int n;

    cout << "Enter value of x: ";
    cin >> x;
    cout << "Enter Number of Terms: ";
    cin >> n;

    for (int i = 1, j = 1; i <= n; i++, j += 2) 
    {
        if (i % 2 == 1) 
        {
            sinx += num / den;
        } 
        else 
        {
            sinx -= num / den;
        }

        num *= x * x;
        den *= (j + 1) * (j + 2);
    }

    cout << "The value of sinx is: " << sinx;

    return 0;
}

