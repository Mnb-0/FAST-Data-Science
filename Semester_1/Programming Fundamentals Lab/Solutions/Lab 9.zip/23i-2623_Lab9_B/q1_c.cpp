#include <iostream>
using std::cout, std::cin, std::endl;
int main() 
{

    int number;
    cout << "Enter a number: ";
    cin >> number;

    for (int i = 1; i <= number; i++) 
    {
        if (i != 1) 
        {
            for (int j = 1; j <= (i - 1) * (number - 1); j++) 
            {
                cout << " ";
            }
            for (int j = 1; j <= number; j++) 
            {
                cout << "*";
            }
            cout << endl;
        }

        if (i == number) 
        {
            for (int k = 1; k <= (number - 1); k++) 
            {
                for (int j = 1; j <= (i * (number - 1)); j++) 
                {
                    cout << " ";
                }
                cout << "*" << endl;
            }
        }
        else 
        {
            for (int k = 1; k <= (number - 2); k++) 
            {
                for (int j = 1; j <= (i * (number - 1)); j++) 
                {
                    cout << " ";
                }
                cout << "*" << endl;
            }
        }
    }
    return 0;
}

