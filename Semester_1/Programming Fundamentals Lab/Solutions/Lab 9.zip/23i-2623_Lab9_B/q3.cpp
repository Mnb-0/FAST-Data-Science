#include <iostream>
using std::cout, std::cin;

int main() {
    int n, reverse = 0;
    cout << "Enter number: ";
    cin >> n;

    while (n != 0) {
        int rem = n % 10;
        reverse = reverse * 10 + rem;
        n /= 10;
    }

    cout << "Reverse is: " << reverse;
    return 0;
}

