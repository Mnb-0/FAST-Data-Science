#include <iostream>
using namespace std;
void InputArray(int [], int);
void DisplayArray(int [], int);
void SortArray(int [], int);
bool FindNum(int [], int, int);
int FindMax(int [], int);
int FindMin(int [], int);
int SquareArraySum(int [], int);
int main()
{
   int size = 0, max,min,squared;
   cout<<"Enter size for array: ";
   cin>>size;
   int Num[size] = {0};
   int toFind = 0;
   bool numFound = false;
   InputArray(Num, size);
   DisplayArray(Num, size);
   SortArray(Num, size);
   DisplayArray(Num, size);
   cout<<"Enter a number to find: "<<endl;
   cin>>toFind;
   numFound = FindNum(Num, size, toFind);
   cout<<numFound;
   max = FindMax(Num, size);
   min = FindMin(Num, size);
   squared = SquareArraySum(Num , size);
   cout<<max<<endl<<min<<endl<<squared<<endl;
   return 0;

}

void InputArray(int arr[], int size)
{
   for (int i = 0 ; i < size ; i++)
   {
      cout<<"Enter A Value: "<<endl;
      cin>>arr[i];
   }
}
void DisplayArray(int arr[], int size)
{
   cout<<"Array is as follows: "<<endl;
   for (int i = 0; i < size; i++)
   {
      cout<<arr[i]<<" ";
   }
   cout<<endl;
}
void SortArray(int arr[], int size)
{
   int temp = 0;
   bool sorted;
   do
   {
      sorted = true;
      for (int i = 0; i < size - 1; i++)
      {
         if (arr[i] > arr[i + 1])
         {
            sorted = false;
            temp = arr[i];
            arr[i] = arr[i + 1];
            arr[i + 1] = temp;
         }
      }
   } while (sorted == false);
}

bool FindNum(int arr[], int size, int element)
{
   for (int i = 0; i < size; i++)
   {
      if(arr[i] == element)
      {
         return true;
      }
   }
   return false;
}

int FindMax(int arr[], int size)
{
   int max = arr[0];
   for (int i = 1; i < size; i++)
   {
      if (arr[i] > max)
      {
         max = arr[i];
      }
   }
   return max;
}

int FindMin(int arr[], int size)
{
   int min = arr[0];
   for (int i = 1; i < size; i++)
   {
      if (arr[i] < min)
      {
         min = arr[i];
      }
   }
   return min;
}
int SquareArraySum(int arr[], int size)
{
   int sum = 0;
   for (int i = 0; i < size ; i++)
   {
      arr[i] = arr[i] * arr[i];
   }
   for (int i = 0; i < size ; i++)
   {
      sum = sum + arr[i];
   }
   return sum;
}