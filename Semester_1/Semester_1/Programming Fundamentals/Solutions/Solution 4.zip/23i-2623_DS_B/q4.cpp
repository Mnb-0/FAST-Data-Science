//Muhammad Muneeb Lone 23i-2623 Assignment 4
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() 
{
    const int size = 60;
    int coins[size];

    srand(static_cast<unsigned int>(time(0)));

    int i = 0;
    while (i < size) 
    {
        coins[i] = rand() % 21 - 10;
        i++;
    }

    int end_max = coins[0];
    int max = coins[0];
    int start = 0, end = 0, currentStart = 0;

    i = 1;
    while (i < size) 
    {
        if (coins[i] > end_max + coins[i]) 
        {
            end_max = coins[i];
            currentStart = i;
        }
        else 
        {
            end_max = end_max + coins[i];
        }

        if (end_max >  max) 
        {
             max = end_max;
            start = currentStart;
            end = i;
        }

        i++;
    }

    int profit = 0;
    i = start;
    while (i <= end) 
    {
        profit += coins[i];
        i++;
    }

    cout << "Maximum Profit: " << profit << endl;
    cout << "Start Index: " << start << endl;
    cout << "End Index: " << end << endl;

    return 0;
}

