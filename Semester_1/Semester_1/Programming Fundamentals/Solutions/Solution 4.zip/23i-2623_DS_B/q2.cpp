//Muhammad Muneeb Lone 23i-2623 Assignment 4
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() 
{
int arraySize = 0;
cout<<"Enter a size for the array: ";
cin>>arraySize;
//Generating N x N square matrix and filling it with random elements
int matrix[arraySize][arraySize];
srand(static_cast<unsigned>(time(nullptr)));
int topElement = 0, bottomElement = arraySize - 1, leftElement = 0, rightElement = arraySize - 1;

for (int i = 0; i < arraySize; ++i) 
{
	for (int j = 0; j < arraySize; j++)
	{
		matrix[i][j] = rand() % 100;//Limit set to 100 according to the pattern shown in the question and also for the sake of numbers that are understandable
	}
}
cout << "Randomly generated array: ";
for (int i = 0; i < arraySize; ++i) 
{
	for (int j = 0; j < arraySize; j++)
	{
		cout<<matrix[i][j]<<" ";
	}
}
cout << endl;
cout << "Printing the matrix in custom pattern\n";

while (topElement <= bottomElement && leftElement <= rightElement) 
{
	// Move right
	for (int i = leftElement; i <= rightElement; i++) 
	{
		cout << matrix[topElement][i] << " ";
	}
	topElement++;

	// Move down
	for (int i = topElement; i <= bottomElement; i++) 
	{
		cout << matrix[i][rightElement] << " ";
	}
	rightElement--;

	// Move left
	if (topElement <= bottomElement) 
	{
		for (int i = rightElement; i >= leftElement; i--) 
		{
			cout << matrix[bottomElement][i] << " ";
		}
	bottomElement--;
	}

	// Move up
	if (leftElement <= rightElement) 
	{
		for (int i = bottomElement; i >= topElement; i--) 
		{
			cout << matrix[i][leftElement] << " ";
		}
	leftElement++;
	}
}
return 0;
}	
