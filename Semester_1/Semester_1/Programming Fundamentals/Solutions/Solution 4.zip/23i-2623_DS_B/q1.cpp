//Muhammad Muneeb Lone 23i-2623 Assignment 4
#include <iostream>
using namespace std;
int main() 
{
int rows = 25, cols = 25;
char maze[rows][cols];

// Fill the array with '.' initially
for (int i = 0; i < rows; ++i) 
{
	for (int j = 0; j < cols; ++j) 
	{
		maze[i][j] = '.';
	}
}

// Set '#' for border elements
for (int i = 0; i < rows; ++i) 
{
	maze[i][0] = '#';         // left border
	maze[i][cols - 1] = '#';  // right border
}

for (int j = 0; j < cols; ++j) 
{
	maze[0][j] = '#';         // top border
	maze[rows - 1][j] = '#';  // bottom border
}

//Create Walls
for (int i = 3 ; i <= 4 ; i++)
{
	for (int j = 16 ; j <= 21; j++)
	{
		maze[i][j] = '#';
	}
}
for (int i = 3 ; i <= 4 ; i++)
{
	for (int j = 3 ; j <= 8 ; j++)
	{
		maze[i][j] = '#';
	}
}
for (int i = 9 ; i <= 17 ; i++)
{
	maze[i][4] = '#';
}
for (int i = 8 ; i <= 16 ; i++)
{
	maze[9][i] = '#';
}
for (int i = 9 ; i <= 14 ; i++)
{
	maze[i][12] = '#';
}
for (int i = 9 ; i <= 17 ; i++)
{
	maze[i][20] = '#';
}
for (int i = 4 ; i <= 9 ; i++)
{
	maze[13][i] = '#';
}
for (int i = 15 ; i <= 20 ; i++)
{
	maze[13][i] = '#';
}
for (int i = 20 ; i <=21 ; i++)
{
	for (int j = 3 ; j <= 6 ; j++)
	{
		maze[i][j] = '#';
	}
}
for (int i = 20 ; i <=21 ; i++)
{
	for (int j = 18 ; j <= 21 ; j++)
	{
		maze[i][j] = '#';
	}
}
for (int i = 16; i <= 21 ; i++)
{
	maze[i][8] = '#';
}
for (int i = 16; i <= 21 ; i++)
{
	maze[i][16] = '#';
}
for (int i = 8 ; i <= 16 ; i++)
{
	maze[21][i] = '#';
}
maze[16][9] = '#';
maze[16][10] = '#';
maze[16][14] = '#';
maze[16][15] = '#';
// Display the maze
for (int i = 0; i < rows; ++i) 
{
	for (int j = 0; j < cols; ++j) 
	{
		cout << maze[i][j] << ' ';
	}
	cout << '\n';
}
return 0;
}

