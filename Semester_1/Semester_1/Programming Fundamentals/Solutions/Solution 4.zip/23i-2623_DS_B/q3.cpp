//Muhammad Muneeb Lone 23i-2623 Assignment 4
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main()
{
int quadrantManip[3][8][8] = {0};
srand(static_cast<unsigned>(time(nullptr)));

for (int i = 1 ; i <= 3 ; i++)//3D Array Initialization
{
	for (int j = 0 ; j < 8 ; j++)
	{
		for (int k = 0 ; k < 8 ; k++)
		{
			if (i == 1)
			{
				quadrantManip[i][j][k] = 0;
			}
			if (i == 2)
			{
				quadrantManip[i][j][k] = 1;
			}
			if (i == 3)
			{
				quadrantManip[i][j][k] = 2;
			}
		}
	}
}
for (int i = 1 ; i <= 3 ; i++)
{
	for (int j = 0 ; j < 8 ; j++)
	{
		for (int k = 0 ; k < 8 ; k++)
		{
			quadrantManip[i][j][k] = (rand() % 3) + 1;
		}
	}
}

return 0;
}
