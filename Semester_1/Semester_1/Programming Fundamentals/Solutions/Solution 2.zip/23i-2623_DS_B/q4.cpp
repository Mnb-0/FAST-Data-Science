//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
using namespace std;
int main()
{
short timeVal = 0, seconds = 0, minutes = 0, hours = 0;
cout<<"Input a time value:";
cin>> timeVal;
if (timeVal >=0 || timeVal <= sizeof(short))
{
	//To extract last 6 bits we take bitwise AND with 63 as it has 1s in 6 rightmost bits
	seconds = (timeVal & 63);
	minutes = (timeVal>>6) & 63;
	hours = (timeVal>>12) & 15;
	cout<<"Time is "<<hours<<" hrs "<<minutes<<" mins "<<seconds<<" secs \n";
}
else
{
	cout<<"Invalid input.";
}
return 0;
}
