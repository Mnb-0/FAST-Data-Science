//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
#include <string>
using namespace std;
int main()
{
int userIn1 , userIn2, evenRow1, evenRow2, first_row_separation, second_row_separation;
string color1 , color2;
cout<<"Enter two numbers one by one: ";
cin>> userIn1 >>userIn2;

//Separating rows

if ((userIn1 % 9) != 0)
{
	first_row_separation = (userIn1 / 9) + 1;
}
else
{
	first_row_separation = (userIn1 / 9);
}

if ((userIn2 % 9) != 0)
{
	second_row_separation = (userIn2 / 9) + 1;
}
else
{
	second_row_separation = (userIn2 / 9);
}

//Assigning odd/even to rows

if ((first_row_separation % 2) == 0)
{	
	evenRow1 = 1;
}
else 
{
	evenRow1 = 0;
}

if ((second_row_separation % 2) == 0)
{	
	evenRow2 = 1;
}
else 
{
	evenRow2 = 0;
}

if (evenRow1 == evenRow2)
{
	cout<<"Same color"<<endl;
}
else
{
	cout<<"Different color"<<endl;
}
return 0;
}
