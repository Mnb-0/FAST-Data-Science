//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
using namespace std;

int main()
{
int moneyReq = 0, note500 = 0, note1000 = 0, note5000 = 0;

cout<<"Enter the amount of money you want to extract: ";
cin>> moneyReq;
//Rule 1
moneyReq = moneyReq - 500;
note500 += 1;

if ((moneyReq <= 50000 || moneyReq > 0) && (moneyReq % 500 == 0))
{
	note5000 = moneyReq / 5000;
	moneyReq = moneyReq - ((moneyReq / 5000) * 5000);
	
	note1000 = moneyReq / 1000;
	moneyReq = moneyReq - ((moneyReq / 1000) * 1000);
	
	note500 = moneyReq / 500;
	moneyReq = moneyReq - ((moneyReq / 500) * 500);
	
	cout<<"5000 notes:"<<note5000<<endl<<"1000 notes:"<<note1000<<endl<<"500 notes:"<<note500<<endl;
}
else
{
	cout<<"Invalid amount\n";
}
return 0;
}
