//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
using namespace std;

int main()
{
int month , day , year;

// month times the date = the year
cout<<"Enter a month, a day, and a four digit year in that order:\n";
cin>>month>>day>>year;
((month * day) == (year % 1000))?cout<<"This date is magic." : cout<<"This date is not magic.";


return 0;
}
