//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
using namespace std;
int main()
{
int eggNum = 0;
cout<<"Input total number of eggs:\n";
cin>>eggNum;
if (eggNum != 0)
	{
	cout<<"Number of 30 eggs packing: " << eggNum / 30 <<"\t Number of leftover eggs: "<< eggNum % 30 << "\n";
	cout<<"Number of 24 eggs packing: " << eggNum / 24 <<"\t Number of leftover eggs: "<< eggNum % 24 << "\n";
	cout<<"Number of 18 eggs packing: " << eggNum / 18 <<"\t Number of leftover eggs: "<< eggNum % 18 << "\n";
	cout<<"Number of 12 eggs packing: " << eggNum / 12 <<"\t Number of leftover eggs: "<< eggNum % 12 << "\n";
	cout<<"Number of 6 eggs packing: " << eggNum / 6 <<"\t Number of leftover eggs: "<< eggNum % 6 << "\n";
	}
else{
	cout<<"0 eggs cannot be packed\n";
    }
return 0;
}
