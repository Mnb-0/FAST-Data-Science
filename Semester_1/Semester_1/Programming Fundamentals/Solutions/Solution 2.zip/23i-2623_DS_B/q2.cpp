//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
const double u = 1.234;
const double p = 3.334;
double num = 0 , den1 = 0 , den2 = 0, i = 0;
cout<<"Input a value for i:\n";
cin>> i;
if (i>=0)
{
	num = (u * (pow(i, 1.5))) * ((i * i) - 1);
	den1 = (p * i) -2;
	den2 = (p * i) - 1;
	cout<<"Your answer is: " << (sqrt(num))/((sqrt(den1)) + (sqrt(den2)));
}
else
{
	cout<<"Please enter only a positive value.\n";
}
return 0;
}
