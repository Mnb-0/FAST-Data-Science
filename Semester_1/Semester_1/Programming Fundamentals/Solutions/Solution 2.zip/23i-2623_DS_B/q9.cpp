//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main()
{
char operation = ' ', negVals = ' ';
int rand1 = 0 , rand2 = 0, maximumValue = 0, result = 0,userInput = 0;
srand(time(0));

cout<<"What operation would you like to perform? Select from + , - , * or /: "<< endl;
cin>> operation;
cout<<"What is the maximum value for the input values of the exercise? "<<endl;
cin>>maximumValue;
cout<<"Are negative values allowed in the exercise? "<<endl;
cin>>negVals;
if (negVals == 'Y' || negVals == 'y')
{
	rand1 = (rand() % (maximumValue + 1)) - (maximumValue/2);
	rand2 = (rand() % (maximumValue + 1)) - (maximumValue/2);
	
}
else 
{
	rand1 = (rand() % (maximumValue + 1));
	rand2 = (rand() % (maximumValue +1));
	if (operation == '-')
	{
		rand2 = rand() % rand1;
	}
}

switch (operation)
{
	case '+':
		result = rand1 + rand2;
            cout << "What is " << rand1 << " + " << rand2 << "? ";
            break;
        case '-':
            result = rand1 - rand2;
            cout << "What is " << rand1 << " - " << rand2 << "? ";
            break;
        case '*':
            result = rand1 * rand2;
            cout << "What is " << rand1 << " * " << rand2 << "? ";
            break;
        case '/':
            result = rand1 / rand2;
            cout << "What is " << rand1 << " / " << rand2 << "? ";
            break;
        default:
            cout << "Invalid operation." << endl;
    }
cin>>userInput;
if (userInput == result)
{	
	cout<<"Congratulations! Correct Answer." <<endl;
}
else
{
	cout<<"Sorry, the correct answer is " << result <<endl;
}
return 0;
}
