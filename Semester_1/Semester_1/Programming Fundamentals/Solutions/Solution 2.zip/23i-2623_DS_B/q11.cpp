//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
using namespace std;
int main()
{
char decision;
cout<<"Record symptom information.";
cout<<"Reboot server to see if condition still exists.";
cout<<"Is this a newly installed server?";
cin>> decision;
if (decision == 'Y')
{
	cout<<"Reseat any components that may have come loose during shipping and reboot the server.";
	cout<<"Does condition still exist?";
	cin>>decision;
	if (decision == 'Y')
	{
		cout<<"Were options added or was the configuration changed recently?"<<endl;
		cin>>decision;
		if (decision == 'Y')
		{
			cout<<"Isolate what has changed. Verify it was installed correctly. Restore server to last known working state or original shipped configuration."<<endl;
			cout<<"Does condition still exist?"<<endl;
			cin>>decision;
			if (decision == 'Y')
			{
				cout<<"Isolate and minimize the memory configuration."<<endl;
				cout<<"Does condition still exist?"<<endl;
				cin>>decision;
				if (decision == 'Y')
				{
					cout<<"Break server down to minimal configuration"<<endl;
					cout<<"Does condition still exist?"<<endl;
					cin>>decision;
					if (decision == 'Y')
					{
						cout<<"Troubleshoot or replace basic server parts"<<endl;
						cout<<"Does condition still exist?"<<endl;
						cin>>decision;
						if (decision == 'Y')
						{
							cout<<"Ensure the following information is available:\n"<<"Survey configuration snapshots\n"<<"OS event log file\n"<<"Full crash dump\n"<<"Call HP Service Provider"<<endl;
						}
						else
						{
							cout<<"Record symptom & error information on repair tag if sending back a failed part"<<endl;
						}
					}
					else
					{
						cout<<"Add one part at a time back to configuration to isolate faulty component."<<endl;
						cout<<"Does condition still exist?"<<endl;
						cin>>decision;
						if (decision == 'Y')
						{
							cout<<"Ensure the following information is available:\n"<<"Survey configuration snapshots\n"<<"OS event log file\n"<<"Full crash dump\n"<<"Call HP Service Provider"<<endl;
						}
						else
						{
							cout<<"Record action taken."<<endl;;
						}
					}
				}
				else
				{
					cout<<"Record action taken."<<endl;
				}
			}
			else
			{
				cout<<"Record action taken."<<endl;	
			}
		}
		else
		{
			cout<<"Check for service notifications."<<endl;
			cout<<"Download the latest software and firmware from the HP website."<<endl;
		}
	}
}
return 0;
}
