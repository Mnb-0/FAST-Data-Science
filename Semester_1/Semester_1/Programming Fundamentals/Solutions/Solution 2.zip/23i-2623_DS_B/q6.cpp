//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
#include <string>
using namespace std;

int main() 
{
    //Constants
    const double fullTimeRate = 900.0;
    const double partTimeRate = 850.0;
    const double adhocRate = 600.0;
    const double fullTimeTax = 0.05;
    const double partTimeTax = 0.07;
    const double adhocTax = 0.10;
    const int hoursPerDay = 8;

    int daysWorked;
    cout<<"Enter number of days worked: ";
    cin>>daysWorked;

    //Employee category
    string employeeCategory;
    if (daysWorked >= 25 && daysWorked <= 30) 
    {
        employeeCategory = "Full-time";
    } else if (daysWorked >= 15 && daysWorked <= 24) 
    {
        employeeCategory = "Part-time";
    } else 
    {
        employeeCategory = "Adhoc";
    }

    //Salary
    double hourlyRate;
    if (employeeCategory == "Full-time") 
    {
        hourlyRate = fullTimeRate;
    } else if (employeeCategory == "Part-time") 
    {
        hourlyRate = partTimeRate;
    } else 
    {
        hourlyRate = adhocRate;
    }

    double grossSalary = daysWorked * hoursPerDay * hourlyRate;

    //Tax
    double taxRate;
    if (employeeCategory == "Full-time") 
    {
        taxRate = fullTimeTax;
    } else if (employeeCategory == "Part-time") 
    {
        taxRate = partTimeTax;
    } else 
    {
        taxRate = adhocTax;
    }

    double taxDeduction = grossSalary * taxRate;

    
    double netPayable = grossSalary - taxDeduction;

    
    cout<<"Employee Category: "<<employeeCategory<< endl;
    cout<<"Gross Salary: $"<<grossSalary<< endl;
    cout<<"Tax Deduction: $"<<taxDeduction<< endl;
    cout<<"Net Payable Amount: $"<< netPayable<< endl;

    return 0;
}

