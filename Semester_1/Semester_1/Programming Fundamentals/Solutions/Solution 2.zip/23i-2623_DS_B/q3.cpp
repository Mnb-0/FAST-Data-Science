//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
short num = 0, newNum = 0;
cout<<"Enter a number to be multiplied by 63: ";
cin>> num;
if (num >= 0 || num <= sizeof(short))
{
	//Shifting 1 bit to the left multiplies value by 2 so we divide 63 into powers of 2
	newNum = (num << 5 ) + (num << 4) + ( num << 3) + (num << 2) + (num << 1) + (num << 0);
	cout<< newNum;
}
else
{
	cout<<"Invalid input";
}
return 0;
}
