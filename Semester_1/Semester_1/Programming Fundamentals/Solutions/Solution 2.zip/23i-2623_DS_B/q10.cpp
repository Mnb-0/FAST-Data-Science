//Muhammad Muneeb Lone | 23i-2623 | Assignment #2
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main()
{
srand(time(0));
int userIn1 = 0, userIn2 = 0, userIn3 = 0, rand1 = 0, rand2 = 0, rand3 = 0, gameChoice = 0;
char decisionHL = ' ', computerChoice = ' ', userChoice = ' ';
cout<<"Guessing Games\n1. Play Higher or Lower\n2. Play Paper-Scissors-Rock\n3. Guess the Numbers\n4.Quit\n";
cout<<"Enter your choice(1-4)\n";
cin>> gameChoice;
if (gameChoice >= 1 || gameChoice <= 4)
{
	switch (gameChoice)
	{
		case 1:
		{
			cout<<"You have chosen to play Higher or Lower"<<endl;
			rand1 = (rand() % 20) + 1;
			rand2 = (rand() % 20) + 1;
			cout<<"The first number is " << rand1 << endl;
			cout<<"Enter H for higher or L for lower" << endl;
			cin>> decisionHL;
			if (decisionHL == 'H' || decisionHL == 'L')
			{
				if ((decisionHL == 'H' && rand2 > rand1) || (decisionHL == 'L' && rand2 < rand1))
				{
					cout<<"You win!!!" << endl;
				}
				else
				{
					cout<<"You lose" << endl;
				}
			}
			else
			{
				cout<<"Please enter H or L";
			}
		break;
		}
		
		case 2:
		{
			cout<<"You have chosen to play Paper-Scissors-Rock"<<endl;
			rand3 = (rand() % 3) + 1;
			switch (rand3)
			{
				case 1:
				{
					computerChoice = 'P';
					break;
				}
				case 2:
				{
					computerChoice = 'S';
					break;
				}
				case 3:
				{
					computerChoice = 'R';
					break;
				}
				default: 
				{
					break;
				}
			}
			cout<<"Please choose from Paper(P), Scissors(S) and Rock(R): " << endl;
			cin>> userChoice;
			
			if (computerChoice == userChoice)
			{
				cout<<"It's a draw"<<endl;
			}
			else
			{
				if (computerChoice == 'R')
				{
					if (userChoice == 'P')
					{
						cout<<"User wins."<<endl;
					}
					if (userChoice == 'S')
					{
						cout<<"Computer wins"<<endl;
					}
				}
				if (computerChoice == 'S')
				{
					if (userChoice == 'R')
					{
						cout<<"User wins."<<endl;
					}
					if (userChoice == 'P')
					{
						cout<<"Computer wins"<<endl;
					}
				}
				if (computerChoice == 'P')
				{
					if (userChoice == 'S')
					{
						cout<<"User wins."<<endl;
					}
					if (userChoice == 'R')
					{
						cout<<"Computer wins"<<endl;
					}
				}
			}
		break;
		}
		
		case 3:
		{
			rand1 = rand() % 10;
			rand2 = rand() % 10;
			rand3 = rand() % 10;
			cout<<"Guess any three numbers one by one from 0 to 9: " << endl;
			cin>> userIn1 >> userIn2 >> userIn3;
			
			if ((userIn1 >= 0 && userIn1 <= 9) && (userIn2 >= 0 && userIn2 <= 9) && (userIn3 >= 0 && userIn3 <= 9))
			{
				if (userIn1 == rand1 && userIn2 == rand2 && userIn3 == rand3)
				{
					cout<<"Three matching in exact order"<< endl;
				}
				if (userIn1 == rand1 || userIn1 == rand2 || userIn1 == rand3 || userIn2 == rand1 || userIn2 == rand2 || userIn2 == rand3 || userIn3 == rand1 || userIn3 == rand2 || userIn3 == rand3)
				{
					cout<<"One is matching"<< endl;
				}
				if ((userIn1 == rand1 || userIn1 == rand2 || userIn1 == rand3) && (userIn2 == rand1 || userIn2 == rand2 || userIn2 == rand3) && (userIn3 == rand1 || userIn3 == rand2 || userIn3 == rand3))
				{
					cout<<"Three matching but not in order"<<endl;
				}
				if ((userIn1 == rand1 || userIn1 == rand2 || userIn1 == rand3) || (userIn2 == rand1 || userIn2 == rand2 || userIn2 == rand3) && (userIn3 == rand1 || userIn3 == rand2 || userIn3 == rand3))
				{
					cout<<"Two matching"<<endl;
				}
				if ((userIn1 == rand1 || userIn1 == rand2 || userIn1 == rand3) && (userIn2 == rand1 || userIn2 == rand2 || userIn2 == rand3) || (userIn3 == rand1 || userIn3 == rand2 || userIn3 == rand3))
				{
					cout<<"Two matching"<<endl;
				}
				if ((userIn1 != rand1 && userIn1 != rand2 && userIn1 != rand3) && (userIn2 != rand1 && userIn2 != rand2 && userIn2 != rand3) && (userIn3 != rand1 && userIn3 != rand2 && userIn3 != rand3))
				{
					cout<<"No matches at all"<<endl;
				}
			}
			else
			{
				cout<<"Please input numbers again as one or more may be out of the defined range 0 - 9";
			}
		break;
		}
		
		case 4:
		{
			cout<<"You have chosen to quit";
			break;
		}
		
		default:
		{
			cout<<"Invalid option selected.";
		}
	}
}
else
{
	cout<<"Please select a valid option";
}

return 0;
}
