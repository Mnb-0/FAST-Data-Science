#!/bin/bash
sudo apt-get install freeglut3-dev glew-utils libglew1.6-dev libfreeimage-dev	
