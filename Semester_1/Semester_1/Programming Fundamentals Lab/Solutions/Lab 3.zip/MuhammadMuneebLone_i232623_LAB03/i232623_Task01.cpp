#include <iostream>
using namespace std;
int main()
{

cout<<"********\n ****** \n  ****  \n   **   \n";

cout<<"********\n *    * \n  *  *  \n   **   \n";

cout<<"*     *\n * _ * \n * _ * \n*     *\n";
return 0;
}
