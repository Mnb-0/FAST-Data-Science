#include <iostream>
using namespace std;
int main()
{
cout<<"Abdullah ibn Amr reported: The Messenger of Allah, peace and blessings be upon him, passed by Sa'd while \nhe was performing ablution. The Prophet said, \"What is extravagance?\" Sa'd said, \"Is there\nextravagance with water in abluion?\" The Prophet said, \"Yes, even if you were on the banks of a flowing\nriver.\" \n\nSource: Musnad Ahmad 7065\n";
 return 0;
}
