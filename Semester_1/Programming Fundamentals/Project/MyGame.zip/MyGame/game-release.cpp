//============================================================================
// Name        : game-release.cpp
// Author      : Sibt ul Hussain
// Version     :
// Copyright   : (c) Reserved
// Description : Basic Snake Game
//============================================================================
#ifndef SNAKEGAME_CPP_
#define SNAKEGAME_CPP_

#include <string>
#include "util.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <string>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sstream>
#include <cmath> 
using namespace std;

int width = 600, height = 600;//Canvas Size
int snakeSize = 3; //Initial Size of snake
int snakeX[100], snakeY[100]; //Arrays to control X and Y of the snake individually
int foodX[5], foodY[5];//Arrays to keep track of how many foods have been printed
int foodTimers[5];//Array to keep track of how long a food has been printed
int score = 0;
int highScore = 0;
bool gameOver = false;//Flag set to false initially
int directionX = 20, directionY = 0;//directionX set to 20 initially so that the snake is moving right 20 pixels as soon as the game starts
string stringHigh;//Random variable simply for outputting from the file

//Function to check current high score and update it if new score is larger than the highscore
void UpdateHighScore() {
    ifstream inputFile("highscore.txt");
    if (inputFile.is_open()) {
        inputFile >> highScore;
        inputFile.close();
    }

    if (score > highScore) {
        highScore = score;
        ofstream outputFile("highscore.txt");
        if (outputFile.is_open()) {
            outputFile << highScore;
            outputFile.close();
        } else {
            cout << "Error: Unable to write to highscore.txt" << endl;
        }
    }
}
//University provided function
void SetCanvasSize(int width, int height) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, 0, height, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}
//Function to check if the food is collding with any pre-existing food
bool IsFoodColliding(int index) {
    for (int i = 0; i < index; ++i) {
        if (foodX[i] == foodX[index] || foodY[i] == foodY[index] ||
            abs(foodX[i] - foodX[index]) == abs(foodY[i] - foodY[index])) {
            return true;
        }
    }
    return false;
}
//Function to simply just initialize the game to default settings chosen by me
void InitializeGame() {
    snakeX[0] = width / 2;
    snakeY[0] = height / 2;

    for (int i = 0; i < 5; ++i) {
        do {
            foodX[i] = 20 + rand() % ((width - 40) / 20) * 20;
            foodY[i] = 20 + rand() % ((height - 40) / 20) * 20;//Assigning coordinates to the food
        } while (IsFoodColliding(i));

        foodTimers[i] = 150;
    }
}
//Function to draw the most basic level of the snake (at the start)
void DrawSnake() {
    for (int i = 0; i < snakeSize; ++i) {//This loops runs till the size of the snake so it generates as many squares as it needs to
        if (i == 0) {
            DrawCircle(snakeX[i], snakeY[i], 10, colors[DARK_GREEN]);
        } else {
            DrawSquare(snakeX[i] - 10, snakeY[i] - 10, 20, colors[GREEN]);
        }
    }
}
//Function to draw foodd at randomly generated coordinates with randomly generated colors 
void DrawFood(int x, int y, int colorIndex) {
    DrawCircle(x, y, 10, colors[colorIndex]);
}
//University provided function
void Display() {
    glClearColor(0, 0.0, 0.0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    ifstream inputFile("highscore.txt");//Code to extract high score from file
    if (inputFile.is_open()) {
        inputFile >> stringHigh;
        inputFile.close();
    }

    DrawString(10, height - 30, "High Score: " + stringHigh, colors[WHITE]);//Displaying all time high score
    DrawString(width - 200, height - 30, "Current Score: " + to_string(score), colors[WHITE]);//Displaying current score

    if (!gameOver) {//If the game is not over, keep drawing snake and keep drawing foods
        DrawSnake();

        for (int i = 0; i < 5; ++i) {
            if (foodTimers[i] > 0 && foodY[i] <= 600 && foodX[i] >= 20) {
                int randomColorIndex = rand() % 40;
                DrawFood(foodX[i], foodY[i], randomColorIndex);
            }
        }
    } else {//As soon as game ends, display one of these two messages
        UpdateHighScore();
        if (score > stoi(stringHigh)) {
            DrawString(width / 2 - 250, height / 2, "Game Over! You have broken all previous records and now the highest score is: " + to_string(score), colors[WHITE]);
        } else {
            DrawString(width / 2 - 150, height / 2, "Game Over! Your score was: " + to_string(score), colors[WHITE]);
        }
    }

    glutSwapBuffers();
}

void MoveSnake() {
    for (int i = snakeSize - 1; i > 0; --i) {
        snakeX[i] = snakeX[i - 1];//Move next square to previous square location
        snakeY[i] = snakeY[i - 1];
    }

    snakeX[0] += directionX;//Move the snake head
    snakeY[0] += directionY;

    if (snakeX[0] >= width) {//Code to loop back around if snake reaches the border
        snakeX[0] = 0;
    } else if (snakeX[0] < 0) {
        snakeX[0] = width - 20;
    }

    if (snakeY[0] >= height-20) {
        snakeY[0] = 0;
    } else if (snakeY[0] < 0) {
        snakeY[0] = height - 40;
    }
}

void CheckCollision() {
    if (snakeX[0] >= width || snakeX[0] < 0 || snakeY[0] >= height || snakeY[0] < 0) {
        gameOver = true;
        if (score > highScore) {
            highScore = score;
        }
    }

    for (int i = 1; i < snakeSize; ++i) {//Checks if snake collides with itself using a for loop
        if (snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i]) {
            gameOver = true;
            if (score > highScore) {
                highScore = score;
            }
        }
    }

    for (int i = 0; i < 5; ++i) {//Checks if the head collides with food
        if (foodTimers[i] > 0 && snakeX[0] == foodX[i] && snakeY[0] == foodY[i]) {
            snakeSize++;
            score = score + 5;
            foodTimers[i] = 0;

            do {
                foodX[i] = rand() % (width / 20) * 20;
                foodY[i] = rand() % (height / 20) * 20;
            } while (IsFoodColliding(i));
        }
    }
}
//University provided function
//This function gets called repeatedly
void Timer(int m) {
    if (!gameOver) {//While the game is not over, move the snake and check collisions
        MoveSnake();
        CheckCollision();

        for (int i = 0; i < 5; ++i) {//Checking if the time alloted to the food is over or not
            if (foodTimers[i] > 0) {
                foodTimers[i]--;//Decrement timer if time is not finished
            } else {
                foodX[i] = rand() % (width / 20) * 20;//Else regenerate food at new x and y
                foodY[i] = rand() % (height / 20) * 20;
                foodTimers[i] = 150;//Reset the timer

                do {
                    foodX[i] = rand() % (width / 20) * 20;
                    foodY[i] = rand() % (height / 20) * 20;
                } while (IsFoodColliding(i));//This loop ensures that the food does not overlap with any existing foods
            }
        }
    }

    glutPostRedisplay();
    glutTimerFunc(1200.0 / FPS, Timer, 0);//Changed this to 1200 so that snake moves slower/Function gets called after a larger interval I think
}

void NonPrintableKeys(int key, int x, int y) {
    if (key == GLUT_KEY_LEFT && directionX != 20) {//If not already going right, go left
        directionX = -20;
        directionY = 0;
    } else if (key == GLUT_KEY_RIGHT && directionX != -20) {//If not already going left, go right
        directionX = 20;
        directionY = 0;
    } else if (key == GLUT_KEY_UP && directionY != -20) {//If not already going down, go up
        directionX = 0;
        directionY = 20;
    } else if (key == GLUT_KEY_DOWN && directionY != 20) {//If not already going up, go down
        directionX = 0;
        directionY = -20;
    }

    glutPostRedisplay();
}

void PrintableKeys(unsigned char key, int x, int y) {
    if (key == KEY_ESC) {
        exit(1);
    }

    glutPostRedisplay();
}

int main(int argc, char* argv[]) {
    srand(time(NULL));

    InitRandomizer();// seed the random number generator...
    glutInit(&argc, argv);// initialize the graphics library...
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
    glutInitWindowPosition(50, 50); // set the initial position of our window
    glutInitWindowSize(width, height); // set the size of our window
    glutCreateWindow("Snake Game by Muneeb Lone"); // set the title of our game window
    SetCanvasSize(width, height); // set the number of pixels...
// Register your functions to the library,
// you are telling the library names of function to call for different tasks.
//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.
    InitializeGame();

    glutDisplayFunc(Display); // tell library which function to call for drawing Canvas.
    glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
    glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
    glutTimerFunc(5.0 / FPS, Timer, 0);
// now handle the control to library and it will call our registered functions when
// it deems necessary...
    glutMainLoop();
    return 1;
}

#endif /* Snake Game */

