//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{

int month = 0, year = 0;
cout<<"Enter the year: ";
cin>>year;
cout<<"Enter the month: ";
cin>>month;

//Checking if year is leap year

if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
{
	if (month > 0 && month <= 12)
	{
		
