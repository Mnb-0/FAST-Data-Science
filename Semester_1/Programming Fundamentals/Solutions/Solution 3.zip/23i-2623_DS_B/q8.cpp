//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
#include <string>
using namespace std;
int main()
{
int deci_num , base_num;
int place = 1, converted_num = 0;
string result = "";
cout<<"Enter a decimal number: ";
cin>> deci_num;
cout<<"Enter the base for which you want to convert to from 2 to 16: ";
cin>> base_num;



if (base_num == 10)
{	
	cout<<"No conversion performed. Your number was: " << deci_num << endl;
}

if (base_num >=2 && base_num <10)
{
	while (deci_num > 0)
	{
		int remainder = deci_num % base_num;
		converted_num = converted_num + (remainder * place);
		deci_num = deci_num / 2;
		place = place * 10;
	}
	
	cout<< "The representation of your number in the base " << base_num << " is: " << converted_num << endl;
	
}

if (base_num > 10 && base_num <= 16)
{
	while (deci_num > 0)
	{
		int remainder = deci_num % base_num;
		if (remainder < 10)
		{
			result = result + to_string(remainder);
		}
		if (remainder >= 10)
		{
			switch (remainder)
			{	
				case 10:
				{
					result = result + "A";
					break;
				} 
				
				case 11:
				{
					result = result + "B";
					break;
				} 
				
				case 12:
				{
					result = result + "C";
					break;
				} 
				
				case 13:
				{
					result = result + "D";
					break;
				} 
				
				case 14:
				{
					result = result + "E";
					break;
				} 
				
				case 15:
				{
					result = result + "F";
					break;
				}
			}
		}
		deci_num = deci_num / base_num;
	}
	
	cout<< "The representation of your number in the base " << base_num << " is: " << result << endl;
				
}		
return 0;
}
