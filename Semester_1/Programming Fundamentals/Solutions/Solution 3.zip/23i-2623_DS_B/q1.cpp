//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
using namespace std;
int main()
{
int num_in = 0;
cout<<"Enter a number: "\n";
cin>>num_in;

if ( num_in == 0 || num_in == 1 || num_in == 2 || num_in == 3 || num_in == 5 || num_in == 8)
{
 
