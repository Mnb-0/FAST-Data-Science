//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
using namespace std;

int main() {
    char el1 = '1', el2 = '2', el3 = '3', el4 = '4', el5 = '5', el6 = '6', el7 = '7', el8 = '8', el9 = '9';
    char player_now = 'O';
    bool draw = false;
    bool gameOver = false;
    int moves_num = 0;

    while (gameOver == false && moves_num < 9) 
    {
    
        cout << el1 << " | " << el2 << " | " << el3 << endl;
        cout << "---------" << endl;
        cout << el4 << " | " << el5 << " | " << el6 << endl;
        cout << "---------" << endl;
        cout << el7 << " | " << el8 << " | " << el9 << endl;

        cout << "Player " << player_now << " please enter a move between 1 to 9: ";
        char move_made;
        cin >> move_made;

        // Check if move is valid
        if (move_made >= '1' && move_made <= '9') 
        {
            // Check if box is empty
            if ((el1 == '1' && move_made == '1') || (el2 == '2' && move_made == '2') || (el3 == '3' && move_made == '3') ||
                (el4 == '4' && move_made == '4') || (el5 == '5' && move_made == '5') || (el6 == '6' && move_made == '6') ||
                (el7 == '7' && move_made == '7') || (el8 == '8' && move_made == '8') || (el9 == '9' && move_made == '9')) 
                {
                moves_num = moves_num + 1;

                // Assigning the player's letter to the element they have selected
                switch (move_made) 
                {
                    case '1':
                        el1 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;		//break as soon as a player is changed/move made
                    case '2':
                        el2 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;
                    case '3':
                        el3 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;
                    case '4':
                        el4 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;
                    case '5':
                        el5 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;
                    case '6':
                        el6 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;
                    case '7':
                        el7 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;
                    case '8':
                        el8 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;
                    case '9':
                        el9 = (player_now == 'O') ? 'O' : 'X';//Changing player
                        break;
                }

                // Checking if the player has won
                if ((el1 == el2 && el2 == el3) || (el1 == el4 && el4 == el7) || (el7 == el8 && el8 == el9) ||
                    (el3 == el6 && el6 == el9) || (el2 == el5 && el5 == el8) || (el4 == el5 && el5 == el6) ||
                    (el1 == el5 && el5 == el9) || (el3 == el5 && el5 == el7)) //Checking all possible combinations for winning
                    {
                    cout << player_now << " has won!!!" << endl;
                    gameOver = true;
                    draw = false;
                    break;
                    }

                // Now changing players
                player_now = (player_now == 'O') ? 'X' : 'O';
            }
            else 
            {
                cout << "Filled space. Try again" << endl;
            }
        } 
        else 
        {
            cout << "Invalid move. Enter a number between 1 and 9" << endl;
        }
    }

    if (gameOver == false && moves_num >= 9 && draw == false) //checking for draws
    {
    
    	cout << el1 << " | " << el2 << " | " << el3 << endl;
        cout << "---------" << endl;
        cout << el4 << " | " << el5 << " | " << el6 << endl;
        cout << "---------" << endl;
        cout << el7 << " | " << el8 << " | " << el9 << endl;
        cout << "It's a draw" << endl;
        
    }

    return 0;
}

