//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
using namespace std;

int main() {
    int num_in;
    int tri_num = 1;

    cout << "Enter the number of rows for Pascal's Triangle: ";
    cin >> num_in;

    if (num_in <= 0) 
    {
        cout << "Please enter a positive integer." << endl;
        return 1;
    }

    for (int i = 0; i < num_in; i++) //row control
    {
        for (int spacing = 0; spacing < num_in - i; spacing++) 
        {
            cout << "  ";
        }

        for (int j = 0; j <= i; j++) //column control
        {
            if (j != 0 && i != 0) //Checking to see if this is the first row. Floating point error without this.
            {
                tri_num = tri_num * (i - j + 1) / j; //every value in the triangle is a coefficient of the binomial theorem so we can use ncr formula.
            } else 
            {
                tri_num = 1; //setting coefficient to 1 if first row and first column as triangle starts with 1.
                
            }

            cout << tri_num << "   ";
        }

        cout << endl;
    }

    return 0;
}

