//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
using namespace std;

int main() 
{
    double x_in , term , result = 0;
    int n_out;

    cout << "Enter the value of x for which you want to calculate approximation of sin(x): ";
    cin >> x_in;

    cout << "Enter the number of terms for the MacLaurin Series: ";
    cin >> n_out;
    int sign = 1;
    term = x_in;
    
    for (int i = 1; i <= n_out; i++) 
    {
        result = result + sign * term;  //Add term currently needed into the result
        sign = -1 * sign;           //flip sign as signs are alternating in the Series
        term = term * (x_in * x_in) / ((2 * i) * (2 * i + 1)); //Calculating the next term
    }
    
    cout << "sin(" << x_in << ") using " << n_out << " terms: " << result << endl;

    return 0;
}

