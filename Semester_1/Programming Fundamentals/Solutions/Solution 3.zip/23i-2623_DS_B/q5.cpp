//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>

int main() {
    int n_in;
    using namespace std;

    cout << "Enter the number of rows and columns (n): ";
    cin >> n_in;

    if (n_in <= 0) 
    {
        cout << "Please enter a positive integer for n." << endl;
    }
    else
    {
    int current = 2;
    int maxNum = n_in * n_in;
    while (current <= maxNum) 
    {
        bool isPrime = true;
        if (current <= 1) 
        {
            isPrime = false;
        } else 
        {
            for (int i = 2; i * i <= current; i++) 
            {
                if (current % i == 0) 
                {
                    isPrime = false;
                    break;
                }
            }
        }

        if (isPrime) 
        {
            cout << "P ";
        } else 
        {
            cout << ". ";
        }
        current++;
        if (current % n_in == 1) 
        {
            cout << endl;
        }
    }
    }
    return 0;
}

