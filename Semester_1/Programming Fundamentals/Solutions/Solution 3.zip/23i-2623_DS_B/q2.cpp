//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
using namespace std;
int main()
{
int row_num = 0;
char characters;
cout<<"Enter the number of rows you want to print: ";
cin>>row_num;
for (int i = 1 ; i <= row_num; i++) // row control
{
	for (int j = 1 ; j <= row_num - i ; j++) //spacing control
	{
		cout<<" ";
	}
	
	for (int j = 1; j <= i ; j++) //insertion start
	{
		cout << "\\";
	}
	cout<<"|";
	for (int jk= 1 ; jk <= i ; jk++)
	{
		cout<<"/";// insertion end
	}
	cout<<endl;
}
for (int i = 1 ; i <= row_num % 3; i++)//trunk row control
{
	for (int j = 2 ; j <= row_num ; j++)//spacing 
	{
		cout<<" ";
	}
		cout << "|||\n";//trunk insertion
}
return 0;
}
