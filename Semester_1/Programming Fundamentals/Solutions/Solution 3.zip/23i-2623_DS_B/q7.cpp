//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
using namespace std;
int main()
{	
	for( int i = 1; i <= 5 ; i++)
	{
		for (int spacing = i; spacing <= 5 ; spacing++)
		{
			cout<<" ";
		}
		for (int j = 1 ; j <=  i* 2 - 1 ; j++)
		{
			if ( j!=1&&j!=i* 2 - 1)
			{
				cout<<" ";
			}
			else
			{
				cout<<" /"<<i<<"\\ ";
			}
		}
	cout<<endl;
	}
	for (int k = 1 ; k<= 8; k ++)
	{
		if (k == 1 || k == 8)
		{
			cout<<" |*^^^^^^^^^^^^^*|"<<endl;
		}
		if (k == 2 || k == 5)
		{
			cout<<" |* < *** *** > *|"<<endl;
		}
		if (k == 3 || k == 4)
		{
			cout<<" |* < * * * * > *|"<<endl;
		}
		if (k ==6 || k == 7 || k == 8)
		{
			cout<<" |* < *   *   > *|"<<endl;
		}
		
	}
			
	for( int i = 5; i >=1 ; i--)
	{
		for (int spacing = i; spacing <= 5 ; spacing++)
		{
			cout<<" ";
		}
		for (int j = 1 ; j <=  i* 2 - 1 ; j++)
		{
			if ( j!=1&&j!=i* 2 - 1)
			{
				cout<<" ";
			}
			else
			{
				cout<<" /"<<i<<"\\ ";
			}
		}
	cout<<endl;
	}
return 0;
}
