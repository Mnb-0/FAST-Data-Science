//Muhammad Muneeb Lone 23i-2623 Assignment 3
#include <iostream>
using namespace std;
int main()
{
int totalPersons = 0, stepPersons = 0, lastLeft = 0, i = 1;
cout<<"Enter the number of people (n): ";
cin>>totalPersons;
cout<<"Enter the step (k): ";
cin>>stepPersons;
if ((totalPersons < 1) || (stepPersons < 1))
	cout<<"Invalid input. n and k must be above 0";
else 
{

while (i <= totalPersons)
{
	lastLeft = (lastLeft + stepPersons) % i; //Mod used so that counting goes to start in circle
	i++;
}

cout<<"Last person standing is at "<< lastLeft + 1; //Adding one because integers start at 0
}
return 0;
}
